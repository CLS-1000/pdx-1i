# cls_pdx1 — PDX-1i

**Portland Metro Intelligence module of the SPEC-1 engine.**

Powers the **Metro Citizens Brief** (MCB) — a signal-gated, neutrality-enforced
publication that tells residents of the bi-state Portland metro what their
elected officials are doing, how budgets and bills are moving, and what
watch-listed institutional players are doing relative to baseline.

```
SPEC-1 (engine) → Metro Citizens Brief (publication) ← cls_pdx1 / PDX-1i (data module)
```

## Scope

**Jurisdictional reach:** Multnomah, Washington, Clackamas counties; Metro;
City of Portland; Clark County (WA); City of Vancouver. Federal and Oregon /
Washington state coverage where officials represent metro constituencies.

**Editorial anchor:** Portland. The graph carries the full metro; the brief
narrates from Portland's chair, looking outward.

## Watch list

Anchor entities tracked with their own per-entity baselines:

| Slug | Entity | Surveillance surface |
|---|---|---|
| `pge` | Portland General Electric | PUC dockets, SEC, ORESTAR, lobby |
| `nw_natural` | NW Natural Gas | PUC dockets, SEC, ORESTAR, lobby |
| `portland_water_bureau` | City of Portland Water Bureau | Council budget, contracts, rates |
| `trimet` | TriMet | Board actions, contracts, service changes |
| `ppb` | Portland Police Bureau | Council budget, oversight, contracts |
| `ohsu` | Oregon Health & Science University | OHA, board, 990s, foundation grants |
| `schnitzer` | Schnitzer (family + affiliated entities) | Property, donations, lobby |

## Architecture invariants

- **Append-only.** No record is mutated in place. Updates are new records.
- **Single-writer per namespace.** Exactly one authorized writer path per
  record type; the rest read.
- **`run_id` traceability.** Every record traces to the cycle that produced it.
- **Provenance non-negotiable.** No `source_uri` → rejected at the provenance gate.
- **Neutrality enforced as gates.** Loaded vocabulary, hedging, and missing
  attribution fail the publication assembly.
- **Failure-first.** Bad rows logged, never halt the pipeline.

## Module surface

```
cls_pdx1/
  models.py              # Pydantic core models (Official, Entity, Affiliation, Bill, Signal, Anomaly, Issue, ...)
  gates.py               # Structural gates (provenance, append-only, time-bounding, corroboration, freshness)
  neutrality/            # tone / hedging / attribution gates for publication prose
  sources/               # Source adapters
    orestar.py           #   Oregon SOS campaign finance
    olis.py              #   Oregon Legislature bills + votes + testimony
    sei.py               #   Oregon Government Ethics Statement of Economic Interest
    (additional)         #   wa_pdc, sec_edgar, irs_990, portland_lobby, multnomah_assessor, ...
  watch/                 # Per-entity watch modules → emit Signals
    pge.py, nw_natural.py, ppb.py, ...
  legislation/           # Bill state machine, transition-to-signal lifting
  anomaly.py             # 90-day rolling baseline, sigma-tiered anomaly detection
  triggers.py            # Publication trigger evaluation (signal-gated, not calendar-gated)
  explain/               # Plain-language LLM summarization with neutrality retry
  publication/           # Issue assembly + markdown + PDF (ReportLab) + diagram (D3 export)
  pipeline.py            # Orchestration
  tests/                 # Test suite
```

## Confidence and anomaly tiers

| Tier | Confidence (affiliations) | Anomaly (signals) |
|---|---|---|
| 1 | Hard public record | > 3 sigma OR Tier-1 hard signal |
| 2 | Documented filing | 2 – 3 sigma OR multi-source soft |
| 3 | Single-source / reported | 1 – 2 sigma, watching |
| 4 | Inferred / co-mention | below threshold, baseline only |

**Publication gate:** anomaly Tier 1 or 2 only. Tier 3 watched; Tier 4 logged
to baseline.
**Corroboration gate:** Tier 3 factual claims need 2 independent sources;
Tier 4 effectively unpublishable as factual claim.

## Publication trigger

The brief is **signal-gated, not calendar-gated.** A trigger evaluation runs
each cycle:

- Accumulated weight from signals (`bill_transition.enacted` = 5.0,
  `donation_received` = 0.5, etc.) and anomalies (Tier 1 = 10.0, Tier 2 = 4.0)
- Threshold check (default 10.0)
- Minimum spacing floor (default 3 days; prevents firehose)
- Quiet-gap override (default 14 days; publish anyway if quiet)

Tier-1 anomaly alone meets threshold. Routine donations alone do not.

## Output channels

| Channel | Format | Cadence |
|---|---|---|
| PDF issue | ReportLab, sacred-geometry aesthetic | Per issue, immutable archive |
| Web view | HTML + interactive D3 force-directed graph | Updated on lower-gate trigger between issues |
| Markdown | GitHub Pages / import format | Per issue |

Diagram regeneration is **not live**. It runs on a separate, lower gate than
publication — the graph drifts forward between issues; the newsletter narrates
the bigger jumps.

## Mission

The brief exists because residents don't have the time to track every council
agenda, every PUC filing, every SEI disclosure, and every committee vote. The
information is public but not legible. PDX-1i takes legible inputs (filings,
votes, contracts, donations) and produces a legible output (a neutrally
written brief, sourced to primary documents, with a visual map of the
relationships).

The brief never characterizes. It narrates what documents show and what
people said on the record. The reader does the inferring.

## Wiring status

| Component | Status |
|---|---|
| Core models | Built |
| Structural gates | Built + tested |
| Neutrality gates | Built + tested |
| Anomaly detector | Built + tested |
| Trigger evaluator | Built + tested |
| Bill state machine | Built + tested |
| Issue assembly + markdown + diagram | Built + tested |
| PDF rendering (ReportLab) | Built (font fallback if Plex unavailable) |
| Explain layer (LLM-backed summarization) | Built + tested (LLM call via factory) |
| Pipeline orchestration | Built + tested (tolerates unwired adapters) |
| ORESTAR adapter | Built (CSV path live; live HTTP scrape not yet wired) |
| OLIS adapter | Built (mapping live; OData query not yet wired) |
| SEI adapter | Built (JSONL path live; AURA PDF parser not yet wired) |
| WA PDC adapter | Not yet started |
| SEC EDGAR adapter | Not yet started |
| IRS 990 adapter | Not yet started |
| Portland lobby adapter | Not yet started |
| `cls_db` persistence integration | Not yet wired |
| Entity resolver | Not yet built |
| `spec1_api` endpoints | Not yet wired |
| APScheduler job registration | Not yet wired |
| MCB Issue 1 | Not yet published |

## Test

```bash
cd /path/to/cls_pdx1/..
python -m pytest cls_pdx1/tests/ -v
```
