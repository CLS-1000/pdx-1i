"""
cls_pdx1.publication.diagram
=============================

Web diagram exporter — produces the data structure consumed by the
sacred-geometry D3.js force-directed graph that accompanies each Metro
Citizens Brief issue.

The diagram is NOT live. It regenerates on a trigger (separate, lower
gate than the publication trigger — the graph drifts forward between
issues, the newsletter narrates the bigger jumps).

Output shape:
  {
    "snapshot_id": "...",
    "generated_at": "...",
    "issue_number_at_generation": int | None,
    "nodes": [
      {"id": "...", "label": "...", "kind": "official|entity|bill|district",
       "group": "...", "watch_listed": bool, "size": float, "meta": {...}}
    ],
    "links": [
      {"source": "...", "target": "...", "edge_type": "...",
       "weight": float, "confidence": int, "valid_from": "...",
       "valid_to": "..." | null, "amount_usd": float | null,
       "source_uri": "..."}
    ]
  }

Consumed by `assets/portland-political-graph.js` (or successor) — the
sacred-geometry visualization (black/white only, IBM Plex Mono labels,
no color accents).
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterable, Optional

from ..models import (
    Affiliation,
    Bill,
    District,
    Entity,
    Official,
    Provenance,
)


@dataclass
class DiagramSnapshot:
    """A point-in-time export of the political graph for visualization.

    Snapshots are append-only. Each carries an immutable `snapshot_id`
    derived from the content hash so identical graph states produce
    identical ids (deterministic, cacheable).
    """

    snapshot_id: str
    generated_at: datetime
    nodes: list[dict] = field(default_factory=list)
    links: list[dict] = field(default_factory=list)
    issue_number_at_generation: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "snapshot_id": self.snapshot_id,
            "generated_at": self.generated_at.isoformat(),
            "issue_number_at_generation": self.issue_number_at_generation,
            "nodes": self.nodes,
            "links": self.links,
        }

    def to_json(self, indent: Optional[int] = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


# ---------------------------------------------------------------------------
# Node builders
# ---------------------------------------------------------------------------


def _official_node(o: Official) -> dict:
    return {
        "id": o.id,
        "label": o.full_name,
        "kind": "official",
        "group": o.jurisdiction.value,
        "watch_listed": False,
        "size": 1.0,
        "meta": {
            "role": o.role,
            "party": o.party,
            "district_id": o.district_id,
            "status": o.status,
        },
    }


def _entity_node(e: Entity) -> dict:
    # Watch-listed entities render larger; priority 1 largest.
    if e.is_watch_listed:
        size = 3.0 if (e.watch_priority or 99) <= 1 else 2.0
    else:
        size = 1.0
    return {
        "id": e.id,
        "label": e.canonical_name,
        "kind": "entity",
        "group": e.kind.value,
        "watch_listed": e.is_watch_listed,
        "size": size,
        "meta": {
            "kind": e.kind.value,
            "sector_tags": [s.value for s in e.sector_tags],
            "jurisdiction_primary": (
                e.jurisdiction_primary.value if e.jurisdiction_primary else None
            ),
            "watch_priority": e.watch_priority,
        },
    }


def _district_node(d: District) -> dict:
    return {
        "id": d.id,
        "label": d.name,
        "kind": "district",
        "group": d.jurisdiction.value,
        "watch_listed": False,
        "size": 0.5,
        "meta": {
            "type": d.type.value,
            "number": d.number,
        },
    }


def _bill_node(b: Bill) -> dict:
    return {
        "id": b.id,
        "label": b.bill_number,
        "kind": "bill",
        "group": b.jurisdiction.value,
        "watch_listed": False,
        "size": 0.75,
        "meta": {
            "title": b.title,
            "state": b.state.value,
            "introduced_at": b.introduced_at.isoformat(),
            "sectors": [s.value for s in b.affected_sectors],
        },
    }


# ---------------------------------------------------------------------------
# Link builder
# ---------------------------------------------------------------------------


# Edge type -> visual weight. Hard records get heavier strokes; inferred
# edges render thin. The viz layer translates weight to stroke width.
EDGE_WEIGHT_BY_TIER: dict[int, float] = {
    1: 3.0,  # Hard record
    2: 2.0,  # Documented
    3: 1.0,  # Reported
    4: 0.5,  # Inferred
}


def _affiliation_link(a: Affiliation) -> dict:
    return {
        "source": a.official_id,
        "target": a.entity_id,
        "edge_type": a.edge_type.value,
        "weight": EDGE_WEIGHT_BY_TIER.get(int(a.confidence), 0.5),
        "confidence": int(a.confidence),
        "valid_from": a.valid_from.isoformat(),
        "valid_to": a.valid_to.isoformat() if a.valid_to else None,
        "amount_usd": a.amount_usd,
        "source_uri": a.provenance.source_uri,
    }


def _bill_sponsor_link(bill: Bill, sponsor_id: str, role: str) -> dict:
    """Officials connect to bills via sponsorship. Edge type sponsor / co_sponsor."""
    return {
        "source": sponsor_id,
        "target": bill.id,
        "edge_type": role,  # "sponsor" | "co_sponsor"
        "weight": 2.0 if role == "sponsor" else 1.0,
        "confidence": 1,  # public record
        "valid_from": bill.introduced_at.isoformat(),
        "valid_to": None,
        "amount_usd": None,
        "source_uri": bill.provenance.source_uri,
    }


# ---------------------------------------------------------------------------
# Snapshot builder
# ---------------------------------------------------------------------------


def build_snapshot(
    officials: Iterable[Official],
    entities: Iterable[Entity],
    affiliations: Iterable[Affiliation],
    districts: Iterable[District] = (),
    bills: Iterable[Bill] = (),
    issue_number_at_generation: Optional[int] = None,
    now: Optional[datetime] = None,
) -> DiagramSnapshot:
    """Assemble a DiagramSnapshot from the canonical record set.

    Time-filtering: affiliations whose valid_to has passed are still
    rendered but the viz layer can hide them; this exporter does not
    filter on time (the graph carries history).
    """
    now = now or datetime.utcnow()

    nodes: list[dict] = []
    links: list[dict] = []

    for d in districts:
        nodes.append(_district_node(d))
    for o in officials:
        nodes.append(_official_node(o))
    for e in entities:
        nodes.append(_entity_node(e))
    for b in bills:
        nodes.append(_bill_node(b))

    valid_node_ids = {n["id"] for n in nodes}

    for a in affiliations:
        # Skip affiliations whose endpoints aren't in the node set
        if a.official_id not in valid_node_ids:
            continue
        if a.entity_id not in valid_node_ids:
            continue
        links.append(_affiliation_link(a))

    for b in bills:
        for sponsor_id in b.sponsor_ids:
            if sponsor_id in valid_node_ids:
                links.append(_bill_sponsor_link(b, sponsor_id, "sponsor"))
        for co in b.co_sponsor_ids:
            if co in valid_node_ids:
                links.append(_bill_sponsor_link(b, co, "co_sponsor"))

    # Officials -> Districts (membership edge, lightweight)
    by_official_district: dict[str, str] = {
        o.id: o.district_id for o in officials if o.district_id
    }
    district_ids = {d.id for d in districts}
    for official_id, district_id in by_official_district.items():
        if district_id not in district_ids:
            continue
        links.append(
            {
                "source": official_id,
                "target": district_id,
                "edge_type": "represents",
                "weight": 1.0,
                "confidence": 1,
                "valid_from": now.date().isoformat(),
                "valid_to": None,
                "amount_usd": None,
                "source_uri": "internal:cls_pdx1.officials",
            }
        )

    # Deterministic snapshot id (content hash)
    payload_for_hash = json.dumps(
        {"nodes": sorted(nodes, key=lambda n: n["id"]),
         "links": sorted(links, key=lambda l: (l["source"], l["target"], l["edge_type"]))},
        sort_keys=True,
        default=str,
    )
    snapshot_id = hashlib.sha256(payload_for_hash.encode("utf-8")).hexdigest()[:16]

    return DiagramSnapshot(
        snapshot_id=snapshot_id,
        generated_at=now,
        nodes=nodes,
        links=links,
        issue_number_at_generation=issue_number_at_generation,
    )


def write_snapshot(snapshot: DiagramSnapshot, out_path: str) -> str:
    """Write a snapshot to disk as JSON. Returns the path."""
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(snapshot.to_json())
    return out_path


__all__ = [
    "DiagramSnapshot",
    "EDGE_WEIGHT_BY_TIER",
    "build_snapshot",
    "write_snapshot",
]
