"""
cls_pdx1.publication
=====================

Metro Citizens Brief (MCB) issue assembly.

Each issue carries:
  - issue number (monotonic, starts at 1)
  - sections (each gated through neutrality before assembly)
  - trigger context (which signals / anomalies fired this issue)
  - graph snapshot id (the diagram state at publish time)
  - dual format: PDF (archival, sacred-geometry aesthetic) + web (interactive)

Issues are append-only: once published, immutable. Corrections are new issues
that explicitly reference the prior issue id.

PDF generation mirrors the existing wsb_publication.py ReportLab pattern.
Web view is a separate handler that consumes the same Issue model and serves
the interactive diagram beside the prose.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from ..models import (
    Anomaly,
    Issue,
    IssueSection,
    Provenance,
    Signal,
)
from ..neutrality import section_neutrality_gate


class IssueAssemblyError(Exception):
    """Raised when issue assembly fails a structural invariant."""


class SectionGateFailure(IssueAssemblyError):
    """Raised when one or more sections fail neutrality gates."""

    def __init__(self, section_heading: str, violations: list[str]) -> None:
        self.section_heading = section_heading
        self.violations = violations
        super().__init__(
            f"Section {section_heading!r} failed neutrality gate: {violations}"
        )


@dataclass
class IssueBuilder:
    """Build an Issue from a set of sections, gated for neutrality.

    Usage:
      builder = IssueBuilder(issue_number=1, trigger_signals=[...], trigger_anomalies=[...])
      builder.add_section("Council vote on PPB budget", body, source_uris, ...)
      builder.add_section(...)
      issue = builder.build(provenance=...)
    """

    issue_number: int
    trigger_signals: list[Signal]
    trigger_anomalies: list[Anomaly]
    diagram_snapshot_id: Optional[str] = None
    correction_of_issue_id: Optional[str] = None
    _sections: list[IssueSection] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self._sections is None:
            self._sections = []

    def add_section(
        self,
        heading: str,
        body: str,
        cited_source_uris: list[str],
        referenced_bill_ids: Optional[list[str]] = None,
        referenced_anomaly_ids: Optional[list[str]] = None,
        referenced_official_ids: Optional[list[str]] = None,
        referenced_entity_ids: Optional[list[str]] = None,
    ) -> None:
        """Add a section. Section fails neutrality => raise immediately."""
        passed, violations = section_neutrality_gate(body, cited_source_uris)
        if not passed:
            raise SectionGateFailure(section_heading=heading, violations=violations)

        if not cited_source_uris:
            raise IssueAssemblyError(
                f"Section {heading!r} must cite at least one source_uri"
            )

        self._sections.append(
            IssueSection(
                heading=heading,
                body=body,
                cited_source_uris=cited_source_uris,
                referenced_bill_ids=referenced_bill_ids or [],
                referenced_anomaly_ids=referenced_anomaly_ids or [],
                referenced_official_ids=referenced_official_ids or [],
                referenced_entity_ids=referenced_entity_ids or [],
            )
        )

    def build(
        self,
        provenance: Provenance,
        published_at: Optional[datetime] = None,
    ) -> Issue:
        if not self._sections:
            raise IssueAssemblyError("cannot build issue with zero sections")
        return Issue(
            issue_number=self.issue_number,
            published_at=published_at or datetime.utcnow(),
            trigger_signal_ids=[s.id for s in self.trigger_signals],
            trigger_anomaly_ids=[a.id for a in self.trigger_anomalies],
            sections=list(self._sections),
            diagram_snapshot_id=self.diagram_snapshot_id,
            correction_of_issue_id=self.correction_of_issue_id,
            provenance=provenance,
        )


# ---------------------------------------------------------------------------
# PDF render — ReportLab integration point
# ---------------------------------------------------------------------------


def render_issue_markdown(issue: Issue) -> str:
    """Render an Issue to markdown.

    Used both as a standalone publication format (e.g., GitHub Pages,
    Substack import) and as input to the PDF renderer downstream.
    """
    lines: list[str] = []
    lines.append(f"# Metro Citizens Brief — Issue {issue.issue_number}")
    lines.append("")
    lines.append(f"_Published {issue.published_at.isoformat()}_")
    lines.append("")
    if issue.correction_of_issue_id:
        lines.append(
            f"_This issue corrects Issue id `{issue.correction_of_issue_id}`._"
        )
        lines.append("")
    lines.append("---")
    lines.append("")
    for section in issue.sections:
        lines.append(f"## {section.heading}")
        lines.append("")
        lines.append(section.body.strip())
        lines.append("")
        if section.cited_source_uris:
            lines.append("**Sources:**")
            for uri in section.cited_source_uris:
                lines.append(f"- {uri}")
            lines.append("")
    lines.append("---")
    lines.append("")
    lines.append(
        f"_Trigger context: {len(issue.trigger_signal_ids)} signals, "
        f"{len(issue.trigger_anomaly_ids)} anomalies._"
    )
    lines.append("")
    if issue.diagram_snapshot_id:
        lines.append(f"_Diagram snapshot: `{issue.diagram_snapshot_id}`_")
    return "\n".join(lines)


def render_issue_pdf(issue: Issue, out_path: str) -> str:
    """Render an Issue to PDF using ReportLab (sacred-geometry aesthetic).

    Mirrors the existing wsb_publication.py pattern. Returns the output path.

    Aesthetic constraints:
      - Black on white only, no color accents
      - IBM Plex Mono throughout
      - Geometric ornament (rule lines, no decorative graphics)
    """
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.platypus import (
            Paragraph,
            SimpleDocTemplate,
            Spacer,
            HRFlowable,
        )
    except ImportError as e:
        raise ImportError(
            "reportlab is required for PDF rendering. Install with: pip install reportlab"
        ) from e

    # Font registration is best-effort — falls back to built-in mono if Plex
    # is not present on the system.
    base_font = "Courier"
    try:
        plex_path = "/usr/share/fonts/truetype/plex/IBMPlexMono-Regular.ttf"
        pdfmetrics.registerFont(TTFont("IBMPlexMono", plex_path))
        base_font = "IBMPlexMono"
    except Exception:
        pass

    doc = SimpleDocTemplate(
        out_path,
        pagesize=LETTER,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
        leftMargin=0.75 * inch,
        rightMargin=0.75 * inch,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "MCBTitle",
        parent=styles["Title"],
        fontName=base_font,
        fontSize=18,
        leading=22,
        spaceAfter=12,
        textColor="#000000",
    )
    h2_style = ParagraphStyle(
        "MCBH2",
        parent=styles["Heading2"],
        fontName=base_font,
        fontSize=12,
        leading=16,
        spaceBefore=12,
        spaceAfter=6,
        textColor="#000000",
    )
    body_style = ParagraphStyle(
        "MCBBody",
        parent=styles["BodyText"],
        fontName=base_font,
        fontSize=9,
        leading=12,
        spaceAfter=6,
        textColor="#000000",
    )
    meta_style = ParagraphStyle(
        "MCBMeta",
        parent=styles["BodyText"],
        fontName=base_font,
        fontSize=8,
        leading=10,
        textColor="#000000",
    )

    flowables = [
        Paragraph(f"METRO CITIZENS BRIEF — ISSUE {issue.issue_number}", title_style),
        Paragraph(f"Published {issue.published_at.isoformat()}", meta_style),
        Spacer(1, 6),
        HRFlowable(width="100%", thickness=0.5, color="#000000"),
        Spacer(1, 12),
    ]

    for section in issue.sections:
        flowables.append(Paragraph(section.heading, h2_style))
        for para in section.body.split("\n\n"):
            if para.strip():
                flowables.append(Paragraph(para.strip().replace("\n", "<br/>"), body_style))
        if section.cited_source_uris:
            sources = "Sources: " + " &nbsp;·&nbsp; ".join(section.cited_source_uris)
            flowables.append(Paragraph(sources, meta_style))
        flowables.append(Spacer(1, 8))
        flowables.append(HRFlowable(width="100%", thickness=0.25, color="#000000"))
        flowables.append(Spacer(1, 8))

    flowables.append(
        Paragraph(
            f"Triggered by {len(issue.trigger_signal_ids)} signals and "
            f"{len(issue.trigger_anomaly_ids)} anomalies.",
            meta_style,
        )
    )

    doc.build(flowables)
    return out_path


__all__ = [
    "IssueBuilder",
    "IssueAssemblyError",
    "SectionGateFailure",
    "render_issue_markdown",
    "render_issue_pdf",
]
