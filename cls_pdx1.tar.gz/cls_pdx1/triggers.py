"""
cls_pdx1.triggers
==================

Publication trigger gates: when does the Metro Citizens Brief fire a new issue?

Three coupled rules:
  1. Signal weight threshold — accumulated weighted signal score crosses a bar.
  2. Maximum quiet gap — publish anyway after N quiet units (prevents
     pathological silence; the brief promises rough weekly cadence).
  3. Minimum spacing — refuse to publish issues closer than M units apart
     (prevents firehose; readers get a coherent issue, not a stream).

These are gates, not schedules. The brief is signal-gated, not calendar-gated;
units here are unit-of-work / signal accumulation, not human-time durations.

Weights are tunable per-anomaly-tier and per-signal-kind.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional

from .models import Anomaly, AnomalyTier, Signal


# Default weight policy. A weight of 1.0 corresponds to "one routine signal".
# Tier-1 anomalies are explicitly publication-worthy on their own.
DEFAULT_SIGNAL_WEIGHTS: dict[str, float] = {
    "bill_transition.enacted": 5.0,
    "bill_transition.passed_both": 4.0,
    "bill_transition.vetoed": 4.0,
    "bill_transition.passed_chamber": 2.0,
    "bill_transition.committee_reported": 1.0,
    "bill_transition.introduced": 0.5,
    "donation_received": 0.5,
    "donation_made": 0.5,
    "rate_filing": 3.0,
    "puc_docket_filing": 3.0,
    "council_vote": 2.0,
    "board_vote": 2.0,
    "contract_award": 1.5,
    "budget_line_change": 2.0,
    "seat_vacancy": 5.0,
    "seat_appointed": 3.0,
    "seat_filled": 3.0,
    "bill_affecting_pge": 2.0,
}


ANOMALY_TIER_WEIGHTS: dict[AnomalyTier, float] = {
    AnomalyTier.TIER_1: 10.0,
    AnomalyTier.TIER_2: 4.0,
    AnomalyTier.TIER_3: 0.0,   # Tier 3 watched but does not fire publication
    AnomalyTier.TIER_4: 0.0,
}


@dataclass
class TriggerPolicy:
    """Configures when an issue fires.

    publish_threshold:   minimum accumulated weight to fire publication
    quiet_gap_days:      publish anyway after this many days even if quiet
    min_spacing_days:    refuse to publish within this many days of last issue
    """

    publish_threshold: float = 10.0
    quiet_gap_days: int = 14
    min_spacing_days: int = 3
    signal_weights: dict[str, float] = field(
        default_factory=lambda: dict(DEFAULT_SIGNAL_WEIGHTS)
    )
    anomaly_weights: dict[AnomalyTier, float] = field(
        default_factory=lambda: dict(ANOMALY_TIER_WEIGHTS)
    )


@dataclass
class TriggerEvaluation:
    """Output of trigger gate evaluation. Carries the decision and the reasons."""

    should_publish: bool
    accumulated_weight: float
    contributing_signal_count: int
    contributing_anomaly_count: int
    reasons: list[str] = field(default_factory=list)
    blockers: list[str] = field(default_factory=list)


def evaluate_publication_trigger(
    signals_since_last: list[Signal],
    anomalies_since_last: list[Anomaly],
    last_published_at: Optional[datetime],
    policy: Optional[TriggerPolicy] = None,
    now: Optional[datetime] = None,
) -> TriggerEvaluation:
    """Evaluate whether the next issue should fire.

    Returns a TriggerEvaluation with the full decision context. The pipeline
    decides what to do with that (publish, defer, log).
    """
    policy = policy or TriggerPolicy()
    now = now or datetime.utcnow()

    # ---- Accumulate weight ----
    signal_weight = sum(
        policy.signal_weights.get(s.kind, 0.0) for s in signals_since_last
    )
    anomaly_weight = sum(
        policy.anomaly_weights.get(a.tier, 0.0) for a in anomalies_since_last
    )
    total_weight = signal_weight + anomaly_weight

    reasons: list[str] = []
    blockers: list[str] = []

    if anomaly_weight > 0:
        reasons.append(
            f"anomaly weight {anomaly_weight:.1f} from "
            f"{len(anomalies_since_last)} anomalies"
        )
    if signal_weight > 0:
        reasons.append(
            f"signal weight {signal_weight:.1f} from "
            f"{len(signals_since_last)} signals"
        )

    # ---- Apply spacing floor ----
    if last_published_at is not None:
        spacing = now - last_published_at
        min_spacing = timedelta(days=policy.min_spacing_days)
        if spacing < min_spacing:
            blockers.append(
                f"min spacing {policy.min_spacing_days}d not met "
                f"(elapsed {spacing.total_seconds() / 86400:.1f}d)"
            )

    # ---- Threshold check ----
    threshold_met = total_weight >= policy.publish_threshold

    # ---- Quiet gap override ----
    quiet_gap_override = False
    if last_published_at is not None:
        elapsed = now - last_published_at
        quiet_gap = timedelta(days=policy.quiet_gap_days)
        if elapsed >= quiet_gap:
            quiet_gap_override = True
            reasons.append(
                f"quiet gap override ({policy.quiet_gap_days}d elapsed)"
            )

    should_publish = (threshold_met or quiet_gap_override) and not blockers

    if threshold_met and not blockers:
        reasons.append(
            f"threshold {policy.publish_threshold:.1f} met "
            f"({total_weight:.1f} accumulated)"
        )

    return TriggerEvaluation(
        should_publish=should_publish,
        accumulated_weight=total_weight,
        contributing_signal_count=len(signals_since_last),
        contributing_anomaly_count=len(anomalies_since_last),
        reasons=reasons,
        blockers=blockers,
    )


__all__ = [
    "TriggerPolicy",
    "TriggerEvaluation",
    "DEFAULT_SIGNAL_WEIGHTS",
    "ANOMALY_TIER_WEIGHTS",
    "evaluate_publication_trigger",
]
