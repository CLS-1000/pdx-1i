"""End-to-end runnable demos for cls_pdx1."""
