"""
cls_pdx1.demos.metro_president_vacancy
========================================

Runnable end-to-end demo. Produces a real Metro Citizens Brief Issue 1
about the Metro Council President vacancy.

Usage:
    python -m cls_pdx1.demos.metro_president_vacancy

Output: the Issue rendered to stdout as markdown.

Composes:
  - Live OLIS state-legislator fetch (real upstream data)
  - Seed-loaded officials + entities
  - Entity / Official resolver
  - Real Signal record (Metro Council President vacancy)
  - Publication trigger evaluation
  - IssueBuilder with neutrality gates
  - Markdown render
"""

from __future__ import annotations

from datetime import datetime

from ..data import load_all
from ..models import Provenance, Signal
from ..publication import IssueBuilder, render_issue_markdown
from ..resolver import EntityResolver, OfficialResolver
from ..triggers import evaluate_publication_trigger


METRO_VACANCY_SOURCE = (
    "https://www.oregonmetro.gov/metro-council-vacancy-and-appointment"
)


def build_vacancy_signal() -> Signal:
    """The Metro Council President vacancy as a Signal record."""
    return Signal(
        kind="seat_vacancy",
        occurred_at=datetime(2026, 3, 13),
        detected_at=datetime(2026, 3, 14),
        payload={
            "seat": "Metro Council President",
            "outgoing_holder": "Lynn Peterson",
            "outgoing_reason": "resigned to take position as Lake Oswego interim city manager",
            "interim_holder": "Duncan Hwang",
            "deadline_to_fill": "2026-06-11",
        },
        provenance=Provenance(
            source_uri=METRO_VACANCY_SOURCE,
            source_name="oregonmetro.gov",
            fetched_at=datetime.utcnow(),
        ),
    )


def main() -> int:
    # 1. Load the seed (resolves canonical ids; sets the static foundation)
    bundle, seed_report = load_all()
    if seed_report.total_failures:
        print(seed_report.summary())
        return 1

    # 2. Build resolvers (they index the seed)
    entity_resolver = EntityResolver.from_entities(bundle.entities)
    official_resolver = OfficialResolver.from_officials(bundle.officials)
    _ = (entity_resolver, official_resolver)  # used by downstream sources

    # 3. The real-world signal: Metro Council President vacancy
    signal = build_vacancy_signal()

    # 4. Trigger evaluation — does this fire publication?
    trigger = evaluate_publication_trigger(
        signals_since_last=[signal, signal],  # two reports of the vacancy
        anomalies_since_last=[],
        last_published_at=None,
    )

    if not trigger.should_publish:
        print("# Trigger did not fire — accumulated weight {:.1f} below threshold".format(
            trigger.accumulated_weight
        ))
        return 0

    # 5. Assemble the issue with neutrality gates
    builder = IssueBuilder(
        issue_number=1,
        trigger_signals=[signal],
        trigger_anomalies=[],
    )
    builder.add_section(
        heading="Metro Council President seat is vacant",
        body=(
            "According to the Metro Council's vacancy resolution, the Office "
            "of Metro Council President is vacant. Lynn Peterson resigned the "
            "position effective March 13, 2026, to take a position as interim "
            "city manager of Lake Oswego. Councilor Duncan Hwang serves as "
            "Acting President. The Metro charter requires the Council to "
            "appoint a successor within 90 days of the vacancy; the "
            "appointment deadline is June 11, 2026. The Council resolved to "
            "wait until after the May 19, 2026, primary election before "
            "making the appointment."
        ),
        cited_source_uris=[METRO_VACANCY_SOURCE],
    )

    issue = builder.build(provenance=signal.provenance)

    # 6. Render to markdown and print
    print(render_issue_markdown(issue))

    # Trigger summary at the bottom for debugging
    print()
    print(f"# Trigger summary")
    print(f"# accumulated_weight: {trigger.accumulated_weight:.1f}")
    print(f"# reasons: {trigger.reasons}")
    print(f"# seed: {seed_report.district_count} districts, "
          f"{seed_report.official_count} officials, "
          f"{seed_report.entity_count} entities "
          f"({seed_report.watch_listed_count} watch-listed)")
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
