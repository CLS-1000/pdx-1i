"""Tests for cls_pdx1."""
