"""Tests for cls_pdx1.sources."""

from __future__ import annotations

import csv
import tempfile
from datetime import datetime
from typing import Iterator, Optional

from cls_pdx1.models import EdgeType, Jurisdiction, Provenance
from cls_pdx1.sources import FetchResult, SourceAdapter
from cls_pdx1.sources.olis import OLIS_STATUS_MAP, map_olis_status, OlisAdapter
from cls_pdx1.sources.orestar import OrestarAdapter
from cls_pdx1.sources.sei import SEI_CATEGORY_TO_EDGE, SeiAdapter


# ---------------------------------------------------------------------------
# SourceAdapter base
# ---------------------------------------------------------------------------


class _DummyAdapter(SourceAdapter):
    """Minimal concrete adapter for testing the base class."""

    name = "dummy"
    jurisdiction = Jurisdiction.PORTLAND
    edge_types = [EdgeType.DONATION]

    def __init__(self, raws: list[dict]) -> None:
        super().__init__()
        self.raws = raws

    def _fetch_raw(self, since: Optional[datetime] = None) -> Iterator[dict]:
        yield from self.raws

    def _stamp(self, raw: dict) -> dict:
        raw["provenance"] = Provenance(
            source_uri="https://example.com/dummy/" + str(raw.get("id", "?")),
            source_name="dummy",
            fetched_at=datetime.utcnow(),
        )
        return raw

    def _normalize(self, stamped: dict) -> Optional[dict]:
        if stamped.get("skip"):
            return None
        return stamped


class TestSourceAdapterBase:
    def test_full_pipeline_accepts_good_record(self):
        adapter = _DummyAdapter([{"id": "1", "amount": 100}])
        result = adapter.fetch()
        assert isinstance(result, FetchResult)
        assert result.items_seen == 1
        assert result.items_accepted == 1
        assert result.items_rejected == 0

    def test_normalize_returning_none_skipped_silently(self):
        adapter = _DummyAdapter([{"id": "1", "skip": True}])
        result = adapter.fetch()
        assert result.items_seen == 1
        assert result.items_accepted == 0
        assert result.items_rejected == 0

    def test_stamp_error_routes_to_rejected(self):
        class _BrokenStamp(_DummyAdapter):
            def _stamp(self, raw: dict) -> dict:
                raise RuntimeError("simulated stamp failure")

        adapter = _BrokenStamp([{"id": "1"}])
        result = adapter.fetch()
        assert result.items_seen == 1
        assert result.items_rejected == 1
        rejection_reason = result.rejected[0][1]
        assert "STAMP_ERR" in rejection_reason

    def test_provenance_failure_routes_to_rejected(self):
        # If _stamp emits a bad URI, provenance_gate will catch it.
        class _BadUri(_DummyAdapter):
            def _stamp(self, raw: dict) -> dict:
                raw["provenance"] = {
                    "source_uri": "not-a-url",
                    "source_name": "x",
                    "fetched_at": datetime.utcnow(),
                }
                return raw

        # Note: Provenance constructor validates URI; this constructs a raw dict
        # that bypasses Provenance class but still gets caught at the gate.
        adapter = _BadUri([{"id": "1"}])
        result = adapter.fetch()
        # The gate runs on the normalized dict; if Provenance was a real class
        # instantiation it would have raised earlier. With dict provenance
        # the gate still catches it.
        # Either route, the record must not enter the records list.
        assert result.items_accepted == 0


# ---------------------------------------------------------------------------
# ORESTAR adapter
# ---------------------------------------------------------------------------


class TestOrestarAdapter:
    def test_csv_export_path(self):
        # Make a tiny CSV that mimics ORESTAR shape
        with tempfile.NamedTemporaryFile(
            "w", suffix=".csv", delete=False, newline=""
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "tran_id",
                    "tran_date",
                    "amount",
                    "contributor",
                    "committee",
                    "candidate_id",
                    "source_pdf_url",
                ],
            )
            writer.writeheader()
            writer.writerow(
                {
                    "tran_id": "T-001",
                    "tran_date": "2025-05-01T00:00:00",
                    "amount": "500.00",
                    "contributor": "Portland General Electric",
                    "committee": "Friends of J. Smith",
                    "candidate_id": "C-001",
                    "source_pdf_url": "https://example.com/orestar/T-001.pdf",
                }
            )
            tmp_path = f.name

        adapter = OrestarAdapter(export_path=tmp_path)
        result = adapter.fetch()
        assert result.items_accepted == 1
        record = result.records[0]
        assert record["amount_usd"] == 500.00
        assert record["edge_type"] == EdgeType.DONATION
        assert record["provenance"].source_uri.startswith("https://example.com/orestar/")

    def test_zero_amount_skipped(self):
        with tempfile.NamedTemporaryFile(
            "w", suffix=".csv", delete=False, newline=""
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "tran_id", "tran_date", "amount", "contributor",
                    "committee", "candidate_id", "source_pdf_url",
                ],
            )
            writer.writeheader()
            writer.writerow({
                "tran_id": "T-002",
                "tran_date": "2025-05-01T00:00:00",
                "amount": "0",
                "contributor": "x",
                "committee": "y",
                "candidate_id": "",
                "source_pdf_url": "https://example.com/orestar/T-002.pdf",
            })
            tmp_path = f.name

        adapter = OrestarAdapter(export_path=tmp_path)
        result = adapter.fetch()
        assert result.items_accepted == 0


# ---------------------------------------------------------------------------
# OLIS adapter
# ---------------------------------------------------------------------------


class TestOlisStatusMap:
    def test_all_states_mapped(self):
        # Every key in OLIS_STATUS_MAP should map to a BillState
        from cls_pdx1.models import BillState
        for status_text, state in OLIS_STATUS_MAP.items():
            assert isinstance(state, BillState)

    def test_map_known_status(self):
        from cls_pdx1.models import BillState
        assert map_olis_status("Signed by Governor") == BillState.ENACTED
        assert map_olis_status("Withdrawn") == BillState.WITHDRAWN

    def test_map_substring_fallback(self):
        from cls_pdx1.models import BillState
        # Partial match should still work
        result = map_olis_status("Bill passed both chambers")
        assert result == BillState.PASSED_BOTH

    def test_map_unknown_defaults_to_committee(self):
        from cls_pdx1.models import BillState
        assert map_olis_status("Totally Made Up Status") == BillState.COMMITTEE

    def test_map_empty_defaults_to_introduced(self):
        from cls_pdx1.models import BillState
        assert map_olis_status("") == BillState.INTRODUCED


class TestOlisAdapter:
    def test_fetch_not_implemented_without_export(self):
        # With live=False (or no session_year), the adapter is in offline mode
        # and _fetch_raw raises NotImplementedError on first iteration.
        adapter = OlisAdapter(session_year=2025, live=False)
        try:
            list(adapter._fetch_raw())
            raised = False
        except NotImplementedError:
            raised = True
        assert raised


# ---------------------------------------------------------------------------
# SEI adapter
# ---------------------------------------------------------------------------


class TestSeiCategoryMap:
    def test_all_categories_map_to_edge_types(self):
        for category, edge in SEI_CATEGORY_TO_EDGE.items():
            assert isinstance(edge, EdgeType)

    def test_employer_maps_to_employment(self):
        assert SEI_CATEGORY_TO_EDGE["employer"] == EdgeType.EMPLOYMENT

    def test_business_interest_maps_to_sei_disclosed(self):
        assert SEI_CATEGORY_TO_EDGE["business_interest"] == EdgeType.SEI_DISCLOSED


class TestSeiAdapter:
    def test_jsonl_export(self):
        # Write a tiny JSONL export
        import json as _json

        with tempfile.NamedTemporaryFile(
            "w", suffix=".jsonl", delete=False
        ) as f:
            f.write(
                _json.dumps({
                    "filing_id": "F-001",
                    "filer_name": "Test Official",
                    "filer_office": "Portland City Councilor",
                    "filing_year": 2025,
                    "filing_date": "2025-04-15",
                    "line_category": "employer",
                    "line_subject": "Acme Consulting",
                    "line_detail": "consulting income",
                    "line_value": "75000",
                    "source_pdf_url": "https://example.com/sei/F-001.pdf",
                }) + "\n"
            )
            tmp_path = f.name

        adapter = SeiAdapter(export_path=tmp_path)
        result = adapter.fetch()
        assert result.items_accepted == 1
        record = result.records[0]
        assert record["edge_type"] == EdgeType.EMPLOYMENT
        assert record["amount_usd"] == 75000.0
        assert "Acme Consulting" in record["description"]
