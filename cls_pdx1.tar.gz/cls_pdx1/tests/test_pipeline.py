"""Tests for cls_pdx1.pipeline orchestration."""

from __future__ import annotations

from datetime import date, datetime
from typing import Iterator, Optional

from cls_pdx1.models import (
    EdgeType,
    Jurisdiction,
    Provenance,
)
from cls_pdx1.pipeline import Pipeline, PipelineRun
from cls_pdx1.sources import SourceAdapter
from cls_pdx1.sources.olis import OlisAdapter
from cls_pdx1.triggers import TriggerPolicy
from cls_pdx1.watch.pge import PgeWatch


def _prov() -> Provenance:
    return Provenance(
        source_uri="https://example.com/x",
        source_name="test",
        fetched_at=datetime.utcnow(),
    )


class _FakeOrestar(SourceAdapter):
    """In-memory fake adapter that emits a PGE donation."""

    name = "fake_orestar"
    jurisdiction = Jurisdiction.OREGON
    edge_types = [EdgeType.DONATION]

    def __init__(self, n: int = 1, amount: float = 5000.0) -> None:
        super().__init__()
        self.n = n
        self.amount = amount

    def _fetch_raw(self, since: Optional[datetime] = None) -> Iterator[dict]:
        for i in range(self.n):
            yield {
                "tran_id": f"T-{i}",
                "amount": self.amount,
                "contributor": "Portland General Electric Company",
                "committee": "Friends of Test Councilor",
                "tran_date": "2025-05-01T00:00:00",
                "source_pdf_url": f"https://example.com/orestar/T-{i}.pdf",
            }

    def _stamp(self, raw: dict) -> dict:
        raw["provenance"] = Provenance(
            source_uri=raw["source_pdf_url"],
            source_name="fake_orestar",
            fetched_at=datetime.utcnow(),
        )
        return raw

    def _normalize(self, stamped: dict) -> Optional[dict]:
        return {
            "amount_usd": float(stamped["amount"]),
            "observed_at": datetime.fromisoformat(stamped["tran_date"]),
            "valid_from": date(2025, 5, 1),
            "edge_type": EdgeType.DONATION,
            "metadata": {
                "contributor_name_raw": stamped["contributor"],
                "committee_name_raw": stamped["committee"],
            },
            "provenance": stamped["provenance"],
        }


class TestPipeline:
    def test_run_cycle_emits_signals_from_watch(self):
        pipeline = Pipeline(
            adapters=[_FakeOrestar(n=3, amount=2500.0)],
            watch_modules=[PgeWatch()],
        )
        run = pipeline.run_cycle()
        assert isinstance(run, PipelineRun)
        assert run.items_accepted == 3
        # PgeWatch should emit a donation_made signal per record
        donations = [s for s in run.signals_emitted if s.kind == "donation_made"]
        assert len(donations) == 3

    def test_unimplemented_adapter_logged_not_raised(self):
        # An adapter that explicitly opts out of live mode raises
        # NotImplementedError from _fetch_raw; the pipeline catches it.
        pipeline = Pipeline(
            adapters=[OlisAdapter(session_year=2025, live=False), _FakeOrestar(n=1)],
            watch_modules=[PgeWatch()],
        )
        run = pipeline.run_cycle()
        # The OLIS adapter contributes an error, but the cycle completes
        assert any("olis" in e.lower() and "not implemented" in e.lower() for e in run.errors)
        # The other adapter still ran
        assert run.items_accepted == 1

    def test_run_cycle_evaluates_trigger(self):
        pipeline = Pipeline(
            adapters=[_FakeOrestar(n=3)],
            watch_modules=[PgeWatch()],
            trigger_policy=TriggerPolicy(publish_threshold=0.5, min_spacing_days=0),
        )
        run = pipeline.run_cycle()
        assert run.trigger is not None

    def test_empty_run(self):
        # No adapters, no watches, no signals -> no errors, no trigger fire
        pipeline = Pipeline(adapters=[], watch_modules=[])
        run = pipeline.run_cycle()
        assert run.items_seen == 0
        assert run.signals_emitted == []
        assert run.errors == []
