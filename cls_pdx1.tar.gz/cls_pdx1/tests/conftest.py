"""pytest configuration for cls_pdx1."""

from __future__ import annotations

import sys
from pathlib import Path

# Allow tests to import cls_pdx1 when running pytest from inside the package.
_pkg_root = Path(__file__).resolve().parent.parent.parent
if str(_pkg_root) not in sys.path:
    sys.path.insert(0, str(_pkg_root))
