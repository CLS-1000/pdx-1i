"""Tests for cls_pdx1.data seed loader."""

from __future__ import annotations

from cls_pdx1.data import (
    SeedBundle,
    SeedReport,
    load_all,
    load_districts,
    load_entities,
    load_officials,
    verify_seed,
)
from cls_pdx1.models import EntityKind, Jurisdiction, Sector


class TestSeedLoadsCleanly:
    """The seed files must load without any validation or gate failures.

    These tests are the canonical contract: if a record is added to the
    seed JSON and it fails validation or a gate, this test breaks.
    """

    def test_verify_seed_zero_failures(self):
        report = verify_seed()
        assert report.total_failures == 0, report.summary()

    def test_districts_load_with_no_failures(self):
        districts, report = load_districts()
        assert report.total_failures == 0, report.summary()
        assert len(districts) > 0

    def test_officials_load_with_no_failures(self):
        # Without district reference set first
        officials, report = load_officials()
        assert len(report.validation_failures) == 0
        assert len(report.gate_failures) == 0
        assert len(officials) > 0

    def test_entities_load_with_no_failures(self):
        entities, report = load_entities()
        assert report.total_failures == 0, report.summary()
        assert len(entities) > 0


class TestSeedContents:
    """Spot-check the seed contains what it should."""

    def test_portland_council_complete(self):
        """All 14 Portland city-government officials must be present
        (Mayor + Auditor + 12 councilors). Additional Portland-jurisdiction
        records (PPS Board, PPA President, Chamber CEO) are allowed."""
        bundle, _ = load_all()
        portland = [o for o in bundle.officials if o.jurisdiction == Jurisdiction.PORTLAND]
        # Filter to records whose role names a city-government position
        city_government = [
            o for o in portland
            if any(
                term in o.role
                for term in ("Mayor", "City Auditor", "City Council")
            )
        ]
        assert len(city_government) == 14, (
            f"Expected 14 Portland city-government officials, found "
            f"{len(city_government)}: {[o.full_name for o in city_government]}"
        )

    def test_mayor_keith_wilson_present(self):
        bundle, _ = load_all()
        wilson = next(
            (o for o in bundle.officials if o.id == "off:portland:keith-wilson"),
            None,
        )
        assert wilson is not None
        assert wilson.role.startswith("Mayor")
        assert wilson.term_start.year == 2025

    def test_council_president_present(self):
        bundle, _ = load_all()
        dunphy = next(
            (o for o in bundle.officials if o.id == "off:portland:jamie-dunphy"),
            None,
        )
        assert dunphy is not None
        assert "President" in dunphy.role

    def test_council_vp_present(self):
        bundle, _ = load_all()
        clark = next(
            (o for o in bundle.officials if o.id == "off:portland:olivia-clark"),
            None,
        )
        assert clark is not None
        assert "Vice President" in clark.role

    def test_multnomah_county_chair_present(self):
        bundle, _ = load_all()
        vp = next(
            (o for o in bundle.officials if o.id == "off:multnomah:jessica-vega-pederson"),
            None,
        )
        assert vp is not None
        assert vp.role.startswith("Multnomah County Chair")

    def test_federal_senators_present(self):
        bundle, _ = load_all()
        senators = [
            o for o in bundle.officials
            if o.jurisdiction == Jurisdiction.FEDERAL
            and "Senator" in o.role
        ]
        assert len(senators) == 2
        names = {s.full_name for s in senators}
        assert "Ron Wyden" in names
        assert "Jeff Merkley" in names

    def test_oregon_house_delegation_present(self):
        bundle, _ = load_all()
        house = [
            o for o in bundle.officials
            if o.jurisdiction == Jurisdiction.FEDERAL
            and "Representative" in o.role
        ]
        # Portland metro: OR-1, OR-3, OR-5, OR-6 representatives
        assert len(house) >= 4

    def test_multi_jurisdiction_coverage(self):
        """Seed must include every metro jurisdiction we framed."""
        bundle, _ = load_all()
        present = {o.jurisdiction for o in bundle.officials}
        required = {
            Jurisdiction.PORTLAND,
            Jurisdiction.MULTNOMAH,
            Jurisdiction.METRO,
            Jurisdiction.WASHINGTON_OR,
            Jurisdiction.CLACKAMAS,
            Jurisdiction.CLARK_WA,
            Jurisdiction.VANCOUVER,
            Jurisdiction.FEDERAL,
        }
        missing = required - present
        assert not missing, f"Missing jurisdictions: {missing}"


class TestEntities:
    def test_watch_anchors_present(self):
        """Every anchor from watch/__init__.py ANCHORS must have a seed Entity."""
        from cls_pdx1.watch import ANCHORS

        bundle, _ = load_all()
        ids_in_seed = {e.id for e in bundle.entities}

        # Map watch slugs to expected entity ids
        watch_to_entity = {
            "pge": "ent:pge",
            "nw_natural": "ent:nw-natural",
            "portland_water_bureau": "ent:portland-water-bureau",
            "trimet": "ent:trimet",
            "ppb": "ent:ppb",
            "ohsu": "ent:ohsu",
            "schnitzer": "ent:schnitzer-cluster",
        }
        for anchor in ANCHORS:
            expected = watch_to_entity.get(anchor.slug)
            assert expected in ids_in_seed, (
                f"Watch anchor {anchor.slug!r} has no matching entity in seed "
                f"(expected id {expected!r})"
            )

    def test_pge_is_watch_listed(self):
        bundle, _ = load_all()
        pge = next(e for e in bundle.entities if e.id == "ent:pge")
        assert pge.is_watch_listed
        assert pge.watch_priority == 1
        assert Sector.UTILITY in pge.sector_tags
        assert pge.kind == EntityKind.COMPANY

    def test_ppb_is_agency(self):
        bundle, _ = load_all()
        ppb = next(e for e in bundle.entities if e.id == "ent:ppb")
        assert ppb.kind == EntityKind.AGENCY
        assert Sector.PUBLIC_SAFETY in ppb.sector_tags

    def test_ppa_is_union(self):
        bundle, _ = load_all()
        ppa = next(e for e in bundle.entities if e.id == "ent:ppa")
        assert ppa.kind == EntityKind.UNION


class TestSchemaIntegrity:
    """Cross-record invariants: ids unique, references resolve."""

    def test_district_ids_unique(self):
        districts, _ = load_districts()
        ids = [d.id for d in districts]
        assert len(ids) == len(set(ids)), "Duplicate district ids in seed"

    def test_official_ids_unique(self):
        officials, _ = load_officials()
        ids = [o.id for o in officials]
        assert len(ids) == len(set(ids)), "Duplicate official ids in seed"

    def test_entity_ids_unique(self):
        entities, _ = load_entities()
        ids = [e.id for e in entities]
        assert len(ids) == len(set(ids)), "Duplicate entity ids in seed"

    def test_no_orphan_district_references(self):
        """Every officials.district_id must resolve to a real district id."""
        bundle, report = load_all()
        assert report.orphan_district_refs == [], (
            f"Orphan district references: {report.orphan_district_refs}"
        )

    def test_seed_provenance_uses_real_urls(self):
        """Sanity check: every record's source_uri is an http(s) URL.

        (provenance_gate already enforces this; this is a belt-and-suspenders
        check.)
        """
        bundle, _ = load_all()
        for record_list in (bundle.districts, bundle.officials, bundle.entities):
            for r in record_list:
                uri = r.provenance.source_uri
                assert uri.startswith("https://") or uri.startswith("http://"), (
                    f"{r.id} has non-http source_uri: {uri!r}"
                )


class TestSeedBundle:
    def test_bundle_helper_properties(self):
        bundle, _ = load_all()
        assert isinstance(bundle, SeedBundle)
        assert len(bundle.district_ids) == len(bundle.districts)
        assert len(bundle.official_ids) == len(bundle.officials)
        assert len(bundle.entity_ids) == len(bundle.entities)
        assert all(e.is_watch_listed for e in bundle.watch_listed)


class TestReportSummary:
    def test_summary_format(self):
        report = verify_seed()
        summary = report.summary()
        assert "Districts:" in summary
        assert "Officials:" in summary
        assert "Entities:" in summary
        assert "Watch-listed:" in summary
        assert "Failures:" in summary
