"""Tests for cls_pdx1.triggers."""

from __future__ import annotations

from datetime import datetime, timedelta

from cls_pdx1.models import Anomaly, AnomalyTier, Provenance, Signal
from cls_pdx1.triggers import (
    ANOMALY_TIER_WEIGHTS,
    DEFAULT_SIGNAL_WEIGHTS,
    TriggerPolicy,
    evaluate_publication_trigger,
)


def _prov() -> Provenance:
    return Provenance(
        source_uri="https://example.com/x",
        source_name="test",
        fetched_at=datetime.utcnow(),
    )


def _signal(kind: str = "donation_made") -> Signal:
    now = datetime.utcnow()
    return Signal(
        kind=kind,
        occurred_at=now,
        detected_at=now,
        provenance=_prov(),
    )


def _anomaly(tier: AnomalyTier) -> Anomaly:
    return Anomaly(
        entity_id="ent-1",
        tier=tier,
        detected_at=datetime.utcnow(),
        kind="donation_spike",
        description="...",
        baseline_window_days=90,
        provenance=_prov(),
    )


class TestEvaluatePublicationTrigger:
    def test_zero_signals_no_publish(self):
        result = evaluate_publication_trigger(
            signals_since_last=[],
            anomalies_since_last=[],
            last_published_at=datetime.utcnow() - timedelta(days=1),
        )
        assert not result.should_publish
        assert result.accumulated_weight == 0.0

    def test_tier_1_anomaly_alone_fires(self):
        result = evaluate_publication_trigger(
            signals_since_last=[],
            anomalies_since_last=[_anomaly(AnomalyTier.TIER_1)],
            last_published_at=datetime.utcnow() - timedelta(days=4),
        )
        # Tier 1 weight is 10 by default; threshold is 10
        assert result.should_publish
        assert result.accumulated_weight >= 10.0

    def test_tier_3_anomaly_does_not_fire(self):
        result = evaluate_publication_trigger(
            signals_since_last=[],
            anomalies_since_last=[_anomaly(AnomalyTier.TIER_3)] * 50,
            last_published_at=datetime.utcnow() - timedelta(days=4),
        )
        # Tier 3 has weight 0
        assert not result.should_publish

    def test_min_spacing_blocks_publication(self):
        result = evaluate_publication_trigger(
            signals_since_last=[],
            anomalies_since_last=[_anomaly(AnomalyTier.TIER_1)],
            last_published_at=datetime.utcnow() - timedelta(hours=12),
        )
        assert not result.should_publish
        assert any("min spacing" in b for b in result.blockers)

    def test_quiet_gap_override(self):
        # No signals, but the gap is long enough to publish anyway
        result = evaluate_publication_trigger(
            signals_since_last=[],
            anomalies_since_last=[],
            last_published_at=datetime.utcnow() - timedelta(days=20),
            policy=TriggerPolicy(quiet_gap_days=14, min_spacing_days=3),
        )
        assert result.should_publish
        assert any("quiet gap" in r for r in result.reasons)

    def test_first_publication_no_spacing_block(self):
        # last_published_at is None => no spacing block, no quiet gap
        # but the threshold must still be met
        result = evaluate_publication_trigger(
            signals_since_last=[_signal("bill_transition.enacted")] * 3,
            anomalies_since_last=[],
            last_published_at=None,
        )
        # 3 * 5.0 = 15.0 > threshold 10.0
        assert result.should_publish

    def test_custom_policy(self):
        # Lower the threshold drastically
        policy = TriggerPolicy(publish_threshold=1.0, min_spacing_days=0)
        result = evaluate_publication_trigger(
            signals_since_last=[_signal("donation_received")],  # weight 0.5
            anomalies_since_last=[],
            last_published_at=datetime.utcnow() - timedelta(days=1),
            policy=policy,
        )
        # 0.5 < 1.0, still no publish
        assert not result.should_publish

    def test_threshold_floor_at_min_spacing(self):
        # Threshold met, but spacing not met -> still blocked
        policy = TriggerPolicy(publish_threshold=0.5, min_spacing_days=7)
        result = evaluate_publication_trigger(
            signals_since_last=[_signal("bill_transition.enacted")],  # 5.0
            anomalies_since_last=[],
            last_published_at=datetime.utcnow() - timedelta(days=2),
            policy=policy,
        )
        assert not result.should_publish
        assert any("min spacing" in b for b in result.blockers)


class TestPolicyInvariants:
    def test_signal_weights_cover_important_kinds(self):
        required = {
            "bill_transition.enacted",
            "council_vote",
            "rate_filing",
            "donation_received",
        }
        assert required <= set(DEFAULT_SIGNAL_WEIGHTS.keys())

    def test_anomaly_tier_weights_cover_all_tiers(self):
        for tier in AnomalyTier:
            assert tier in ANOMALY_TIER_WEIGHTS

    def test_tier_1_weight_meets_threshold_alone(self):
        # Tier 1 should be heavy enough to fire publication on its own
        default_policy = TriggerPolicy()
        assert ANOMALY_TIER_WEIGHTS[AnomalyTier.TIER_1] >= default_policy.publish_threshold

    def test_tier_3_and_4_weights_are_zero(self):
        assert ANOMALY_TIER_WEIGHTS[AnomalyTier.TIER_3] == 0.0
        assert ANOMALY_TIER_WEIGHTS[AnomalyTier.TIER_4] == 0.0
