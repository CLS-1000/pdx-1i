"""Integration tests for cls_pdx1.sources.olis against the live OLIS OData service.

These tests hit the live `https://api.oregonlegislature.gov` endpoint. They
are marked to skip cleanly when the network is unavailable or the endpoint
is unreachable, so they remain safe to run from anywhere — CI, local, or
isolated environments.

Run only when you want to verify the live wiring:
    pytest cls_pdx1/tests/test_olis_live.py -v
"""

from __future__ import annotations

import socket
import urllib.error
import urllib.request

import pytest

from cls_pdx1.sources.olis import (
    OLIS_ODATA_BASE,
    OlisAdapter,
    OlisLegislatorAdapter,
    _odata_fetch,
    map_olis_status,
)
from cls_pdx1.models import BillState, Jurisdiction


def _olis_reachable() -> bool:
    """Quick probe — is OLIS reachable from this host?

    A failure here doesn't mean the code is broken; it means we're offline
    or OLIS is down. The integration tests then skip rather than fail.
    """
    try:
        req = urllib.request.Request(
            OLIS_ODATA_BASE + "/",
            headers={"Accept": "application/atomsvc+xml"},
        )
        urllib.request.urlopen(req, timeout=5).close()
        return True
    except (urllib.error.URLError, socket.timeout, ConnectionError, OSError):
        return False


olis_required = pytest.mark.skipif(
    not _olis_reachable(),
    reason="OLIS endpoint not reachable from this host (offline / firewall / outage)",
)


@olis_required
class TestOlisOdataFetch:
    def test_legislative_sessions_returns_data(self):
        data = _odata_fetch("LegislativeSessions", top=3)
        assert "value" in data
        assert len(data["value"]) > 0
        for s in data["value"]:
            assert "SessionKey" in s
            assert "SessionName" in s


@olis_required
class TestOlisLegislatorAdapterLive:
    def test_fetch_legislators_2025(self):
        adapter = OlisLegislatorAdapter(session_year=2025, max_records=10)
        result = adapter.fetch()
        # All fetched should pass; 0 rejected
        assert result.items_seen > 0
        assert result.items_accepted == result.items_seen
        assert result.items_rejected == 0

    def test_legislator_record_shape(self):
        adapter = OlisLegislatorAdapter(session_year=2025, max_records=3)
        result = adapter.fetch()
        assert len(result.records) > 0
        rec = result.records[0]
        # Every legislator carries a name, a role, a state jurisdiction, and provenance
        assert rec["full_name"]
        assert "State" in rec["role"]
        assert rec["jurisdiction"] == Jurisdiction.OREGON
        assert rec["provenance"].source_uri.startswith("https://")
        # Metadata carries the OLIS code
        assert rec["metadata"]["olis_legislator_code"]

    def test_party_normalization(self):
        adapter = OlisLegislatorAdapter(session_year=2025, max_records=20)
        result = adapter.fetch()
        parties = {r["party"] for r in result.records if r["party"]}
        # OLIS gives "Democrat" — we should have normalized to "Democratic"
        assert "Democrat" not in parties
        # Reasonable to expect at least one Democratic legislator in the dataset
        assert any(p == "Democratic" for p in parties)


@olis_required
class TestOlisMeasureAdapterLive:
    def test_fetch_measures_2025(self):
        adapter = OlisAdapter(session_year=2025, max_records=10)
        result = adapter.fetch()
        assert result.items_seen > 0
        assert result.items_accepted == result.items_seen

    def test_measure_record_shape(self):
        adapter = OlisAdapter(session_year=2025, max_records=3)
        result = adapter.fetch()
        assert len(result.records) > 0
        rec = result.records[0]
        assert rec["bill_number"]
        assert rec["jurisdiction"] == Jurisdiction.OREGON
        assert isinstance(rec["state"], BillState)
        assert rec["provenance"].source_uri.startswith("https://")
        # The source_uri should point at the OLIS web UI for this measure
        assert "olis.oregonlegislature.gov" in rec["provenance"].source_uri

    def test_state_mapping_real_values(self):
        """Status text from OLIS should map to a real BillState (not raise)."""
        adapter = OlisAdapter(session_year=2025, max_records=20)
        result = adapter.fetch()
        for rec in result.records:
            assert isinstance(rec["state"], BillState), (
                f"State for {rec['bill_number']} is not a BillState: {rec['state']!r}"
            )

    def test_max_records_respected(self):
        adapter = OlisAdapter(session_year=2025, max_records=3)
        result = adapter.fetch()
        assert result.items_seen <= 3


@olis_required
class TestStatusMappingReal:
    def test_filed_with_secretary_of_state_is_enacted(self):
        # Real status from production data: "Filed with Secretary of State"
        # appears on resolutions / acts that have completed the process.
        assert map_olis_status("Filed with Secretary of State") == BillState.ENACTED

    def test_in_house_committee_is_committee(self):
        assert map_olis_status("In House Committee") == BillState.COMMITTEE

    def test_in_senate_committee_is_committee(self):
        assert map_olis_status("In Senate Committee") == BillState.COMMITTEE


# ---------------------------------------------------------------------------
# Non-live tests — verify the offline / stub paths still raise correctly
# ---------------------------------------------------------------------------


class TestOlisOfflineSafety:
    def test_no_session_year_raises_not_implemented(self):
        # No session_year => not live => first iteration of _fetch_raw raises
        adapter = OlisAdapter()
        raised = False
        try:
            list(adapter._fetch_raw())
        except NotImplementedError:
            raised = True
        assert raised

    def test_live_false_overrides(self):
        # Explicit live=False should keep the stub behavior even with a session_year
        adapter = OlisAdapter(session_year=2025, live=False)
        raised = False
        try:
            list(adapter._fetch_raw())
        except NotImplementedError:
            raised = True
        assert raised

    def test_legislator_adapter_offline_raises(self):
        adapter = OlisLegislatorAdapter()
        raised = False
        try:
            list(adapter._fetch_raw())
        except NotImplementedError:
            raised = True
        assert raised
