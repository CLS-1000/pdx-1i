"""Tests for cls_pdx1.watch."""

from __future__ import annotations

from datetime import date, datetime

from cls_pdx1.models import Provenance
from cls_pdx1.watch import ANCHORS, anchor_by_slug
from cls_pdx1.watch.nw_natural import NwNaturalWatch
from cls_pdx1.watch.pge import PgeWatch
from cls_pdx1.watch.ppb import PpbWatch


def _prov() -> Provenance:
    return Provenance(
        source_uri="https://example.com/x",
        source_name="test",
        fetched_at=datetime.utcnow(),
    )


class TestAnchorRegistry:
    def test_all_required_anchors_present(self):
        required_slugs = {
            "pge",
            "nw_natural",
            "portland_water_bureau",
            "trimet",
            "ppb",
            "ohsu",
            "schnitzer",
        }
        present = {a.slug for a in ANCHORS}
        assert required_slugs <= present

    def test_anchor_by_slug_finds(self):
        a = anchor_by_slug("pge")
        assert a is not None
        assert a.canonical_name == "Portland General Electric"

    def test_anchor_by_slug_missing_returns_none(self):
        assert anchor_by_slug("not-a-thing") is None

    def test_priority_one_anchors_present(self):
        priority_1 = [a for a in ANCHORS if a.watch_priority == 1]
        assert len(priority_1) >= 6  # all core watch entities


# ---------------------------------------------------------------------------
# PGE watch
# ---------------------------------------------------------------------------


class TestPgeWatch:
    def test_donation_from_pge_emits_signal(self):
        watch = PgeWatch()
        record = {
            "amount_usd": 5000.0,
            "observed_at": datetime(2025, 5, 1),
            "metadata": {
                "contributor_name_raw": "Portland General Electric Company",
                "committee_name_raw": "Friends of J. Smith",
            },
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert len(signals) == 1
        assert signals[0].kind == "donation_made"
        assert signals[0].value == 5000.0

    def test_unrelated_donation_ignored(self):
        watch = PgeWatch()
        record = {
            "amount_usd": 5000.0,
            "observed_at": datetime(2025, 5, 1),
            "metadata": {
                "contributor_name_raw": "Acme Vendor LLC",
                "committee_name_raw": "Friends of J. Smith",
            },
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert signals == []

    def test_utility_legislation_flagged(self):
        watch = PgeWatch()
        record = {
            "bill_number": "HB 2002",
            "title": "Relating to investor-owned utility wildfire mitigation",
            "summary_raw": "",
            "state": "introduced",
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert any(s.kind == "bill_affecting_pge" for s in signals)

    def test_unrelated_bill_ignored(self):
        watch = PgeWatch()
        record = {
            "bill_number": "HB 9999",
            "title": "Relating to school lunch programs",
            "summary_raw": "Modifies school lunch eligibility.",
            "state": "introduced",
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert signals == []


# ---------------------------------------------------------------------------
# NW Natural watch
# ---------------------------------------------------------------------------


class TestNwNaturalWatch:
    def test_gas_legislation_flagged(self):
        watch = NwNaturalWatch()
        record = {
            "bill_number": "HB 3030",
            "title": "Relating to building electrification standards",
            "summary_raw": "",
            "state": "introduced",
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert any(s.kind == "bill_affecting_nw_natural" for s in signals)

    def test_nw_natural_donation_detected(self):
        watch = NwNaturalWatch()
        record = {
            "amount_usd": 2500.0,
            "observed_at": datetime(2025, 4, 1),
            "metadata": {
                "contributor_name_raw": "NW Natural Gas",
                "committee_name_raw": "Citizens for Energy Choice",
            },
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert len(signals) == 1
        assert signals[0].kind == "donation_made"


# ---------------------------------------------------------------------------
# PPB watch
# ---------------------------------------------------------------------------


class TestPpbWatch:
    def test_council_vote_on_ppb_caught(self):
        watch = PpbWatch()
        record = {
            "record_kind": "council_vote",
            "subject": "Portland Police Bureau budget amendment",
            "occurred_at": datetime(2025, 4, 15),
            "outcome": "passed",
            "votes": {"yea": 3, "nay": 2},
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert any(s.kind == "council_vote" for s in signals)

    def test_budget_line_change_caught(self):
        watch = PpbWatch()
        record = {
            "record_kind": "budget_line_change",
            "line_label": "PPB sworn officer compensation",
            "occurred_at": datetime(2025, 4, 1),
            "from_amount": 100_000_000.0,
            "to_amount": 110_000_000.0,
            "delta_usd": 10_000_000.0,
            "fiscal_year": "2025-26",
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        line_signals = [s for s in signals if s.kind == "budget_line_change"]
        assert len(line_signals) == 1
        assert line_signals[0].value == 10_000_000.0

    def test_unrelated_council_vote_ignored(self):
        watch = PpbWatch()
        record = {
            "record_kind": "council_vote",
            "subject": "Library funding renewal",
            "occurred_at": datetime(2025, 4, 1),
            "outcome": "passed",
            "votes": {},
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert signals == []

    def test_state_law_enforcement_bill_caught(self):
        watch = PpbWatch()
        record = {
            "bill_number": "HB 4040",
            "title": "Relating to police accountability and use of force",
            "summary_raw": "",
            "state": "introduced",
            "provenance": _prov(),
        }
        signals = list(watch.extract_signals([record]))
        assert any(s.kind == "bill_affecting_ppb" for s in signals)
