"""Tests for cls_pdx1.explain."""

from __future__ import annotations

from cls_pdx1.explain import ExplainEngine, PLAIN_LANGUAGE_PROMPT_V1


class TestExplainEngine:
    def test_clean_summary_passes_gates(self):
        clean = (
            "WHAT IT DOES: According to the bill text, this measure would require "
            "utilities to file annual wildfire mitigation plans with the Public "
            "Utility Commission.\n"
            "WHO PROPOSED IT: Rep. J. Test proposed the bill.\n"
            "CURRENT STATUS: The measure was referred to committee.\n"
            "PUBLIC INPUT: A public hearing is scheduled."
        )
        engine = ExplainEngine(summarize_fn=lambda _: clean)
        result = engine.summarize(
            document_text="Sample legislative text.",
            cited_source_uris=["https://example.com/source"],
        )
        assert result.passed_gates
        assert result.summary_plain is not None
        assert "PUC" not in result.summary_plain or "Public Utility Commission" in result.summary_plain

    def test_loaded_summary_fails_and_falls_back(self):
        loaded = "The bill clearly admitted what insiders had revealed all along."
        engine = ExplainEngine(summarize_fn=lambda _: loaded, max_retries=0)
        result = engine.summarize(
            document_text="Sample legislative text.",
            cited_source_uris=["https://example.com/source"],
        )
        assert not result.passed_gates
        assert result.summary_plain is None
        assert result.raw_excerpt_fallback is not None
        # gate violations include tone and/or hedging
        violations = " ".join(result.gate_violations)
        assert "tone" in violations or "hedge" in violations

    def test_retry_with_strengthened_constraint(self):
        attempts = []

        def fake_summarize(prompt: str) -> str:
            attempts.append(prompt)
            if len(attempts) == 1:
                # first attempt: loaded
                return "The mayor slammed the bill."
            # second attempt: clean
            return (
                "WHAT IT DOES: According to the filing, the bill would amend the "
                "city code.\nWHO PROPOSED IT: (not stated).\n"
                "CURRENT STATUS: introduced.\nPUBLIC INPUT: (not stated)."
            )

        engine = ExplainEngine(summarize_fn=fake_summarize, max_retries=1)
        result = engine.summarize(
            document_text="x",
            cited_source_uris=["https://example.com/x"],
        )
        assert result.passed_gates
        # second prompt got the retry instruction
        assert "Retry:" in attempts[1]

    def test_prompt_version_propagated(self):
        engine = ExplainEngine(
            summarize_fn=lambda _: "According to the filing, the bill was filed.",
            prompt_version="v1",
        )
        result = engine.summarize(
            document_text="x",
            cited_source_uris=["https://example.com/x"],
        )
        assert result.prompt_version == "v1"

    def test_excerpt_fallback_truncation(self):
        long_text = "x" * 5000
        result = ExplainEngine._excerpt(long_text, max_chars=100)
        assert len(result) <= 100


class TestPromptV1:
    def test_prompt_contains_neutrality_constraints(self):
        # The prompt must list both the neutral verbs and the loaded verbs
        # to make the LLM aware of the constraint.
        assert "Use only neutral verbs" in PLAIN_LANGUAGE_PROMPT_V1
        assert "Do not use" in PLAIN_LANGUAGE_PROMPT_V1
        for verb in ("admitted", "alleged", "slammed", "controversial", "obviously"):
            assert verb in PLAIN_LANGUAGE_PROMPT_V1

    def test_prompt_has_structure_section(self):
        for header in ("WHAT IT DOES", "WHO PROPOSED IT", "CURRENT STATUS", "PUBLIC INPUT"):
            assert header in PLAIN_LANGUAGE_PROMPT_V1

    def test_prompt_has_not_stated_fallback(self):
        assert "(not stated)" in PLAIN_LANGUAGE_PROMPT_V1
