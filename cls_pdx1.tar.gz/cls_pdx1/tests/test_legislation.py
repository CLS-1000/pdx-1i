"""Tests for cls_pdx1.legislation."""

from __future__ import annotations

from datetime import date, datetime

import pytest

from cls_pdx1.legislation import (
    IllegalTransition,
    TERMINAL_STATES,
    apply_transition,
    transition_to_signal,
    validate_transition,
)
from cls_pdx1.models import (
    Bill,
    BillState,
    BillStateTransition,
    Jurisdiction,
    Provenance,
)


def _prov() -> Provenance:
    return Provenance(
        source_uri="https://olis.example/bill",
        source_name="olis",
        fetched_at=datetime.utcnow(),
    )


def _bill(state: BillState = BillState.INTRODUCED) -> Bill:
    return Bill(
        jurisdiction=Jurisdiction.OREGON,
        bill_number="HB 2002",
        title="A test bill",
        introduced_at=date(2025, 1, 14),
        state=state,
        summary_raw="Test summary.",
        provenance=_prov(),
    )


class TestValidateTransition:
    def test_none_to_anything_allowed(self):
        validate_transition(None, BillState.INTRODUCED)
        validate_transition(None, BillState.PASSED_BOTH)
        validate_transition(None, BillState.DEAD)

    def test_same_to_same_allowed(self):
        validate_transition(BillState.COMMITTEE, BillState.COMMITTEE)

    def test_forward_progression_allowed(self):
        validate_transition(BillState.INTRODUCED, BillState.COMMITTEE)
        validate_transition(BillState.COMMITTEE, BillState.COMMITTEE_REPORTED)
        validate_transition(BillState.FLOOR, BillState.PASSED_CHAMBER)

    def test_terminal_state_transitions_blocked(self):
        for terminal in TERMINAL_STATES:
            with pytest.raises(IllegalTransition):
                validate_transition(terminal, BillState.INTRODUCED)

    def test_enacted_to_dead_blocked(self):
        with pytest.raises(IllegalTransition):
            validate_transition(BillState.ENACTED, BillState.DEAD)


class TestApplyTransition:
    def test_transition_appends_to_history(self):
        bill = _bill(state=BillState.INTRODUCED)
        assert len(bill.state_history) == 0

        updated = apply_transition(
            bill=bill,
            to_state=BillState.COMMITTEE,
            occurred_at=datetime(2025, 1, 16),
            provenance=_prov(),
            notes="Referred to Ways and Means",
        )
        assert updated.state == BillState.COMMITTEE
        assert len(updated.state_history) == 1
        assert updated.state_history[0].to_state == BillState.COMMITTEE
        assert updated.state_history[0].from_state == BillState.INTRODUCED

    def test_original_bill_not_mutated(self):
        bill = _bill(state=BillState.INTRODUCED)
        apply_transition(
            bill=bill,
            to_state=BillState.COMMITTEE,
            occurred_at=datetime.utcnow(),
            provenance=_prov(),
        )
        # original still INTRODUCED
        assert bill.state == BillState.INTRODUCED
        assert len(bill.state_history) == 0

    def test_id_preserved_across_transitions(self):
        bill = _bill(state=BillState.INTRODUCED)
        updated = apply_transition(
            bill=bill,
            to_state=BillState.COMMITTEE,
            occurred_at=datetime.utcnow(),
            provenance=_prov(),
        )
        # the Bill record is the same bill — id persists
        assert updated.id == bill.id

    def test_chained_transitions_accumulate_history(self):
        bill = _bill(state=BillState.INTRODUCED)
        b2 = apply_transition(
            bill, BillState.COMMITTEE, datetime.utcnow(), _prov()
        )
        b3 = apply_transition(
            b2, BillState.COMMITTEE_REPORTED, datetime.utcnow(), _prov()
        )
        b4 = apply_transition(
            b3, BillState.PASSED_CHAMBER, datetime.utcnow(), _prov()
        )
        assert len(b4.state_history) == 3
        assert b4.state == BillState.PASSED_CHAMBER

    def test_terminal_transition_blocks_further(self):
        bill = _bill(state=BillState.ENACTED)
        with pytest.raises(IllegalTransition):
            apply_transition(
                bill=bill,
                to_state=BillState.INTRODUCED,
                occurred_at=datetime.utcnow(),
                provenance=_prov(),
            )


class TestTransitionToSignal:
    def test_signal_carries_bill_id(self):
        bill = _bill()
        transition = BillStateTransition(
            from_state=BillState.INTRODUCED,
            to_state=BillState.COMMITTEE,
            occurred_at=datetime(2025, 1, 16),
            provenance=_prov(),
        )
        signal = transition_to_signal(bill, transition)
        assert signal.bill_id == bill.id

    def test_signal_kind_follows_to_state(self):
        bill = _bill()
        transition = BillStateTransition(
            from_state=BillState.COMMITTEE,
            to_state=BillState.ENACTED,
            occurred_at=datetime.utcnow(),
            provenance=_prov(),
        )
        signal = transition_to_signal(bill, transition)
        assert signal.kind == "bill_transition.enacted"

    def test_signal_payload_includes_states(self):
        bill = _bill()
        transition = BillStateTransition(
            from_state=BillState.INTRODUCED,
            to_state=BillState.COMMITTEE,
            occurred_at=datetime.utcnow(),
            provenance=_prov(),
        )
        signal = transition_to_signal(bill, transition)
        assert signal.payload["from_state"] == "introduced"
        assert signal.payload["to_state"] == "committee"

    def test_provenance_propagated(self):
        bill = _bill()
        prov = _prov()
        transition = BillStateTransition(
            from_state=None,
            to_state=BillState.INTRODUCED,
            occurred_at=datetime.utcnow(),
            provenance=prov,
        )
        signal = transition_to_signal(bill, transition)
        assert signal.provenance.source_uri == prov.source_uri
