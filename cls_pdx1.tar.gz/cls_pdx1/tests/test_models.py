"""Tests for cls_pdx1.models."""

from __future__ import annotations

from datetime import date, datetime

import pytest
from pydantic import ValidationError

from cls_pdx1.models import (
    Affiliation,
    Anomaly,
    AnomalyTier,
    Bill,
    BillState,
    BillStateTransition,
    ConfidenceTier,
    DistrictType,
    District,
    EdgeType,
    Entity,
    EntityKind,
    Issue,
    IssueSection,
    Jurisdiction,
    Official,
    Provenance,
    Sector,
    Signal,
    Testimony,
    Vote,
    VotePosition,
)


def _prov(uri: str = "https://example.com/source") -> Provenance:
    return Provenance(
        source_uri=uri,
        source_name="test",
        fetched_at=datetime.utcnow(),
    )


# ---------------------------------------------------------------------------
# Provenance
# ---------------------------------------------------------------------------


class TestProvenance:
    def test_accepts_https_uri(self):
        p = Provenance(
            source_uri="https://example.com/a",
            source_name="ex",
            fetched_at=datetime.utcnow(),
        )
        assert p.source_uri == "https://example.com/a"

    def test_accepts_http_uri(self):
        p = Provenance(
            source_uri="http://example.com/a",
            source_name="ex",
            fetched_at=datetime.utcnow(),
        )
        assert p.source_uri.startswith("http://")

    def test_accepts_file_uri(self):
        p = Provenance(
            source_uri="file:///mnt/x/y.pdf",
            source_name="ex",
            fetched_at=datetime.utcnow(),
        )
        assert p.source_uri.startswith("file://")

    def test_rejects_bare_string(self):
        with pytest.raises(ValidationError):
            Provenance(
                source_uri="not-a-url",
                source_name="ex",
                fetched_at=datetime.utcnow(),
            )

    def test_rejects_empty(self):
        with pytest.raises(ValidationError):
            Provenance(
                source_uri="",
                source_name="ex",
                fetched_at=datetime.utcnow(),
            )


# ---------------------------------------------------------------------------
# District / Official
# ---------------------------------------------------------------------------


class TestOfficial:
    def test_minimal_construction(self):
        o = Official(
            full_name="Test Councilor",
            role="Portland City Councilor",
            jurisdiction=Jurisdiction.PORTLAND,
            term_start=date(2025, 1, 1),
            provenance=_prov(),
        )
        assert o.id  # auto-generated
        assert o.status == "active"
        assert o.aliases == []

    def test_district_link(self):
        d = District(
            name="District 3",
            type=DistrictType.CITY_COUNCIL,
            jurisdiction=Jurisdiction.PORTLAND,
            number="3",
            provenance=_prov(),
        )
        o = Official(
            full_name="Test Councilor",
            role="Portland City Councilor",
            district_id=d.id,
            jurisdiction=Jurisdiction.PORTLAND,
            term_start=date(2025, 1, 1),
            provenance=_prov(),
        )
        assert o.district_id == d.id


# ---------------------------------------------------------------------------
# Entity
# ---------------------------------------------------------------------------


class TestEntity:
    def test_watch_list_entity(self):
        e = Entity(
            canonical_name="Portland General Electric",
            kind=EntityKind.COMPANY,
            sector_tags=[Sector.UTILITY],
            is_watch_listed=True,
            watch_priority=1,
            provenance=_prov(),
        )
        assert e.is_watch_listed is True
        assert e.watch_priority == 1
        assert Sector.UTILITY in e.sector_tags

    def test_non_watch_list_default(self):
        e = Entity(
            canonical_name="Some Vendor LLC",
            kind=EntityKind.COMPANY,
            provenance=_prov(),
        )
        assert e.is_watch_listed is False
        assert e.watch_priority is None


# ---------------------------------------------------------------------------
# Affiliation
# ---------------------------------------------------------------------------


class TestAffiliation:
    def test_donation_record(self):
        a = Affiliation(
            official_id="off-1",
            entity_id="ent-1",
            edge_type=EdgeType.DONATION,
            confidence=ConfidenceTier.HARD_RECORD,
            observed_at=datetime(2025, 5, 1, 12),
            valid_from=date(2025, 5, 1),
            valid_to=date(2025, 5, 1),
            amount_usd=500.00,
            provenance=_prov(),
        )
        assert a.amount_usd == 500.00
        assert a.confidence == ConfidenceTier.HARD_RECORD

    def test_negative_amount_rejected(self):
        with pytest.raises(ValidationError):
            Affiliation(
                official_id="off-1",
                entity_id="ent-1",
                edge_type=EdgeType.DONATION,
                confidence=ConfidenceTier.HARD_RECORD,
                observed_at=datetime.utcnow(),
                valid_from=date.today(),
                amount_usd=-100,
                provenance=_prov(),
            )


# ---------------------------------------------------------------------------
# Bill / Vote / Testimony
# ---------------------------------------------------------------------------


class TestBill:
    def test_bill_state_history(self):
        prov = _prov()
        bill = Bill(
            jurisdiction=Jurisdiction.OREGON,
            bill_number="HB 2002",
            title="Test bill",
            introduced_at=date(2025, 1, 14),
            state=BillState.INTRODUCED,
            summary_raw="A test measure.",
            provenance=prov,
        )
        transition = BillStateTransition(
            from_state=BillState.INTRODUCED,
            to_state=BillState.COMMITTEE,
            occurred_at=datetime(2025, 1, 16),
            provenance=prov,
        )
        updated = bill.model_copy(
            update={"state": BillState.COMMITTEE, "state_history": [transition]}
        )
        assert updated.state == BillState.COMMITTEE
        assert len(updated.state_history) == 1

    def test_vote_record(self):
        v = Vote(
            bill_id="bill-1",
            official_id="off-1",
            position=VotePosition.YEA,
            occurred_at=datetime.utcnow(),
            provenance=_prov(),
        )
        assert v.position == VotePosition.YEA


class TestTestimony:
    def test_testimony_with_affiliation(self):
        t = Testimony(
            bill_id="bill-1",
            witness_name="J. Smith",
            stated_affiliation="Portland General Electric",
            position="for",
            occurred_at=datetime.utcnow(),
            provenance=_prov(),
        )
        assert t.stated_affiliation == "Portland General Electric"
        assert t.matched_entity_id is None  # resolver assigns later


# ---------------------------------------------------------------------------
# Signal / Anomaly
# ---------------------------------------------------------------------------


class TestSignalAnomaly:
    def test_signal_numeric(self):
        s = Signal(
            entity_id="ent-1",
            kind="donation_received",
            occurred_at=datetime.utcnow(),
            detected_at=datetime.utcnow(),
            value=5000.0,
            provenance=_prov(),
        )
        assert s.value == 5000.0

    def test_anomaly_neutral_description(self):
        a = Anomaly(
            entity_id="ent-1",
            tier=AnomalyTier.TIER_1,
            detected_at=datetime.utcnow(),
            kind="donation_spike",
            description="Signal of kind 'donation_received' recorded value 50,000.00 on 2025-05-01.",
            baseline_window_days=90,
            baseline_mean=1000.0,
            baseline_stdev=500.0,
            observed_value=50000.0,
            deviation_sigma=98.0,
            provenance=_prov(),
        )
        assert a.tier == AnomalyTier.TIER_1
        # Description must not contain editorial words
        assert "shocking" not in a.description.lower()
        assert "admitted" not in a.description.lower()


# ---------------------------------------------------------------------------
# Issue / IssueSection
# ---------------------------------------------------------------------------


class TestIssue:
    def test_issue_minimal(self):
        section = IssueSection(
            heading="Council vote on PPB budget",
            body="The Portland City Council voted 3-2 on the proposed PPB budget amendment.",
            cited_source_uris=["https://example.com/vote"],
        )
        issue = Issue(
            issue_number=1,
            published_at=datetime.utcnow(),
            trigger_signal_ids=["sig-1"],
            sections=[section],
            provenance=_prov(),
        )
        assert issue.issue_number == 1
        assert len(issue.sections) == 1
