"""Tests for cls_pdx1.publication (issue assembly + diagram)."""

from __future__ import annotations

from datetime import date, datetime

import pytest

from cls_pdx1.models import (
    Affiliation,
    Anomaly,
    AnomalyTier,
    ConfidenceTier,
    District,
    DistrictType,
    EdgeType,
    Entity,
    EntityKind,
    Jurisdiction,
    Official,
    Provenance,
    Sector,
    Signal,
)
from cls_pdx1.publication import (
    IssueAssemblyError,
    IssueBuilder,
    SectionGateFailure,
    render_issue_markdown,
)
from cls_pdx1.publication.diagram import (
    DiagramSnapshot,
    EDGE_WEIGHT_BY_TIER,
    build_snapshot,
)


def _prov(uri: str = "https://example.com/source") -> Provenance:
    return Provenance(
        source_uri=uri,
        source_name="test",
        fetched_at=datetime.utcnow(),
    )


# ---------------------------------------------------------------------------
# IssueBuilder
# ---------------------------------------------------------------------------


class TestIssueBuilder:
    def _builder(self) -> IssueBuilder:
        return IssueBuilder(
            issue_number=1,
            trigger_signals=[],
            trigger_anomalies=[],
        )

    def test_clean_section_added(self):
        b = self._builder()
        b.add_section(
            heading="Council vote on PPB budget",
            body=(
                "According to the published agenda, the Portland City Council "
                "voted 3-2 on the proposed amendment."
            ),
            cited_source_uris=["https://example.com/agenda"],
        )
        issue = b.build(provenance=_prov())
        assert issue.issue_number == 1
        assert len(issue.sections) == 1

    def test_loaded_verb_rejected_at_assembly(self):
        b = self._builder()
        with pytest.raises(SectionGateFailure):
            b.add_section(
                heading="Council vote",
                body="The mayor admitted the plan was incomplete.",
                cited_source_uris=["https://example.com/x"],
            )

    def test_section_without_sources_rejected(self):
        b = self._builder()
        with pytest.raises(IssueAssemblyError):
            b.add_section(
                heading="Council vote",
                body=(
                    "According to the agenda, the council voted on the amendment."
                ),
                cited_source_uris=[],
            )

    def test_empty_issue_rejected(self):
        b = self._builder()
        with pytest.raises(IssueAssemblyError):
            b.build(provenance=_prov())

    def test_correction_issue_tracks_original(self):
        b = IssueBuilder(
            issue_number=2,
            trigger_signals=[],
            trigger_anomalies=[],
            correction_of_issue_id="abc-123",
        )
        b.add_section(
            heading="Correction",
            body="According to the corrected record, the vote was 4-1, not 3-2.",
            cited_source_uris=["https://example.com/corrected"],
        )
        issue = b.build(provenance=_prov())
        assert issue.correction_of_issue_id == "abc-123"


# ---------------------------------------------------------------------------
# Markdown rendering
# ---------------------------------------------------------------------------


class TestRenderIssueMarkdown:
    def test_includes_issue_number(self):
        b = IssueBuilder(issue_number=7, trigger_signals=[], trigger_anomalies=[])
        b.add_section(
            "Test",
            "According to the record, the vote occurred.",
            ["https://example.com/x"],
        )
        issue = b.build(provenance=_prov())
        md = render_issue_markdown(issue)
        assert "Metro Citizens Brief" in md
        assert "Issue 7" in md

    def test_includes_sources(self):
        b = IssueBuilder(issue_number=1, trigger_signals=[], trigger_anomalies=[])
        b.add_section(
            "Test",
            "According to the record, the vote occurred.",
            ["https://example.com/source1", "https://example.com/source2"],
        )
        issue = b.build(provenance=_prov())
        md = render_issue_markdown(issue)
        assert "https://example.com/source1" in md
        assert "https://example.com/source2" in md

    def test_correction_notice_rendered(self):
        b = IssueBuilder(
            issue_number=2,
            trigger_signals=[],
            trigger_anomalies=[],
            correction_of_issue_id="prev-id",
        )
        b.add_section(
            "Correction",
            "According to the corrected record, the vote was 4-1.",
            ["https://example.com/x"],
        )
        issue = b.build(provenance=_prov())
        md = render_issue_markdown(issue)
        assert "corrects" in md.lower() or "correction" in md.lower()


# ---------------------------------------------------------------------------
# Diagram snapshot
# ---------------------------------------------------------------------------


class TestDiagramSnapshot:
    def _seed(self) -> tuple:
        prov = _prov()
        district = District(
            name="District 3",
            type=DistrictType.CITY_COUNCIL,
            jurisdiction=Jurisdiction.PORTLAND,
            number="3",
            provenance=prov,
        )
        official = Official(
            full_name="J. Test",
            role="Portland City Councilor",
            district_id=district.id,
            jurisdiction=Jurisdiction.PORTLAND,
            term_start=date(2025, 1, 1),
            provenance=prov,
        )
        entity_watch = Entity(
            canonical_name="Portland General Electric",
            kind=EntityKind.COMPANY,
            sector_tags=[Sector.UTILITY],
            is_watch_listed=True,
            watch_priority=1,
            provenance=prov,
        )
        entity_other = Entity(
            canonical_name="Acme Vendor",
            kind=EntityKind.COMPANY,
            provenance=prov,
        )
        affiliation = Affiliation(
            official_id=official.id,
            entity_id=entity_watch.id,
            edge_type=EdgeType.DONATION,
            confidence=ConfidenceTier.HARD_RECORD,
            observed_at=datetime(2025, 5, 1),
            valid_from=date(2025, 5, 1),
            valid_to=date(2025, 5, 1),
            amount_usd=500.0,
            provenance=prov,
        )
        return district, official, entity_watch, entity_other, affiliation

    def test_snapshot_contains_all_node_kinds(self):
        d, o, e1, e2, a = self._seed()
        snap = build_snapshot(
            officials=[o],
            entities=[e1, e2],
            affiliations=[a],
            districts=[d],
        )
        kinds = {n["kind"] for n in snap.nodes}
        assert "official" in kinds
        assert "entity" in kinds
        assert "district" in kinds

    def test_watch_listed_node_larger(self):
        d, o, e1, e2, a = self._seed()
        snap = build_snapshot(
            officials=[o],
            entities=[e1, e2],
            affiliations=[a],
            districts=[d],
        )
        watch_size = next(n["size"] for n in snap.nodes if n["watch_listed"])
        normal_size = next(
            n["size"] for n in snap.nodes if n["kind"] == "entity" and not n["watch_listed"]
        )
        assert watch_size > normal_size

    def test_affiliation_link_present(self):
        d, o, e1, e2, a = self._seed()
        snap = build_snapshot(
            officials=[o],
            entities=[e1, e2],
            affiliations=[a],
            districts=[d],
        )
        donation_links = [l for l in snap.links if l["edge_type"] == "donation"]
        assert len(donation_links) == 1
        link = donation_links[0]
        assert link["amount_usd"] == 500.0
        assert link["confidence"] == 1

    def test_district_membership_link(self):
        d, o, e1, e2, a = self._seed()
        snap = build_snapshot(
            officials=[o],
            entities=[e1, e2],
            affiliations=[a],
            districts=[d],
        )
        represents = [l for l in snap.links if l["edge_type"] == "represents"]
        assert len(represents) == 1

    def test_snapshot_id_deterministic(self):
        d, o, e1, e2, a = self._seed()
        snap_a = build_snapshot(
            officials=[o], entities=[e1, e2], affiliations=[a], districts=[d],
            now=datetime(2025, 5, 21, 12),
        )
        snap_b = build_snapshot(
            officials=[o], entities=[e1, e2], affiliations=[a], districts=[d],
            now=datetime(2025, 5, 21, 12),
        )
        # Same content -> same id (content-addressable)
        assert snap_a.snapshot_id == snap_b.snapshot_id

    def test_orphan_affiliation_skipped(self):
        d, o, e1, e2, a = self._seed()
        # Build a separate affiliation pointing at non-existent ids
        orphan = Affiliation(
            official_id="nope-1",
            entity_id="nope-2",
            edge_type=EdgeType.DONATION,
            confidence=ConfidenceTier.HARD_RECORD,
            observed_at=datetime.utcnow(),
            valid_from=date.today(),
            provenance=_prov(),
        )
        snap = build_snapshot(
            officials=[o], entities=[e1, e2], affiliations=[a, orphan], districts=[d],
        )
        # Orphan dropped, only the real one present
        donation_links = [l for l in snap.links if l["edge_type"] == "donation"]
        assert len(donation_links) == 1

    def test_serializes_to_json(self):
        d, o, e1, e2, a = self._seed()
        snap = build_snapshot(
            officials=[o], entities=[e1, e2], affiliations=[a], districts=[d],
        )
        j = snap.to_json()
        assert "snapshot_id" in j
        assert "nodes" in j
        assert "links" in j

    def test_edge_weight_by_tier_descending(self):
        # Higher confidence -> heavier weight
        assert EDGE_WEIGHT_BY_TIER[1] > EDGE_WEIGHT_BY_TIER[2]
        assert EDGE_WEIGHT_BY_TIER[2] > EDGE_WEIGHT_BY_TIER[3]
        assert EDGE_WEIGHT_BY_TIER[3] > EDGE_WEIGHT_BY_TIER[4]
