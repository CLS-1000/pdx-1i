"""Tests for the Grok-sourced supplementary data integration.

Covers:
  - The 3 new officials (Wang, Schmautz, Hoan)
  - The 5 new entities (CCC, SEIU 49, Hacienda CDC, Don't Shoot PDX, PPS)
  - The 1 new district (PPS Board)
  - x_handles.json — its 2 verified handles + 25 documented absences
  - verification_refs.yaml — citation pool format
  - media_coverage_patterns.jsonl — relabeled framing data
"""

from __future__ import annotations

import pytest

from cls_pdx1.data import (
    load_all,
    load_media_coverage_patterns,
    load_verification_refs,
    load_x_handles,
)
from cls_pdx1.models import EntityKind, Jurisdiction, Sector


# ---------------------------------------------------------------------------
# New seed records (from Grok v2 portland_nodes.json — the keepers)
# ---------------------------------------------------------------------------


class TestNewOfficials:
    def test_eddie_wang_present(self):
        bundle, _ = load_all()
        wang = next(
            (o for o in bundle.officials if o.id == "off:portland:eddie-wang"),
            None,
        )
        assert wang is not None
        assert "Wang" in wang.full_name
        assert "Portland Public Schools" in wang.role
        assert wang.district_id == "dist:portland:pps-board"

    def test_aaron_schmautz_present(self):
        bundle, _ = load_all()
        schmautz = next(
            (o for o in bundle.officials if o.id == "off:portland:aaron-schmautz"),
            None,
        )
        assert schmautz is not None
        assert "Portland Police Association" in schmautz.role

    def test_andrew_hoan_present(self):
        bundle, _ = load_all()
        hoan = next(
            (o for o in bundle.officials if o.id == "off:portland:andrew-hoan"),
            None,
        )
        assert hoan is not None
        assert "Portland Metro Chamber" in hoan.role

    def test_pps_board_district_present(self):
        bundle, _ = load_all()
        pps_dist = next(
            (d for d in bundle.districts if d.id == "dist:portland:pps-board"),
            None,
        )
        assert pps_dist is not None
        assert pps_dist.jurisdiction == Jurisdiction.PORTLAND


class TestNewEntities:
    def test_central_city_concern(self):
        bundle, _ = load_all()
        ccc = next(
            (e for e in bundle.entities if e.id == "ent:central-city-concern"),
            None,
        )
        assert ccc is not None
        assert ccc.kind == EntityKind.NONPROFIT

    def test_seiu_49(self):
        bundle, _ = load_all()
        seiu = next(
            (e for e in bundle.entities if e.id == "ent:seiu-49"),
            None,
        )
        assert seiu is not None
        assert seiu.kind == EntityKind.UNION
        assert Sector.LABOR in seiu.sector_tags

    def test_seiu_49_distinct_from_seiu_503(self):
        bundle, _ = load_all()
        ids = {e.id for e in bundle.entities}
        # Both should be present and distinct
        assert "ent:seiu-49" in ids
        assert "ent:seiu-503" in ids

    def test_hacienda_cdc(self):
        bundle, _ = load_all()
        hac = next(
            (e for e in bundle.entities if e.id == "ent:hacienda-cdc"),
            None,
        )
        assert hac is not None

    def test_dont_shoot_pdx(self):
        bundle, _ = load_all()
        dsp = next(
            (e for e in bundle.entities if e.id == "ent:dont-shoot-pdx"),
            None,
        )
        assert dsp is not None
        assert dsp.kind == EntityKind.NONPROFIT

    def test_pps_entity(self):
        bundle, _ = load_all()
        pps = next(
            (e for e in bundle.entities if e.id == "ent:pps"),
            None,
        )
        assert pps is not None
        assert pps.kind == EntityKind.AGENCY


# ---------------------------------------------------------------------------
# x_handles.json
# ---------------------------------------------------------------------------


class TestXHandles:
    def test_loads_without_error(self):
        data = load_x_handles()
        assert "records" in data
        assert "documented_absences" in data

    def test_mayor_wilson_handle(self):
        data = load_x_handles()
        wilson = next(
            (r for r in data["records"]
             if r["node_id"] == "off:portland:keith-wilson"),
            None,
        )
        assert wilson is not None
        assert wilson["x_handle"] == "@MayorKWilson"
        # Caveat must be present — handle is stale
        assert wilson["status"] == "needs_verification"

    def test_kanal_handle_marked_superseded(self):
        data = load_x_handles()
        kanal = next(
            (r for r in data["records"]
             if r["node_id"] == "off:portland:sameer-kanal"),
            None,
        )
        assert kanal is not None
        assert kanal["status"] == "superseded"
        assert kanal["superseded_by"] == "@CouncilorKanal"

    def test_documented_absences_have_node_ids(self):
        data = load_x_handles()
        # Every documented absence should carry a node_id and verified_at
        for absence in data["documented_absences"]:
            assert "node_id" in absence
            assert "verified_at" in absence

    def test_warnings_present(self):
        data = load_x_handles()
        assert "warnings" in data
        assert len(data["warnings"]) > 0

    def test_handle_node_ids_resolve_to_real_officials(self):
        """The node_ids referenced by x_handles must exist in the seed."""
        data = load_x_handles()
        bundle, _ = load_all()
        official_ids = bundle.official_ids

        for rec in data["records"]:
            assert rec["node_id"] in official_ids, (
                f"x_handles record references unknown official: {rec['node_id']}"
            )
        for absence in data["documented_absences"]:
            assert absence["node_id"] in official_ids, (
                f"x_handles absence references unknown official: {absence['node_id']}"
            )


# ---------------------------------------------------------------------------
# verification_refs.yaml
# ---------------------------------------------------------------------------


class TestVerificationRefs:
    @pytest.fixture(autouse=True)
    def _skip_if_no_yaml(self):
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed")

    def test_loads_without_error(self):
        data = load_verification_refs()
        assert isinstance(data, dict)
        assert "records" in data

    def test_has_records(self):
        data = load_verification_refs()
        assert len(data["records"]) > 0

    def test_all_records_have_verified_excerpt(self):
        """Every citation record must carry a verified excerpt (the rule that
        forced Grok to actually fetch rather than fabricate)."""
        data = load_verification_refs()
        for rec in data["records"]:
            assert rec.get("verified_excerpt"), (
                f"Citation {rec.get('id')} missing verified_excerpt"
            )
            assert rec.get("url"), f"Citation {rec.get('id')} missing url"
            assert rec["url"].startswith("https://"), (
                f"Citation {rec.get('id')} has non-https url"
            )

    def test_referenced_officials_resolve_to_seed(self):
        """Officials cited in references should exist in the seed."""
        data = load_verification_refs()
        bundle, _ = load_all()
        official_ids = bundle.official_ids

        unknown = []
        for rec in data["records"]:
            for off_id in rec.get("references_officials", []) or []:
                if off_id not in official_ids:
                    unknown.append((rec.get("id"), off_id))
        assert not unknown, f"References to unknown officials: {unknown}"


# ---------------------------------------------------------------------------
# media_coverage_patterns.jsonl
# ---------------------------------------------------------------------------


class TestMediaCoveragePatterns:
    def test_loads_without_error(self):
        clusters = load_media_coverage_patterns()
        assert isinstance(clusters, list)
        assert len(clusters) > 0

    def test_header_skipped(self):
        clusters = load_media_coverage_patterns()
        # First record should be a cluster, not the _header
        assert "_header" not in clusters[0]
        assert "cluster_id" in clusters[0]

    def test_relabeling_metadata_preserved(self):
        clusters = load_media_coverage_patterns()
        # Each cluster should carry the original Grok signature for audit
        for c in clusters:
            assert "_grok_original_signature" in c, (
                f"Cluster {c.get('cluster_id')} missing _grok_original_signature"
            )
            assert "_relabeling_note" in c, (
                f"Cluster {c.get('cluster_id')} missing _relabeling_note"
            )

    def test_no_clusters_claim_psyop_label(self):
        """The relabeling rule: the file must not present these as confirmed
        PSYOP. Each cluster's `pattern` field must use the framing-convergence
        vocabulary, not the original five PSYOP signatures."""
        clusters = load_media_coverage_patterns()
        psyop_signatures = {
            "coordinated_inauthentic_amplification",
            "astroturf_grassroots",
            "narrative_laundering",
            "whataboutism_pivot",
            "manufactured_consensus",
        }
        for c in clusters:
            # The 'pattern' field replaces the original 'signature' field
            assert c.get("pattern") not in psyop_signatures, (
                f"Cluster {c.get('cluster_id')} still uses PSYOP signature "
                f"as its primary label — should be relabeled"
            )

    def test_x_status_ids_are_19_digits(self):
        """Real X status IDs are 19-digit snowflakes. Verifies the v2
        anti-fabrication guardrail held in the data we kept."""
        clusters = load_media_coverage_patterns()
        for c in clusters:
            for post in c.get("example_posts", []):
                sid = post.get("status_id", "")
                assert sid.isdigit(), f"Non-digit status_id: {sid}"
                assert len(sid) == 19, (
                    f"Status ID is {len(sid)} digits, expected 19: {sid}"
                )


# ---------------------------------------------------------------------------
# Cross-file integrity — the integration as a whole
# ---------------------------------------------------------------------------


class TestIntegrationIntegrity:
    def test_seed_grew_by_expected_count(self):
        """After Grok artifact merge: 60 officials (was 57), 22 entities
        (was 17), 41 districts (was 40)."""
        bundle, _ = load_all()
        assert len(bundle.officials) >= 60
        assert len(bundle.entities) >= 22
        assert len(bundle.districts) >= 41

    def test_no_orphan_district_refs_after_merge(self):
        _, report = load_all()
        assert report.orphan_district_refs == []

    def test_seed_still_passes_all_gates(self):
        from cls_pdx1.data import verify_seed
        report = verify_seed()
        assert report.total_failures == 0, report.summary()
