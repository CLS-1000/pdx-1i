"""Tests for cls_pdx1.neutrality."""

from __future__ import annotations

from cls_pdx1.neutrality import (
    HEDGING_TERMS,
    LOADED_VERBS,
    NEUTRAL_VERBS,
    attribution_gate,
    hedging_gate,
    section_neutrality_gate,
    tone_gate,
)


# ---------------------------------------------------------------------------
# Tone gate
# ---------------------------------------------------------------------------


class TestToneGate:
    def test_empty_text_passes(self):
        ok, viol = tone_gate("")
        assert ok
        assert viol == []

    def test_neutral_prose_passes(self):
        text = "The Portland City Council voted 3-2 on the proposed budget amendment."
        ok, viol = tone_gate(text)
        assert ok
        assert viol == []

    def test_loaded_verb_caught(self):
        text = "The mayor admitted that the plan was incomplete."
        ok, viol = tone_gate(text)
        assert not ok
        assert "admitted" in viol

    def test_multiple_loaded_verbs_caught(self):
        text = "The councilor slammed the plan, then doubled down."
        ok, viol = tone_gate(text)
        assert not ok
        assert "slammed" in viol
        assert "doubled down" in viol

    def test_word_boundary_match(self):
        # 'denied' is loaded, but 'denied-list' shouldn't false-positive
        # via substring. We only check single-token word-boundary forms.
        text = "He denied the request."
        ok, viol = tone_gate(text)
        assert not ok
        assert "denied" in viol

    def test_partial_word_not_caught(self):
        # 'slamming' shouldn't trigger 'slammed' because we use word boundaries
        text = "The door was slamming all night."
        ok, viol = tone_gate(text)
        # "slamming" doesn't match "slammed" with \b
        assert ok or "slammed" not in viol

    def test_case_insensitive(self):
        text = "He SLAMMED the proposal."
        ok, viol = tone_gate(text)
        assert not ok
        assert "slammed" in viol


# ---------------------------------------------------------------------------
# Hedging gate
# ---------------------------------------------------------------------------


class TestHedgingGate:
    def test_neutral_prose_passes(self):
        text = "The proposal received a vote of 4-1."
        ok, viol = hedging_gate(text)
        assert ok

    def test_hedging_terms_caught(self):
        text = "Clearly, the decision was controversial."
        ok, viol = hedging_gate(text)
        assert not ok
        assert "clearly" in viol
        assert "controversial" in viol

    def test_obviously_caught(self):
        text = "The result obviously favored the incumbent."
        ok, viol = hedging_gate(text)
        assert not ok
        assert "obviously" in viol


# ---------------------------------------------------------------------------
# Attribution gate
# ---------------------------------------------------------------------------


class TestAttributionGate:
    def test_passes_with_source_and_marker(self):
        text = "According to the filing, the budget was approved."
        ok, reason = attribution_gate(text, has_source_uri=True)
        assert ok

    def test_passes_with_said_marker(self):
        text = "The mayor said the plan is moving forward."
        ok, reason = attribution_gate(text, has_source_uri=True)
        assert ok

    def test_fails_no_marker_with_source(self):
        text = "The budget was approved."
        ok, reason = attribution_gate(text, has_source_uri=True)
        assert not ok
        assert "ATTR_001" in (reason or "")

    def test_fails_marker_without_source(self):
        text = "The mayor said the plan is moving forward."
        ok, reason = attribution_gate(text, has_source_uri=False)
        assert not ok
        assert "ATTR_002" in (reason or "")

    def test_fails_both_missing(self):
        text = "The plan is moving forward."
        ok, reason = attribution_gate(text, has_source_uri=False)
        assert not ok

    def test_empty_text_passes(self):
        ok, reason = attribution_gate("", has_source_uri=False)
        assert ok


# ---------------------------------------------------------------------------
# Section composite
# ---------------------------------------------------------------------------


class TestSectionNeutralityGate:
    def test_clean_section_passes(self):
        body = (
            "According to the city auditor's filing, the council approved the budget "
            "amendment on a 3-2 vote."
        )
        sources = ["https://example.com/filing"]
        ok, viol = section_neutrality_gate(body, sources)
        assert ok
        assert viol == []

    def test_failures_collected(self):
        body = "The mayor admitted the controversial plan."
        sources = ["https://example.com/x"]
        ok, viol = section_neutrality_gate(body, sources)
        assert not ok
        # Should collect tone, hedging, attribution failures
        assert any("tone" in v for v in viol)
        assert any("hedge" in v for v in viol)
        # No attribution marker -> attr failure
        assert any("attr" in v for v in viol)


# ---------------------------------------------------------------------------
# Vocabulary invariants
# ---------------------------------------------------------------------------


class TestVocabularyInvariants:
    def test_loaded_and_neutral_disjoint(self):
        overlap = LOADED_VERBS & NEUTRAL_VERBS
        assert overlap == set(), f"Verbs cannot be both loaded and neutral: {overlap}"

    def test_loaded_verbs_includes_known_problems(self):
        # If these slip into output, the brief loses neutrality immediately
        must_include = {"admitted", "claimed", "denied", "slammed", "revealed"}
        assert must_include <= LOADED_VERBS

    def test_neutral_verbs_includes_required_actions(self):
        # The verbs the brief actually needs to do its job
        must_include = {"said", "voted", "proposed", "filed", "testified", "approved"}
        assert must_include <= NEUTRAL_VERBS

    def test_hedging_terms_non_empty(self):
        assert len(HEDGING_TERMS) > 0
