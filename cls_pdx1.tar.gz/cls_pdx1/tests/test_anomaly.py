"""Tests for cls_pdx1.anomaly."""

from __future__ import annotations

from datetime import datetime, timedelta

from cls_pdx1.anomaly import (
    AnomalyDetector,
    RollingBaseline,
    SIGMA_TIER_THRESHOLDS,
    sigma_to_tier,
)
from cls_pdx1.models import AnomalyTier, Provenance, Signal


def _prov(uri: str = "https://example.com/x") -> Provenance:
    return Provenance(
        source_uri=uri,
        source_name="test",
        fetched_at=datetime.utcnow(),
    )


def _signal(value: float, entity_id: str = "ent-1", kind: str = "donation_made",
            occurred_at: datetime = None) -> Signal:
    return Signal(
        entity_id=entity_id,
        kind=kind,
        occurred_at=occurred_at or datetime.utcnow(),
        detected_at=occurred_at or datetime.utcnow(),
        value=value,
        provenance=_prov(),
    )


# ---------------------------------------------------------------------------
# sigma_to_tier
# ---------------------------------------------------------------------------


class TestSigmaToTier:
    def test_tier_1_above_3_sigma(self):
        assert sigma_to_tier(3.5) == AnomalyTier.TIER_1
        assert sigma_to_tier(-4.0) == AnomalyTier.TIER_1

    def test_tier_2_between_2_and_3_sigma(self):
        assert sigma_to_tier(2.5) == AnomalyTier.TIER_2
        assert sigma_to_tier(-2.1) == AnomalyTier.TIER_2

    def test_tier_3_between_1_and_2_sigma(self):
        assert sigma_to_tier(1.5) == AnomalyTier.TIER_3
        assert sigma_to_tier(-1.0) == AnomalyTier.TIER_3

    def test_tier_4_below_1_sigma(self):
        assert sigma_to_tier(0.5) == AnomalyTier.TIER_4
        assert sigma_to_tier(0.0) == AnomalyTier.TIER_4

    def test_thresholds_descending(self):
        thresholds = [t for t, _ in SIGMA_TIER_THRESHOLDS]
        assert thresholds == sorted(thresholds, reverse=True)


# ---------------------------------------------------------------------------
# RollingBaseline
# ---------------------------------------------------------------------------


class TestRollingBaseline:
    def test_empty_baseline_returns_zero(self):
        b = RollingBaseline(window=timedelta(days=90))
        n, mean, std = b.stats(now=datetime.utcnow())
        assert n == 0
        assert mean == 0.0
        assert std == 0.0

    def test_single_sample(self):
        b = RollingBaseline(window=timedelta(days=90))
        b.add(datetime.utcnow(), 100.0)
        n, mean, std = b.stats(now=datetime.utcnow())
        assert n == 1
        assert mean == 100.0
        assert std == 0.0  # no variance with one sample

    def test_mean_and_stdev(self):
        b = RollingBaseline(window=timedelta(days=90))
        now = datetime.utcnow()
        for v in (10, 20, 30, 40, 50):
            b.add(now, float(v))
        n, mean, std = b.stats(now=now)
        assert n == 5
        assert mean == 30.0
        assert std > 0

    def test_window_trim(self):
        b = RollingBaseline(window=timedelta(days=10))
        now = datetime.utcnow()
        b.add(now - timedelta(days=30), 100.0)
        b.add(now - timedelta(days=5), 200.0)
        n, mean, _ = b.stats(now=now)
        assert n == 1
        assert mean == 200.0


# ---------------------------------------------------------------------------
# AnomalyDetector
# ---------------------------------------------------------------------------


class TestAnomalyDetector:
    def test_insufficient_baseline_returns_none(self):
        det = AnomalyDetector(min_samples_for_detection=10)
        result = det.update(_signal(1000.0))
        assert result is None

    def test_signal_without_entity_id_skipped(self):
        det = AnomalyDetector()
        s = Signal(
            kind="x",
            occurred_at=datetime.utcnow(),
            detected_at=datetime.utcnow(),
            value=1.0,
            provenance=_prov(),
        )
        result = det.update(s)
        assert result is None

    def test_signal_without_value_skipped(self):
        det = AnomalyDetector()
        s = Signal(
            entity_id="ent-1",
            kind="bill_affecting_pge",
            occurred_at=datetime.utcnow(),
            detected_at=datetime.utcnow(),
            value=None,
            provenance=_prov(),
        )
        result = det.update(s)
        assert result is None

    def test_three_sigma_spike_caught_as_tier_1(self):
        det = AnomalyDetector(min_samples_for_detection=10, window_days=365)
        now = datetime.utcnow()
        # Build a stable baseline at ~1000
        for i in range(20):
            sig = _signal(
                value=1000.0 + (i % 5) * 10,  # small variance
                occurred_at=now - timedelta(days=20 - i),
            )
            det.update(sig)
        # Big spike
        spike = _signal(value=100_000.0, occurred_at=now)
        anomaly = det.update(spike)
        assert anomaly is not None
        assert anomaly.tier == AnomalyTier.TIER_1
        assert anomaly.deviation_sigma is not None
        assert anomaly.deviation_sigma > 3

    def test_below_threshold_returns_none(self):
        det = AnomalyDetector(min_samples_for_detection=5, window_days=365)
        now = datetime.utcnow()
        for i in range(10):
            det.update(_signal(value=1000.0, occurred_at=now - timedelta(days=10 - i)))
        # Identical to baseline = 0 sigma
        result = det.update(_signal(value=1000.0, occurred_at=now))
        # With stdev=0, _baseline.stats returns stdev=0, which triggers the
        # degenerate-baseline guard and returns None.
        assert result is None

    def test_neutral_description_format(self):
        det = AnomalyDetector(min_samples_for_detection=5, window_days=365)
        now = datetime.utcnow()
        for i in range(10):
            det.update(_signal(
                value=100.0 + i,  # gives stdev > 0
                occurred_at=now - timedelta(days=10 - i),
            ))
        spike = _signal(value=10_000.0, occurred_at=now)
        anomaly = det.update(spike)
        assert anomaly is not None
        desc = anomaly.description.lower()
        # Must not contain loaded language
        for term in ("admitted", "shocking", "scandalous", "alarming", "controversial"):
            assert term not in desc
        # Must contain the structural elements
        assert "sigma" in desc
        assert "rolling mean" in desc

    def test_feed_processes_batch(self):
        det = AnomalyDetector(min_samples_for_detection=5, window_days=365)
        now = datetime.utcnow()
        signals = [
            _signal(value=100.0 + i, occurred_at=now - timedelta(days=10 - i))
            for i in range(10)
        ]
        # Add one big spike at the end
        signals.append(_signal(value=10_000.0, occurred_at=now))
        anomalies = det.feed(signals)
        # Only the spike should be tier-1/2; earlier signals built baseline
        assert any(a.tier in (AnomalyTier.TIER_1, AnomalyTier.TIER_2) for a in anomalies)

    def test_baseline_isolated_per_entity_and_kind(self):
        det = AnomalyDetector(min_samples_for_detection=5, window_days=365)
        now = datetime.utcnow()
        # Build baseline for entity A
        for i in range(10):
            det.update(_signal(
                value=100.0 + i,
                entity_id="ent-A",
                kind="donation",
                occurred_at=now - timedelta(days=10 - i),
            ))
        # New entity B with one signal — baseline empty, no anomaly emitted
        result = det.update(_signal(
            value=10_000.0,
            entity_id="ent-B",
            kind="donation",
            occurred_at=now,
        ))
        assert result is None
