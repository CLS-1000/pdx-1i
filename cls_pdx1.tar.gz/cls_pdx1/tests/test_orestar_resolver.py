"""Tests for ORESTAR helper functions: build_search_url, verify_csv,
enrich_with_resolvers (the resolver integration).

This is where the seed data and the resolver actually meet the ORESTAR
pipeline. The end-to-end flow tested here:

    raw CSV -> adapter -> pre-resolution Affiliation
    -> enrich_with_resolvers -> bound Affiliation (entity_id + official_id)
"""

from __future__ import annotations

import csv
import tempfile
from datetime import datetime

import pytest

from cls_pdx1.data import load_all
from cls_pdx1.models import ConfidenceTier, EdgeType, Provenance
from cls_pdx1.resolver import EntityResolver, OfficialResolver
from cls_pdx1.sources.orestar import (
    EXPECTED_CSV_COLUMNS,
    OrestarAdapter,
    ORESTAR_TRANSACTION_SEARCH,
    build_search_url,
    enrich_with_resolvers,
    verify_csv,
)


# ---------------------------------------------------------------------------
# build_search_url
# ---------------------------------------------------------------------------


class TestBuildSearchUrl:
    def test_no_args_returns_base(self):
        assert build_search_url() == ORESTAR_TRANSACTION_SEARCH

    def test_contributor_added(self):
        url = build_search_url(contributor="Portland General Electric")
        assert "contributor_name=" in url
        assert "Portland" in url

    def test_committee_added(self):
        url = build_search_url(committee="Friends of Smith")
        assert "committee_name=" in url

    def test_date_range_added(self):
        url = build_search_url(start_date="2026-01-01", end_date="2026-05-21")
        assert "start_date=" in url
        assert "end_date=" in url

    def test_url_well_formed(self):
        url = build_search_url(contributor="Acme")
        assert url.startswith("https://")


# ---------------------------------------------------------------------------
# verify_csv
# ---------------------------------------------------------------------------


class TestVerifyCsv:
    def test_missing_file(self):
        ok, problems = verify_csv("/tmp/__does_not_exist__.csv")
        assert not ok
        assert "not found" in " ".join(problems).lower()

    def test_empty_file(self):
        with tempfile.NamedTemporaryFile(
            "w", suffix=".csv", delete=False
        ) as f:
            tmp = f.name
        ok, problems = verify_csv(tmp)
        assert not ok

    def test_valid_csv(self):
        with tempfile.NamedTemporaryFile(
            "w", suffix=".csv", delete=False, newline=""
        ) as f:
            w = csv.writer(f)
            w.writerow(["tran_id", "tran_date", "amount", "contributor", "committee"])
            w.writerow(["T-1", "2026-05-01", "500", "PGE", "Friends of Smith"])
            tmp = f.name
        ok, problems = verify_csv(tmp)
        assert ok, problems

    def test_missing_columns(self):
        with tempfile.NamedTemporaryFile(
            "w", suffix=".csv", delete=False, newline=""
        ) as f:
            w = csv.writer(f)
            w.writerow(["tran_id", "amount"])  # Missing date, contributor, committee
            w.writerow(["T-1", "500"])
            tmp = f.name
        ok, problems = verify_csv(tmp)
        assert not ok
        assert "missing expected columns" in " ".join(problems)

    def test_canonical_columns_documented(self):
        # The constant must list at minimum the fields verify_csv enforces
        assert "tran_id" in EXPECTED_CSV_COLUMNS
        assert "tran_date" in EXPECTED_CSV_COLUMNS
        assert "amount" in EXPECTED_CSV_COLUMNS
        assert "contributor" in EXPECTED_CSV_COLUMNS
        assert "committee" in EXPECTED_CSV_COLUMNS


# ---------------------------------------------------------------------------
# Resolver enrichment — the end-to-end binding
# ---------------------------------------------------------------------------


def _prov() -> Provenance:
    return Provenance(
        source_uri="https://example.com/orestar/T-1",
        source_name="orestar",
        fetched_at=datetime.utcnow(),
    )


def _pre_resolution_record(
    contributor: str = "Portland General Electric Company",
    committee: str = "Friends of Keith Wilson",
    amount: float = 500.0,
) -> dict:
    """Build a pre-resolution Affiliation record (the shape OrestarAdapter._normalize emits)."""
    return {
        "edge_type": EdgeType.DONATION,
        "confidence": ConfidenceTier.HARD_RECORD,
        "observed_at": datetime(2026, 5, 1, 12),
        "valid_from": datetime(2026, 5, 1).date(),
        "valid_to": datetime(2026, 5, 1).date(),
        "amount_usd": amount,
        "description": f"Donation of ${amount:,.2f}",
        "metadata": {
            "contributor_name_raw": contributor,
            "committee_name_raw": committee,
            "tran_id": "T-1",
        },
        "provenance": _prov(),
        "official_id": None,
        "entity_id": None,
    }


class TestEnrichWithResolvers:
    @classmethod
    def setup_class(cls):
        bundle, _ = load_all()
        cls.entity_resolver = EntityResolver.from_entities(bundle.entities)
        cls.official_resolver = OfficialResolver.from_officials(bundle.officials)

    def test_pge_to_wilson_binds_cleanly(self):
        record = _pre_resolution_record(
            contributor="Portland General Electric Company",
            committee="Friends of Keith Wilson",
        )
        bound, unbound = enrich_with_resolvers(
            [record],
            entity_resolver=self.entity_resolver,
            official_resolver=self.official_resolver,
        )
        assert len(bound) == 1
        assert len(unbound) == 0
        r = bound[0]
        assert r["entity_id"] == "ent:pge"
        assert r["official_id"] == "off:portland:keith-wilson"

    def test_known_contributor_unknown_committee_goes_unbound(self):
        record = _pre_resolution_record(
            contributor="Portland General Electric",
            committee="Friends of Some Random Person",
        )
        bound, unbound = enrich_with_resolvers(
            [record],
            entity_resolver=self.entity_resolver,
            official_resolver=self.official_resolver,
        )
        assert len(bound) == 0
        assert len(unbound) == 1
        # entity resolved, official did not
        assert unbound[0]["entity_id"] == "ent:pge"
        assert unbound[0]["official_id"] is None

    def test_metadata_carries_resolver_outcome(self):
        record = _pre_resolution_record()
        bound, _ = enrich_with_resolvers(
            [record],
            entity_resolver=self.entity_resolver,
            official_resolver=self.official_resolver,
        )
        assert len(bound) == 1
        meta = bound[0]["metadata"]
        assert "resolver_contributor_tier" in meta
        assert "resolver_committee_tier" in meta
        assert "resolver_contributor_score" in meta
        assert "resolver_committee_score" in meta

    def test_confidence_downgrade_on_weak_resolution(self):
        # Both sides resolve cleanly to canonical/alias matches.
        # Confidence on the affiliation should remain HARD_RECORD.
        record = _pre_resolution_record(
            contributor="Portland General Electric",
            committee="Mayor Keith Wilson",
        )
        bound, _ = enrich_with_resolvers(
            [record],
            entity_resolver=self.entity_resolver,
            official_resolver=self.official_resolver,
        )
        assert len(bound) == 1
        # HARD_RECORD or DOCUMENTED — both acceptable given the alias index
        assert bound[0]["confidence"] in (
            ConfidenceTier.HARD_RECORD, ConfidenceTier.DOCUMENTED
        )

    def test_batch_processing(self):
        records = [
            _pre_resolution_record(
                contributor="Portland General Electric",
                committee="Mayor Keith Wilson",
                amount=500.0,
            ),
            _pre_resolution_record(
                contributor="Northwest Natural",
                committee="Friends of Ron Wyden",
                amount=1000.0,
            ),
            _pre_resolution_record(
                contributor="Acme Made Up Co",
                committee="Imaginary Person",
                amount=2000.0,
            ),
        ]
        bound, unbound = enrich_with_resolvers(
            records,
            entity_resolver=self.entity_resolver,
            official_resolver=self.official_resolver,
        )
        # First two bind, third does not
        assert len(bound) == 2
        assert len(unbound) == 1
        entity_ids = {r["entity_id"] for r in bound}
        assert "ent:pge" in entity_ids
        assert "ent:nw-natural" in entity_ids


# ---------------------------------------------------------------------------
# End-to-end: ORESTAR CSV -> adapter -> resolver -> bound affiliations
# ---------------------------------------------------------------------------


class TestEndToEnd:
    @classmethod
    def setup_class(cls):
        bundle, _ = load_all()
        cls.entity_resolver = EntityResolver.from_entities(bundle.entities)
        cls.official_resolver = OfficialResolver.from_officials(bundle.officials)

    def test_full_pipeline_from_csv(self):
        # Write a tiny CSV
        with tempfile.NamedTemporaryFile(
            "w", suffix=".csv", delete=False, newline=""
        ) as f:
            w = csv.DictWriter(
                f,
                fieldnames=[
                    "tran_id", "tran_date", "amount",
                    "contributor", "committee", "candidate_id", "source_pdf_url",
                ],
            )
            w.writeheader()
            w.writerow({
                "tran_id": "T-A",
                "tran_date": "2026-05-01T00:00:00",
                "amount": "500.00",
                "contributor": "Portland General Electric Company",
                "committee": "Friends of Keith Wilson",
                "candidate_id": "",
                "source_pdf_url": "https://example.com/orestar/T-A.pdf",
            })
            w.writerow({
                "tran_id": "T-B",
                "tran_date": "2026-05-03T00:00:00",
                "amount": "1000.00",
                "contributor": "Northwest Natural Gas",
                "committee": "Friends of Ron Wyden",
                "candidate_id": "",
                "source_pdf_url": "https://example.com/orestar/T-B.pdf",
            })
            tmp_path = f.name

        # 1) Verify CSV format
        ok, problems = verify_csv(tmp_path)
        assert ok, problems

        # 2) Adapter -> pre-resolution
        adapter = OrestarAdapter(export_path=tmp_path)
        result = adapter.fetch()
        assert result.items_accepted == 2

        # 3) Enrich with resolvers -> bound affiliations
        bound, unbound = enrich_with_resolvers(
            result.records,
            entity_resolver=self.entity_resolver,
            official_resolver=self.official_resolver,
        )

        # 4) Both records bound to canonical seed ids
        assert len(bound) == 2
        binding_ids = {(r["entity_id"], r["official_id"]) for r in bound}
        assert ("ent:pge", "off:portland:keith-wilson") in binding_ids
        assert ("ent:nw-natural", "off:federal:ron-wyden") in binding_ids
