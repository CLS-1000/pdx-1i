"""
cls_pdx1.models
================

Core data models for PDX-1i.

Every record carries source_uri. No record enters the system without provenance.
Affiliations are time-bounded edges with tiered confidence.
Bills carry a state machine; transitions are themselves signals.
Anomalies are baseline-relative observations, neutrally stated, attributable to source.

Invariants (enforced via gates module, not just type system):
  - Append-only: nothing is mutated in place; new state is a new record.
  - Single-writer: each record namespace has exactly one authorized writer path.
  - Failure-first: every field that can be unknown is Optional and unknowns are
    represented explicitly rather than via defaults that imply false certainty.
"""

from __future__ import annotations

from datetime import date, datetime
from enum import Enum, IntEnum
from typing import Literal, Optional
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Identifiers and enums
# ---------------------------------------------------------------------------


def _id() -> str:
    return str(uuid4())


class Jurisdiction(str, Enum):
    """Geographic / governmental jurisdictions in scope.

    Bi-state Portland metro: OR side (Multnomah, Washington, Clackamas, Metro,
    City of Portland) plus WA side (Clark County, City of Vancouver).
    State and federal included for officials representing PDX-area constituencies.
    """

    PORTLAND = "portland"
    MULTNOMAH = "multnomah"
    WASHINGTON_OR = "washington_or"
    CLACKAMAS = "clackamas"
    METRO = "metro"
    OREGON = "oregon"
    VANCOUVER = "vancouver"
    CLARK_WA = "clark_wa"
    WASHINGTON_STATE = "washington_state"
    FEDERAL = "federal"


class Sector(str, Enum):
    """Industry sector tags applied to entities."""

    REAL_ESTATE = "real_estate"
    SOFTWARE = "software"
    CONSTRUCTION = "construction"
    UTILITY = "utility"
    TRANSIT = "transit"
    HEALTHCARE = "healthcare"
    EDUCATION = "education"
    FINANCE = "finance"
    LEGAL = "legal"
    MEDIA = "media"
    PUBLIC_SAFETY = "public_safety"
    LABOR = "labor"
    AGRICULTURE = "agriculture"
    HOSPITALITY = "hospitality"


class ConfidenceTier(IntEnum):
    """Affiliation evidence tiers.

    Tier 1 — Hard public record (ORESTAR donation, signed contract, board roster).
    Tier 2 — Documented filing (lobby registration, SEC filing, IRS 990, SEI).
    Tier 3 — Single-source journalism, single-witness testimony.
    Tier 4 — Inferred (news co-mention, statistical co-occurrence). Lowest confidence.

    Publication thresholds typically gate on Tier 1–2 only for factual claims.
    Tier 3–4 may appear as "reported" or "observed pattern" with full attribution.
    """

    HARD_RECORD = 1
    DOCUMENTED = 2
    REPORTED = 3
    INFERRED = 4


class AnomalyTier(IntEnum):
    """Anomaly severity tiers, mirrors journalist module pattern.

    Tier 1 — > 3 sigma deviation OR Tier-1-confidence single-event hard signal.
    Tier 2 — 2–3 sigma OR multi-source corroborated soft signal.
    Tier 3 — 1–2 sigma, watching.
    Tier 4 — below threshold, logged to baseline only.
    """

    TIER_1 = 1
    TIER_2 = 2
    TIER_3 = 3
    TIER_4 = 4


class DistrictType(str, Enum):
    CITY_COUNCIL = "city_council"
    CITY_AT_LARGE = "city_at_large"
    CITY_MAYOR = "city_mayor"
    CITY_AUDITOR = "city_auditor"
    COUNTY_COMMISSION = "county_commission"
    COUNTY_SHERIFF = "county_sheriff"
    COUNTY_DA = "county_da"
    METRO_COUNCIL = "metro_council"
    SCHOOL_BOARD = "school_board"
    STATE_HOUSE = "state_house"
    STATE_SENATE = "state_senate"
    STATE_EXECUTIVE = "state_executive"
    CONGRESSIONAL = "congressional"
    US_SENATE = "us_senate"


class EntityKind(str, Enum):
    COMPANY = "company"
    FAMILY = "family"
    AGENCY = "agency"
    NONPROFIT = "nonprofit"
    PAC = "pac"
    UNION = "union"
    TRADE_ASSOC = "trade_assoc"
    REGULATOR = "regulator"
    FOUNDATION = "foundation"
    HOLDING_COMPANY = "holding_company"


class EdgeType(str, Enum):
    """Affiliation edge types between Officials and Entities."""

    DONATION = "donation"
    LOBBYING = "lobbying"
    BOARD_SEAT = "board_seat"
    EMPLOYMENT = "employment"
    PRIOR_EMPLOYMENT = "prior_employment"
    CONTRACT_AWARD = "contract_award"
    HOUSEHOLD_INCOME = "household_income"
    SEI_DISCLOSED = "sei_disclosed"
    NEWS_COMENTION = "news_comention"
    FAMILY_TIE = "family_tie"
    TESTIMONY = "testimony"
    APPOINTMENT_BY = "appointment_by"


class BillState(str, Enum):
    INTRODUCED = "introduced"
    COMMITTEE = "committee"
    COMMITTEE_REPORTED = "committee_reported"
    FLOOR = "floor"
    PASSED_CHAMBER = "passed_chamber"
    PASSED_BOTH = "passed_both"
    ENACTED = "enacted"
    VETOED = "vetoed"
    DEAD = "dead"
    WITHDRAWN = "withdrawn"
    POSTPONED = "postponed"


class VotePosition(str, Enum):
    YEA = "yea"
    NAY = "nay"
    ABSTAIN = "abstain"
    EXCUSED = "excused"
    ABSENT = "absent"


# ---------------------------------------------------------------------------
# Provenance: every record carries this
# ---------------------------------------------------------------------------


class Provenance(BaseModel):
    """Provenance metadata. Every record carries one of these.

    source_uri is non-optional by design. Records without source_uri are
    rejected at the provenance gate.
    """

    source_uri: str = Field(..., min_length=1)
    source_name: str
    fetched_at: datetime
    adapter_version: str = "0.1.0"

    @field_validator("source_uri")
    @classmethod
    def must_be_resolvable(cls, v: str) -> str:
        if not (v.startswith("http://") or v.startswith("https://") or v.startswith("file://")):
            raise ValueError(f"source_uri must be a URL or file URI, got: {v!r}")
        return v


# ---------------------------------------------------------------------------
# Officials & Districts
# ---------------------------------------------------------------------------


class District(BaseModel):
    id: str = Field(default_factory=_id)
    name: str
    type: DistrictType
    jurisdiction: Jurisdiction
    number: Optional[str] = None  # "HD 45", "Position 3", "District 1"
    geometry_uri: Optional[str] = None  # link to GeoJSON
    provenance: Provenance


class Official(BaseModel):
    id: str = Field(default_factory=_id)
    full_name: str
    aliases: list[str] = Field(default_factory=list)
    role: str  # "Portland City Councilor", "Multnomah County Chair", "OR State Rep"
    district_id: Optional[str] = None
    jurisdiction: Jurisdiction
    party: Optional[str] = None
    term_start: date
    term_end: Optional[date] = None
    status: Literal["active", "former", "elect"] = "active"
    provenance: Provenance


# ---------------------------------------------------------------------------
# Entities (organizations, families, agencies, etc.)
# ---------------------------------------------------------------------------


class Entity(BaseModel):
    id: str = Field(default_factory=_id)
    canonical_name: str
    aliases: list[str] = Field(default_factory=list)
    kind: EntityKind
    sector_tags: list[Sector] = Field(default_factory=list)
    parent_entity_id: Optional[str] = None  # for subsidiary / family chain
    jurisdiction_primary: Optional[Jurisdiction] = None
    is_watch_listed: bool = False  # subject to anomaly monitoring
    watch_priority: Optional[int] = None  # 1=highest, None=not on watch
    provenance: Provenance


# ---------------------------------------------------------------------------
# Affiliations: typed, time-bounded, tiered edges
# ---------------------------------------------------------------------------


class Affiliation(BaseModel):
    """A typed edge between an Official and an Entity.

    Time-bounded: valid_from is required, valid_to is optional (None = ongoing).
    Confidence-tiered: tier drives publication eligibility.
    Always carries provenance. No provenance => rejected at gate.
    """

    id: str = Field(default_factory=_id)
    official_id: str
    entity_id: str
    edge_type: EdgeType
    confidence: ConfidenceTier
    observed_at: datetime
    valid_from: date
    valid_to: Optional[date] = None
    amount_usd: Optional[float] = None  # for donations / contracts
    description: Optional[str] = None  # neutral, factual description
    metadata: dict = Field(default_factory=dict)
    provenance: Provenance

    @field_validator("amount_usd")
    @classmethod
    def amount_non_negative(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and v < 0:
            raise ValueError("amount_usd cannot be negative")
        return v


# ---------------------------------------------------------------------------
# Bills, votes, testimony
# ---------------------------------------------------------------------------


class BillStateTransition(BaseModel):
    from_state: Optional[BillState] = None
    to_state: BillState
    occurred_at: datetime
    notes: Optional[str] = None
    provenance: Provenance


class Bill(BaseModel):
    id: str = Field(default_factory=_id)
    jurisdiction: Jurisdiction
    bill_number: str  # "HB 2002", "Portland Ordinance 191234", "Multnomah Order 2024-001"
    title: str
    introduced_at: date
    sponsor_ids: list[str] = Field(default_factory=list)  # official ids
    co_sponsor_ids: list[str] = Field(default_factory=list)
    state: BillState
    state_history: list[BillStateTransition] = Field(default_factory=list)
    summary_raw: str  # original / official text
    summary_plain: Optional[str] = None  # filled by explain layer
    affected_entity_ids: list[str] = Field(default_factory=list)  # inferred
    affected_sectors: list[Sector] = Field(default_factory=list)
    next_action_at: Optional[datetime] = None  # next hearing / vote
    public_comment_deadline: Optional[datetime] = None
    provenance: Provenance


class Vote(BaseModel):
    id: str = Field(default_factory=_id)
    bill_id: str
    official_id: str
    position: VotePosition
    occurred_at: datetime
    provenance: Provenance


class Testimony(BaseModel):
    """Hearing witness record. Feeds back into Affiliation graph as
    edge_type=TESTIMONY when witness has a stated affiliation."""

    __test__ = False  # not a pytest class, just a Pydantic model named "Testimony"

    id: str = Field(default_factory=_id)
    bill_id: str
    witness_name: str
    stated_affiliation: Optional[str] = None  # what they said they represent
    matched_entity_id: Optional[str] = None  # resolved entity if any
    position: Optional[Literal["for", "against", "neutral"]] = None
    occurred_at: datetime
    excerpt: Optional[str] = None
    provenance: Provenance


# ---------------------------------------------------------------------------
# Watch list, anomalies, signals
# ---------------------------------------------------------------------------


class Signal(BaseModel):
    """A discrete observed event. Anomalies are derived from signals over a window."""

    id: str = Field(default_factory=_id)
    entity_id: Optional[str] = None  # watch-list entity if applicable
    official_id: Optional[str] = None
    bill_id: Optional[str] = None
    kind: str  # "donation", "rate_filing", "bill_introduced", "vote", etc.
    occurred_at: datetime
    detected_at: datetime
    value: Optional[float] = None  # for numeric signals
    payload: dict = Field(default_factory=dict)
    provenance: Provenance


class Anomaly(BaseModel):
    """A neutrally-stated deviation from baseline.

    The description is fact-only: 'X filed Y on date Z, value W, vs.
    90-day baseline mean of V'. Interpretation lives in the brief prose, not here.
    """

    id: str = Field(default_factory=_id)
    entity_id: str
    tier: AnomalyTier
    detected_at: datetime
    kind: str  # "donation_spike", "contract_anomaly", "lobby_spike", etc.
    description: str  # neutral factual statement
    baseline_window_days: int
    baseline_mean: Optional[float] = None
    baseline_stdev: Optional[float] = None
    observed_value: Optional[float] = None
    deviation_sigma: Optional[float] = None
    signal_ids: list[str] = Field(default_factory=list)  # contributing signals
    response_recorded: Optional[str] = None  # entity's on-record response
    response_source_uri: Optional[str] = None
    provenance: Provenance


# ---------------------------------------------------------------------------
# Publication: Metro Citizens Brief issues
# ---------------------------------------------------------------------------


class IssueSection(BaseModel):
    """A section in an MCB issue. Sections are bounded, attributed, neutral."""

    heading: str
    body: str  # passes neutrality gates before assembly
    cited_source_uris: list[str] = Field(default_factory=list)
    referenced_bill_ids: list[str] = Field(default_factory=list)
    referenced_anomaly_ids: list[str] = Field(default_factory=list)
    referenced_official_ids: list[str] = Field(default_factory=list)
    referenced_entity_ids: list[str] = Field(default_factory=list)


class Issue(BaseModel):
    """Metro Citizens Brief issue.

    Issues are append-only — once published, immutable. Corrections become
    new issues with a stated correction notice.
    """

    id: str = Field(default_factory=_id)
    issue_number: int  # MCB Issue 1, 2, 3...
    published_at: datetime
    trigger_signal_ids: list[str]  # what fired this issue
    trigger_anomaly_ids: list[str] = Field(default_factory=list)
    sections: list[IssueSection]
    pdf_uri: Optional[str] = None  # archival PDF
    web_uri: Optional[str] = None  # web view
    diagram_snapshot_id: Optional[str] = None  # graph state at publish time
    correction_of_issue_id: Optional[str] = None  # set if this corrects a prior issue
    provenance: Provenance


__all__ = [
    "Jurisdiction",
    "Sector",
    "ConfidenceTier",
    "AnomalyTier",
    "DistrictType",
    "EntityKind",
    "EdgeType",
    "BillState",
    "VotePosition",
    "Provenance",
    "District",
    "Official",
    "Entity",
    "Affiliation",
    "BillStateTransition",
    "Bill",
    "Vote",
    "Testimony",
    "Signal",
    "Anomaly",
    "IssueSection",
    "Issue",
]
