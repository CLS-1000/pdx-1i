"""
cls_pdx1
=========

PDX-1i — Portland Metro Intelligence module of the SPEC-1 engine.

Powers the Metro Citizens Brief: a signal-gated, neutrality-enforced
publication that tells residents of the bi-state Portland metro
(Multnomah / Washington / Clackamas / Clark counties + City of Portland +
City of Vancouver + Metro) what their elected officials are doing, how
budgets and bills are moving, and what watch-list institutional players
(PGE, NW Natural, Water Bureau, TriMet, PPB, OHSU, Schnitzer) are doing
relative to baseline.

Architecture invariants (shared with the rest of SPEC-1):
  - Append-only records; updates are new records.
  - Single-writer per record namespace.
  - run_id traceability end-to-end.
  - Provenance non-negotiable: no source_uri => rejected.
  - Neutrality enforced as gates, not editorial habit.
  - Failure-first: bad rows logged, never halt the pipeline.

Public surface:
  models       — Pydantic core models (Official, Entity, Affiliation, Bill, Signal, Anomaly, Issue, ...)
  gates        — structural gates (provenance, append-only, time-bounding, corroboration)
  neutrality   — tone / hedging / attribution gates for publication prose
  sources      — source adapters (one file per upstream data source)
  watch        — per-entity watch modules feeding anomaly detection
  legislation  — bill state machine, transition-to-signal lifting
  anomaly      — rolling-baseline anomaly detection
  triggers     — publication trigger evaluation (signal-gated, not calendar-gated)
  explain      — plain-language LLM summarization with neutrality retry
  publication  — issue assembly + markdown + PDF + graph diagram export
  pipeline     — orchestration tying it all together
"""

from __future__ import annotations

__version__ = "0.1.0"
__module_id__ = "cls_pdx1"

# Brand identity for the publication this module powers
PUBLICATION_NAME = "Metro Citizens Brief"
PUBLICATION_SLUG = "mcb"

__all__ = [
    "__version__",
    "__module_id__",
    "PUBLICATION_NAME",
    "PUBLICATION_SLUG",
]
