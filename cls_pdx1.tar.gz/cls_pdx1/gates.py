"""
cls_pdx1.gates
==============

Architectural gates. These are the non-negotiables:

  - Provenance gate: no source_uri => rejected.
  - Append-only gate: no in-place mutation; updates are new records.
  - Tier-corroboration gate: high-tier publication-bound claims require N sources.

Neutrality gates live in cls_pdx1.neutrality; this module is the structural
invariants only.

Every gate returns a (passed: bool, reason: Optional[str]) tuple. Reasons are
machine-readable codes plus human-readable detail.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from .models import Affiliation, Anomaly, ConfidenceTier, Provenance, Signal


# ---------------------------------------------------------------------------
# Provenance gate — THE invariant
# ---------------------------------------------------------------------------


def provenance_gate(record: Any) -> tuple[bool, Optional[str]]:
    """Reject any record lacking a valid provenance.source_uri.

    Single non-negotiable architectural invariant: nothing enters the
    pipeline without a resolvable source URI.

    Works on Pydantic models or dicts.
    """
    if record is None:
        return False, "PROV_001: record is None"

    if hasattr(record, "provenance"):
        prov = record.provenance
    elif isinstance(record, dict):
        prov = record.get("provenance")
    else:
        return False, "PROV_002: record has no provenance attribute or key"

    if prov is None:
        return False, "PROV_003: provenance is None"

    if isinstance(prov, Provenance):
        source_uri = prov.source_uri
    elif isinstance(prov, dict):
        source_uri = prov.get("source_uri")
    else:
        return False, f"PROV_004: provenance has unexpected type {type(prov).__name__}"

    if not source_uri:
        return False, "PROV_005: source_uri is missing or empty"

    if not isinstance(source_uri, str):
        return False, f"PROV_006: source_uri must be string, got {type(source_uri).__name__}"

    if not (
        source_uri.startswith("http://")
        or source_uri.startswith("https://")
        or source_uri.startswith("file://")
    ):
        return False, f"PROV_007: source_uri must be a URL/URI scheme, got {source_uri!r}"

    return True, None


# ---------------------------------------------------------------------------
# Append-only enforcement
# ---------------------------------------------------------------------------


class AppendOnlyViolation(Exception):
    """Raised when a write path attempts to mutate an existing record."""


def append_only_gate(
    existing_ids: set[str], incoming_id: str
) -> tuple[bool, Optional[str]]:
    """Reject writes whose id already exists. Updates must be new records."""
    if incoming_id in existing_ids:
        return False, f"APND_001: id {incoming_id} already present; writes must be append-only"
    return True, None


# ---------------------------------------------------------------------------
# Time-bounding gate (affiliations)
# ---------------------------------------------------------------------------


def time_bounding_gate(affiliation: Affiliation) -> tuple[bool, Optional[str]]:
    """Affiliations must have valid_from. valid_to may be None (=ongoing).

    If both set, valid_from must precede valid_to.
    """
    if affiliation.valid_from is None:
        return False, "TIME_001: affiliation missing valid_from"
    if affiliation.valid_to is not None and affiliation.valid_to < affiliation.valid_from:
        return (
            False,
            f"TIME_002: valid_to ({affiliation.valid_to}) precedes valid_from ({affiliation.valid_from})",
        )
    return True, None


# ---------------------------------------------------------------------------
# Tier corroboration: higher-impact claims require more sources
# ---------------------------------------------------------------------------


# Default corroboration policy: how many independent sources are required to
# publish a factual claim at each confidence tier.
#
# Tier 1 (hard public record): one source suffices (the record itself).
# Tier 2 (documented filing): one source suffices.
# Tier 3 (reported): require two independent sources to publish as factual.
# Tier 4 (inferred): cannot be published as factual; only as "observed pattern".
DEFAULT_CORROBORATION_POLICY: dict[int, int] = {
    int(ConfidenceTier.HARD_RECORD): 1,
    int(ConfidenceTier.DOCUMENTED): 1,
    int(ConfidenceTier.REPORTED): 2,
    int(ConfidenceTier.INFERRED): 99,  # effectively unpublishable as factual claim
}


def tier_corroboration_gate(
    tier: ConfidenceTier,
    source_uris: list[str],
    policy: Optional[dict[int, int]] = None,
) -> tuple[bool, Optional[str]]:
    """Confirm a claim has enough independent sources for its confidence tier."""
    policy = policy or DEFAULT_CORROBORATION_POLICY
    required = policy.get(int(tier), 1)
    unique_sources = len(set(source_uris))
    if unique_sources < required:
        return (
            False,
            f"CORR_001: tier {int(tier)} requires {required} independent sources, got {unique_sources}",
        )
    return True, None


# ---------------------------------------------------------------------------
# Anomaly publication gate
# ---------------------------------------------------------------------------


def anomaly_publication_gate(anomaly: Anomaly) -> tuple[bool, Optional[str]]:
    """Anomalies enter the publication pipeline only if Tier 1 or 2.

    Tier 3/4 anomalies are recorded but not surfaced in the brief; they roll
    into baseline updates.
    """
    if int(anomaly.tier) > 2:
        return False, f"ANOM_001: anomaly tier {int(anomaly.tier)} below publication threshold"
    return True, None


# ---------------------------------------------------------------------------
# Signal freshness gate
# ---------------------------------------------------------------------------


def signal_freshness_gate(
    signal: Signal, max_age_seconds: int = 60 * 60 * 24 * 30
) -> tuple[bool, Optional[str]]:
    """Reject signals older than max_age. Default: 30 days.

    Stale signals can still backfill baselines but shouldn't trigger publications.
    """
    age = (datetime.utcnow() - signal.detected_at).total_seconds()
    if age > max_age_seconds:
        return False, f"FRESH_001: signal age {int(age)}s exceeds max {max_age_seconds}s"
    return True, None


# ---------------------------------------------------------------------------
# Composite gate runner
# ---------------------------------------------------------------------------


def run_gates(*gate_results: tuple[bool, Optional[str]]) -> tuple[bool, list[str]]:
    """Run multiple gate results, collect failures.

    Returns (all_passed, list_of_failure_reasons).
    """
    failures = [reason for passed, reason in gate_results if not passed and reason]
    return len(failures) == 0, failures


__all__ = [
    "AppendOnlyViolation",
    "provenance_gate",
    "append_only_gate",
    "time_bounding_gate",
    "tier_corroboration_gate",
    "anomaly_publication_gate",
    "signal_freshness_gate",
    "run_gates",
    "DEFAULT_CORROBORATION_POLICY",
]
