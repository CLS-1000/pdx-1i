"""
cls_pdx1.sources.orestar
=========================

Oregon Secretary of State campaign finance — ORESTAR.

Highest-leverage starting adapter: dollar-flow backbone that the rest of the
graph hangs off. Every donation is a Tier-1 hard-record affiliation.

ORESTAR is a JSF / form-driven application; there is no clean public API.
The supported workflow for bulk ingestion is:

  1. Use `build_search_url()` to construct an ORESTAR Transaction Search URL
     for the date range / committee / contributor of interest.
  2. Open it in a browser, run the search, click the CSV export link.
  3. Save the downloaded CSV.
  4. Pass that path as `export_path=...` to OrestarAdapter; the rest of the
     pipeline (provenance stamping, normalization, gate validation) runs
     unchanged.

A "live HTTP scrape" path is intentionally NOT wired here. JSF session
handling is fragile and breaks on every ORESTAR redesign; the documented
CSV export is the path the Oregon SOS itself recommends for bulk users.

Use `enrich_with_resolvers()` to bind raw contributor / committee names to
canonical Entity / Official ids from the seed before persistence. The
resolver assigns a ConfidenceTier per binding — downstream gates handle
the rest.
"""

from __future__ import annotations

import csv
import urllib.parse
from datetime import datetime
from typing import Any, Iterator, Optional

from ..models import (
    Affiliation,
    ConfidenceTier,
    EdgeType,
    Jurisdiction,
    Provenance,
)
from . import SourceAdapter


# Production endpoints
ORESTAR_BASE = "https://secure.sos.state.or.us/orestar/"
ORESTAR_TRANSACTION_SEARCH = (
    "https://secure.sos.state.or.us/orestar/gotoPublicTransactionSearch.do"
)

# Canonical CSV column names ORESTAR uses (as of 2026). Used by verify_csv
# to catch format drift early.
EXPECTED_CSV_COLUMNS = frozenset({
    "tran_id",
    "tran_date",
    "amount",
    "contributor",
    "committee",
})


def enrich_with_resolvers(
    affiliation_records: list[dict],
    entity_resolver: Any,
    official_resolver: Any,
) -> tuple[list[dict], list[dict]]:
    """Bind raw contributor / committee names to canonical ids.

    Mutates each record in place (well — re-assigns `entity_id` /
    `official_id` and adds resolver outcome metadata) and returns
    (bound, unbound) — the unbound list contains records where one or
    both endpoints could not be resolved.

    Confidence tier on the Affiliation is downgraded if either resolver
    landed below HARD_RECORD: the binding is only as confident as its
    weakest leg.

    Parameters
    ----------
    affiliation_records : list of dict (pre-resolution shape from _normalize)
    entity_resolver     : an EntityResolver from cls_pdx1.resolver
    official_resolver   : an OfficialResolver from cls_pdx1.resolver

    Returns
    -------
    bound, unbound : two lists
    """
    bound: list[dict] = []
    unbound: list[dict] = []

    for rec in affiliation_records:
        meta = rec.setdefault("metadata", {})
        contributor_raw = meta.get("contributor_name_raw") or ""
        committee_raw = meta.get("committee_name_raw") or ""

        ent_result = entity_resolver.resolve(contributor_raw)
        off_result = official_resolver.resolve(committee_raw)

        meta["resolver_contributor_tier"] = ent_result.tier.name
        meta["resolver_contributor_score"] = ent_result.score
        meta["resolver_committee_tier"] = off_result.tier.name
        meta["resolver_committee_score"] = off_result.score

        rec["entity_id"] = ent_result.resolved_id
        rec["official_id"] = off_result.resolved_id

        # Downgrade confidence to match the weakest resolved leg
        weakest = None
        for r in (ent_result, off_result):
            c = r.confidence
            if c is None:
                weakest = ConfidenceTier.INFERRED
                break
            if weakest is None or int(c) > int(weakest):
                weakest = c
        if weakest is not None and int(weakest) > int(rec["confidence"]):
            rec["confidence"] = weakest

        if ent_result.resolved_id and off_result.resolved_id:
            bound.append(rec)
        else:
            unbound.append(rec)

    return bound, unbound


def build_search_url(
    contributor: Optional[str] = None,
    committee: Optional[str] = None,
    start_date: Optional[str] = None,  # YYYY-MM-DD
    end_date: Optional[str] = None,
) -> str:
    """Construct an ORESTAR transaction search URL the user can open in a browser.

    ORESTAR's actual search form posts via JSF and uses internal session keys,
    so this returns the entry-point URL with the criteria as query hints —
    the user still needs to apply them in the UI. The URL is the documented
    starting point for any manual export.
    """
    params: dict[str, str] = {}
    if contributor:
        params["contributor_name"] = contributor
    if committee:
        params["committee_name"] = committee
    if start_date:
        params["start_date"] = start_date
    if end_date:
        params["end_date"] = end_date
    if not params:
        return ORESTAR_TRANSACTION_SEARCH
    return ORESTAR_TRANSACTION_SEARCH + "?" + urllib.parse.urlencode(params)


def verify_csv(path: str) -> tuple[bool, list[str]]:
    """Verify that a CSV file looks like a valid ORESTAR transaction export.

    Returns (ok, problems). `ok=False` if any required column is missing.
    Run this before pumping a file through the adapter so format drift
    fails fast rather than silently producing empty results.
    """
    problems: list[str] = []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            reader = csv.reader(fh)
            try:
                header = next(reader)
            except StopIteration:
                return False, [f"{path}: empty file"]
        header_set = {h.strip().lower().replace(" ", "_") for h in header}
        missing = EXPECTED_CSV_COLUMNS - header_set
        if missing:
            problems.append(
                f"missing expected columns: {sorted(missing)}; got: {sorted(header_set)[:10]}"
            )
    except FileNotFoundError:
        return False, [f"{path}: file not found"]
    except (UnicodeDecodeError, OSError) as e:
        return False, [f"{path}: read error: {e}"]
    return (len(problems) == 0), problems


class OrestarAdapter(SourceAdapter):
    """ORESTAR campaign finance transaction adapter.

    Edge type produced: EdgeType.DONATION
    Confidence tier:    ConfidenceTier.HARD_RECORD (Tier 1)

    Pre-resolution: `official_id` and `entity_id` are None on output.
    Call `enrich_with_resolvers()` to bind names to canonical ids.
    """

    name = "orestar"
    jurisdiction = Jurisdiction.OREGON
    edge_types = [EdgeType.DONATION]
    version = "0.2.0"

    def __init__(
        self,
        http_client: Optional[Any] = None,
        export_path: Optional[str] = None,
    ) -> None:
        super().__init__(http_client=http_client)
        # When export_path is provided, the adapter reads from a local
        # CSV/JSON export instead of hitting the live endpoint. Useful for
        # bulk reprocessing and testing.
        self.export_path = export_path

    def _fetch_raw(self, since: Optional[datetime] = None) -> Iterator[dict]:
        """Yield raw ORESTAR transaction rows.

        Implementer wires either:
          (a) live HTTP scrape against ORESTAR's transaction search; or
          (b) parsing of bulk CSV exports downloaded out-of-band.

        Each yielded raw dict is expected to contain at minimum:
          - tran_id          (ORESTAR transaction id)
          - tran_date        (ISO date string)
          - amount           (numeric)
          - contributor      (name)
          - committee        (recipient committee name)
          - candidate_id     (linked candidate, if any)
          - source_pdf_url   (link back to filing PDF)
        """
        if self.export_path:
            yield from self._fetch_from_export(self.export_path, since=since)
            return

        # Live fetch path. Concrete HTTP implementation is wired by integrator
        # since ORESTAR's interface is form-based and authentication-light but
        # rate-sensitive.
        raise NotImplementedError(
            "Live ORESTAR fetch not yet wired. Provide export_path or "
            "implement _fetch_from_live."
        )

    def _fetch_from_export(
        self, path: str, since: Optional[datetime] = None
    ) -> Iterator[dict]:
        """Read transactions from a local CSV export.

        ORESTAR CSV exports use a documented column layout; this method
        is the format-aware parser. Stubbed here as an example shape.
        """
        import csv

        with open(path, "r", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                if since:
                    try:
                        row_date = datetime.fromisoformat(row.get("tran_date", ""))
                        if row_date < since:
                            continue
                    except (ValueError, TypeError):
                        pass
                yield row

    def _stamp(self, raw: dict) -> dict:
        """Attach Provenance pointing back to the ORESTAR filing."""
        tran_id = raw.get("tran_id") or raw.get("id") or "unknown"
        source_pdf = raw.get("source_pdf_url") or raw.get("pdf_url")
        # Fall back to the ORESTAR base search URL with the tran_id appended
        source_uri = source_pdf or f"{ORESTAR_BASE}?tran_id={tran_id}"

        raw["provenance"] = Provenance(
            source_uri=source_uri,
            source_name="orestar",
            fetched_at=datetime.utcnow(),
            adapter_version=self.version,
        )
        return raw

    def _normalize(self, stamped: dict) -> Optional[dict]:
        """Map an ORESTAR row to an Affiliation record.

        Resolution of (contributor -> Entity) and (committee/candidate -> Official)
        happens at the entity resolver layer, not here. This adapter produces
        a pre-resolution Affiliation with placeholder ids; the pipeline calls
        the resolver to bind them.
        """
        try:
            amount = float(stamped.get("amount", 0) or 0)
        except (ValueError, TypeError):
            return None

        if amount <= 0:
            return None

        tran_date = stamped.get("tran_date")
        try:
            observed_at = datetime.fromisoformat(tran_date) if tran_date else datetime.utcnow()
        except (ValueError, TypeError):
            observed_at = datetime.utcnow()

        # Pre-resolution shape: contributor and candidate are name strings.
        # Resolver binds them to canonical ids downstream.
        affiliation_shaped = {
            "edge_type": EdgeType.DONATION,
            "confidence": ConfidenceTier.HARD_RECORD,
            "observed_at": observed_at,
            "valid_from": observed_at.date(),
            "valid_to": observed_at.date(),  # one-time event
            "amount_usd": amount,
            "description": (
                f"Donation of ${amount:,.2f} recorded in ORESTAR "
                f"on {observed_at.date().isoformat()}"
            ),
            "metadata": {
                "contributor_name_raw": stamped.get("contributor"),
                "committee_name_raw": stamped.get("committee"),
                "candidate_id_raw": stamped.get("candidate_id"),
                "tran_id": stamped.get("tran_id"),
            },
            "provenance": stamped["provenance"],
            # Placeholder ids — resolver populates these
            "official_id": None,
            "entity_id": None,
        }
        return affiliation_shaped


__all__ = [
    "OrestarAdapter",
    "ORESTAR_BASE",
    "ORESTAR_TRANSACTION_SEARCH",
    "EXPECTED_CSV_COLUMNS",
    "build_search_url",
    "verify_csv",
    "enrich_with_resolvers",
]
