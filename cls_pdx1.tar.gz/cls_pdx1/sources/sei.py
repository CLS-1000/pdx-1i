"""
cls_pdx1.sources.sei
=====================

Oregon Government Ethics Commission — Statement of Economic Interest (SEI).

Every Oregon public official files an annual SEI disclosing:
  - Employer and household-member employers
  - Sources of household income > $1,000
  - Business interests, partnerships, holdings
  - Real property (if used in any state business)
  - Gifts received from lobbyists / regulated entities
  - Honoraria, expense reimbursements

This is the densest single source for surfacing conflict-of-interest
edges directly disclosed by the official themselves. Every SEI entry is
a Tier-2 documented affiliation (the official is the source).

OGEC publishes filings via the AURA system:
  https://aura.oregon.gov/

Filings are PDFs. The integrator wires a PDF parser; this adapter
provides the canonical record shape and normalization.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Iterator, Optional

from ..models import (
    ConfidenceTier,
    EdgeType,
    Jurisdiction,
    Provenance,
)
from . import SourceAdapter


OGEC_AURA_BASE = "https://aura.oregon.gov/"


# SEI line-item categories observed on the form. Mapped to our EdgeType.
SEI_CATEGORY_TO_EDGE: dict[str, EdgeType] = {
    "employer": EdgeType.EMPLOYMENT,
    "household_member_employer": EdgeType.HOUSEHOLD_INCOME,
    "business_interest": EdgeType.SEI_DISCLOSED,
    "income_source": EdgeType.HOUSEHOLD_INCOME,
    "honoraria": EdgeType.SEI_DISCLOSED,
    "gift": EdgeType.SEI_DISCLOSED,
    "real_property": EdgeType.SEI_DISCLOSED,
    "office_partnership": EdgeType.SEI_DISCLOSED,
}


class SeiAdapter(SourceAdapter):
    """SEI filings adapter.

    Produces multiple Affiliation records per filing — one per disclosed
    economic relationship. All are Tier-2 DOCUMENTED (the filing itself).

    Subclasses or callers can swap the PDF parser; the contract is that
    `_fetch_raw` yields dicts with the structure documented in
    `_fetch_from_export`.
    """

    name = "sei"
    jurisdiction = Jurisdiction.OREGON
    edge_types = [
        EdgeType.EMPLOYMENT,
        EdgeType.HOUSEHOLD_INCOME,
        EdgeType.SEI_DISCLOSED,
    ]
    version = "0.1.0"

    def __init__(
        self,
        http_client: Optional[Any] = None,
        export_path: Optional[str] = None,
    ) -> None:
        super().__init__(http_client=http_client)
        self.export_path = export_path

    def _fetch_raw(self, since: Optional[datetime] = None) -> Iterator[dict]:
        """Yield raw SEI line items.

        Each raw dict is expected to contain:
          - filing_id          (AURA filing id)
          - filer_name         (official's full name as on the SEI)
          - filer_office       (role title)
          - filing_year        (int)
          - filing_date        (ISO date)
          - line_category      (one of SEI_CATEGORY_TO_EDGE keys)
          - line_subject       (entity / employer / source name as written)
          - line_detail        (free-text description if present)
          - line_value         (optional: dollar amount if disclosed)
          - source_pdf_url     (link back to the PDF)
        """
        if self.export_path:
            yield from self._fetch_from_export(self.export_path, since=since)
            return

        raise NotImplementedError(
            "Live SEI fetch requires AURA PDF scraping. Provide export_path or "
            "implement _fetch_from_live with a PDF parser."
        )

    def _fetch_from_export(
        self, path: str, since: Optional[datetime] = None
    ) -> Iterator[dict]:
        """Read SEI line items from a local JSONL export."""
        import json

        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if since:
                    try:
                        row_date = datetime.fromisoformat(row.get("filing_date", ""))
                        if row_date < since:
                            continue
                    except (ValueError, TypeError):
                        pass
                yield row

    def _stamp(self, raw: dict) -> dict:
        filing_id = raw.get("filing_id") or raw.get("id") or "unknown"
        source_pdf = raw.get("source_pdf_url") or raw.get("pdf_url")
        source_uri = source_pdf or f"{OGEC_AURA_BASE}?filing_id={filing_id}"
        raw["provenance"] = Provenance(
            source_uri=source_uri,
            source_name="sei",
            fetched_at=datetime.utcnow(),
            adapter_version=self.version,
        )
        return raw

    def _normalize(self, stamped: dict) -> Optional[dict]:
        """Map a SEI line item to an Affiliation-shaped dict.

        Resolution of filer_name -> Official id and line_subject -> Entity id
        is the resolver's job. This adapter produces pre-resolution shape with
        the raw names preserved in metadata.
        """
        category = stamped.get("line_category")
        if not category:
            return None
        edge_type = SEI_CATEGORY_TO_EDGE.get(category)
        if edge_type is None:
            return None

        line_subject = (stamped.get("line_subject") or "").strip()
        if not line_subject:
            return None

        filing_year = stamped.get("filing_year")
        filing_date_raw = stamped.get("filing_date")
        try:
            filing_date = (
                date.fromisoformat(filing_date_raw)
                if filing_date_raw
                else date.today()
            )
        except (ValueError, TypeError):
            filing_date = date.today()

        # SEI line items are annual disclosures. valid_from is filing_date;
        # valid_to is one year forward unless we have a more specific signal.
        try:
            value = float(stamped.get("line_value", 0) or 0) or None
        except (ValueError, TypeError):
            value = None

        return {
            "edge_type": edge_type,
            "confidence": ConfidenceTier.DOCUMENTED,
            "observed_at": datetime.combine(filing_date, datetime.min.time()),
            "valid_from": filing_date,
            "valid_to": None,  # SEI disclosures are point-in-time; resolver may close them
            "amount_usd": value,
            "description": (
                f"SEI {category} disclosure: {line_subject} "
                f"(filing year {filing_year})"
            ),
            "metadata": {
                "filer_name_raw": stamped.get("filer_name"),
                "filer_office_raw": stamped.get("filer_office"),
                "line_subject_raw": line_subject,
                "line_detail_raw": stamped.get("line_detail"),
                "line_category": category,
                "filing_id": stamped.get("filing_id"),
                "filing_year": filing_year,
            },
            "provenance": stamped["provenance"],
            "official_id": None,
            "entity_id": None,
        }


__all__ = ["SeiAdapter", "OGEC_AURA_BASE", "SEI_CATEGORY_TO_EDGE"]
