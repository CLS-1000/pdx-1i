"""
cls_pdx1.sources
================

Source adapters: one per upstream data source.

Each adapter:
  - Declares its source identity (name, jurisdiction, edge_types produced)
  - Implements fetch(since) that yields records stamped with provenance
  - Handles its own rate limiting and graceful failure
  - Validates every record against provenance_gate before yielding

Concrete adapters live in sibling modules:
  - orestar.py  — Oregon SOS campaign finance
  - olis.py     — Oregon Legislature bills + votes
  - wa_pdc.py   — Washington Public Disclosure Commission
  - sei.py      — Oregon Government Ethics Commission SEI filings
  - sec_edgar.py — SEC EDGAR for public-company board / insider data
  - irs_990.py  — IRS 990 via ProPublica Nonprofit Explorer
  - portland_lobby.py — City of Portland Lobby Entity Reports
  - metro_lobby.py — Metro lobby registry
  - multnomah_assessor.py — Property ownership records
  - news_feeds.py — RSS feeds from regional publications
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Iterator, Optional

from ..gates import provenance_gate
from ..models import EdgeType, Jurisdiction


@dataclass
class FetchResult:
    """Wrapper around adapter output for orchestration accounting."""

    records: list[dict] = field(default_factory=list)
    rejected: list[tuple[dict, str]] = field(default_factory=list)  # (record, reason)
    fetched_at: datetime = field(default_factory=datetime.utcnow)
    source_name: str = ""
    items_seen: int = 0

    @property
    def items_accepted(self) -> int:
        return len(self.records)

    @property
    def items_rejected(self) -> int:
        return len(self.rejected)


class SourceAdapter(ABC):
    """Base class for all source adapters.

    Subclasses set class-level attributes for declarative identity:
      name           — unique slug, e.g. "orestar"
      jurisdiction   — Jurisdiction enum value
      edge_types     — list[EdgeType] this adapter can produce
      version        — adapter schema version

    Subclasses implement:
      _fetch_raw(since) — yield raw records from upstream
      _stamp(record)    — attach Provenance to a raw record
      _normalize(record) — map raw record to one of the core models

    The provided fetch() runs the full pipeline and validates each record.
    """

    name: str = "unnamed"
    jurisdiction: Jurisdiction = Jurisdiction.PORTLAND
    edge_types: list[EdgeType] = []
    version: str = "0.1.0"

    def __init__(self, http_client: Optional[Any] = None) -> None:
        self.http = http_client

    @abstractmethod
    def _fetch_raw(self, since: Optional[datetime] = None) -> Iterator[dict]:
        """Yield raw upstream records. Implementer is responsible for
        pagination, rate limiting, and source-specific quirks."""
        ...

    @abstractmethod
    def _stamp(self, raw: dict) -> dict:
        """Attach Provenance to a raw record. Returns the record with
        a `provenance` key populated."""
        ...

    @abstractmethod
    def _normalize(self, stamped: dict) -> Optional[dict]:
        """Convert a stamped raw record to a normalized model-shaped dict
        (Official / Entity / Affiliation / Bill / Signal etc.).

        Return None if the record is not actionable (skip silently)."""
        ...

    def fetch(self, since: Optional[datetime] = None) -> FetchResult:
        """Full pipeline: raw -> stamp -> normalize -> validate.

        Failures collected, not raised, so a bad row doesn't kill the batch.
        """
        result = FetchResult(source_name=self.name)
        for raw in self._fetch_raw(since=since):
            result.items_seen += 1
            try:
                stamped = self._stamp(raw)
            except Exception as e:
                result.rejected.append((raw, f"STAMP_ERR: {e}"))
                continue
            try:
                normalized = self._normalize(stamped)
            except Exception as e:
                result.rejected.append((stamped, f"NORM_ERR: {e}"))
                continue
            if normalized is None:
                continue
            passed, reason = provenance_gate(normalized)
            if not passed:
                result.rejected.append((normalized, reason or "PROV_FAIL"))
                continue
            result.records.append(normalized)
        return result

    def __repr__(self) -> str:
        return (
            f"<{self.__class__.__name__} name={self.name!r} "
            f"jurisdiction={self.jurisdiction.value} v={self.version}>"
        )
