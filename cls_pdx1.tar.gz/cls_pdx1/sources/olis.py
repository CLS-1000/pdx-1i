"""
cls_pdx1.sources.olis
======================

Oregon Legislative Information System (OLIS).

Bill tracking backbone. Every bill state transition is a signal; sponsorship
and committee assignment are inputs to the legislative ties graph; witness
testimony with stated affiliation is an Affiliation edge into the entity graph.

Live OData v3 service:
  https://api.oregonlegislature.gov/odata/odataservice.svc

Collections used:
  - LegislativeSessions    Session metadata (year, R/S/I, begin/end dates)
  - Measures               Bills (HB, SB, HCR, HJM, etc.)
  - Legislators            Legislator roster per session
  - MeasureSponsors        Sponsor links (sponsor type, level, print order)
  - MeasureHistoryActions  State transition log per measure
  - MeasureVotes           Floor + committee votes

Two adapter classes here:
  - OlisAdapter            Fetches Measures; produces Bill-shaped records
  - OlisLegislatorAdapter  Fetches Legislators; produces Official-shaped records

Pagination: OData $skip + $top. Default $top=100 per page; capped at
max_records total to keep cycles bounded.
"""

from __future__ import annotations

import json
import urllib.parse
import urllib.request
from datetime import date, datetime
from typing import Any, Iterator, Optional

from ..models import (
    Bill,
    BillState,
    BillStateTransition,
    EdgeType,
    Jurisdiction,
    Provenance,
)
from . import SourceAdapter


OLIS_ODATA_BASE = "https://api.oregonlegislature.gov/odata/odataservice.svc"
OLIS_WEB_BASE = "https://olis.oregonlegislature.gov/liz/"

ODATA_PAGE_SIZE = 100
HTTP_TIMEOUT_SECONDS = 30


OLIS_STATUS_MAP: dict[str, BillState] = {
    "Introduction and first reading": BillState.INTRODUCED,
    "First reading.": BillState.INTRODUCED,
    "First reading": BillState.INTRODUCED,
    "Presession filed": BillState.INTRODUCED,
    "Referred to committee": BillState.COMMITTEE,
    "In committee": BillState.COMMITTEE,
    "In House Committee": BillState.COMMITTEE,
    "In Senate Committee": BillState.COMMITTEE,
    "Committee reported": BillState.COMMITTEE_REPORTED,
    "Third reading": BillState.FLOOR,
    "Passed": BillState.PASSED_CHAMBER,
    "Passed both chambers": BillState.PASSED_BOTH,
    "Enrolled": BillState.PASSED_BOTH,
    "Effective": BillState.ENACTED,
    "Signed by Governor": BillState.ENACTED,
    "Filed with Secretary of State": BillState.ENACTED,
    "Vetoed": BillState.VETOED,
    "Withdrawn": BillState.WITHDRAWN,
    "Failed": BillState.DEAD,
    "Died in committee": BillState.DEAD,
}


def map_olis_status(status_text: str) -> BillState:
    """Map raw OLIS status / current-location text to BillState.

    Substring fallback prefers longer (more specific) matches.
    """
    if not status_text:
        return BillState.INTRODUCED
    if status_text in OLIS_STATUS_MAP:
        return OLIS_STATUS_MAP[status_text]
    lowered = status_text.lower()
    for key, state in sorted(
        OLIS_STATUS_MAP.items(), key=lambda kv: -len(kv[0])
    ):
        if key.lower() in lowered or lowered in key.lower():
            return state
    return BillState.COMMITTEE


def _odata_fetch(
    collection: str,
    filter_clause: Optional[str] = None,
    top: int = ODATA_PAGE_SIZE,
    skip: int = 0,
    timeout: int = HTTP_TIMEOUT_SECONDS,
    base: str = OLIS_ODATA_BASE,
) -> dict:
    params = {"$format": "json", "$top": str(top), "$skip": str(skip)}
    if filter_clause:
        params["$filter"] = filter_clause
    url = f"{base}/{collection}?" + urllib.parse.urlencode(
        params, quote_via=urllib.parse.quote
    )
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8")
    return json.loads(body)


def _paged_odata_fetch(
    collection: str,
    filter_clause: Optional[str] = None,
    max_records: Optional[int] = None,
    page_size: int = ODATA_PAGE_SIZE,
    base: str = OLIS_ODATA_BASE,
) -> Iterator[dict]:
    skip = 0
    fetched = 0
    while True:
        page = _odata_fetch(
            collection=collection,
            filter_clause=filter_clause,
            top=page_size,
            skip=skip,
            base=base,
        )
        records = page.get("value", [])
        if not records:
            return
        for r in records:
            yield r
            fetched += 1
            if max_records is not None and fetched >= max_records:
                return
        if len(records) < page_size:
            return
        skip += page_size


# ---------------------------------------------------------------------------
# Measures adapter (Bill records)
# ---------------------------------------------------------------------------


class OlisAdapter(SourceAdapter):
    """OLIS measure / bill adapter.

    `live=True` (default when session_year provided): fetches Measures via
    OData using stdlib urllib. Otherwise raises NotImplementedError on
    _fetch_raw (preserves the original stub behavior for unit tests).
    """

    name = "olis"
    jurisdiction = Jurisdiction.OREGON
    edge_types = [EdgeType.TESTIMONY]
    version = "0.2.0"

    def __init__(
        self,
        http_client: Optional[Any] = None,
        session_year: Optional[int] = None,
        session_type: str = "R1",
        max_records: Optional[int] = None,
        live: Optional[bool] = None,
    ) -> None:
        super().__init__(http_client=http_client)
        self.session_year = session_year
        self.session_type = session_type
        self.max_records = max_records
        self.live = live if live is not None else (session_year is not None)

    @property
    def session_key(self) -> Optional[str]:
        if self.session_year is None:
            return None
        return f"{self.session_year}{self.session_type}"

    def _fetch_raw(self, since: Optional[datetime] = None) -> Iterator[dict]:
        if not self.live:
            raise NotImplementedError(
                "OlisAdapter is not in live mode. Pass session_year=YYYY or "
                "live=True to enable the OData fetch."
            )
        if not self.session_key:
            raise ValueError("session_year is required for live OLIS fetch")

        filt = f"SessionKey eq '{self.session_key}'"
        for raw_measure in _paged_odata_fetch(
            collection="Measures",
            filter_clause=filt,
            max_records=self.max_records,
        ):
            yield self._olis_measure_to_raw(raw_measure)

    def _olis_measure_to_raw(self, m: dict) -> dict:
        """Map a raw OLIS Measure record to the placeholder shape that
        _stamp/_normalize expect."""
        prefix = m.get("MeasurePrefix") or ""
        number = m.get("MeasureNumber")
        bill_id = f"{m.get('SessionKey', '')}-{prefix}{number}".strip("-")
        return {
            "bill_id": bill_id,
            "measure_prefix": prefix,
            "measure_number": number,
            "title": (m.get("CatchLine") or m.get("RelatingTo") or "")[:500],
            "introduced_date": None,
            "current_status": m.get("CurrentLocation") or "",
            "sponsors": [],
            "co_sponsors": [],
            "history": [],
            "text_url": None,
            "summary_raw": m.get("MeasureSummary") or "",
            "session_key": m.get("SessionKey"),
            "olis_measure_record": m,
        }

    def _stamp(self, raw: dict) -> dict:
        prefix = raw.get("measure_prefix", "")
        number = raw.get("measure_number", "")
        session_key = raw.get("session_key") or self.session_key or ""
        source_uri = raw.get("text_url") or (
            f"{OLIS_WEB_BASE}{session_key}/Measures/Overview/{prefix}{number}"
            if session_key
            else f"{OLIS_WEB_BASE}{prefix}{number}"
        )
        raw["provenance"] = Provenance(
            source_uri=source_uri,
            source_name="olis",
            fetched_at=datetime.utcnow(),
            adapter_version=self.version,
        )
        return raw

    def _normalize(self, stamped: dict) -> Optional[dict]:
        prefix = stamped.get("measure_prefix", "")
        number = stamped.get("measure_number", "")
        bill_number = (
            f"{prefix} {number}".strip() or stamped.get("bill_id", "unknown")
        )

        intro_date_raw = stamped.get("introduced_date")
        try:
            introduced_at = (
                date.fromisoformat(intro_date_raw)
                if intro_date_raw
                else date.today()
            )
        except (ValueError, TypeError):
            introduced_at = date.today()

        current_state = map_olis_status(stamped.get("current_status", ""))

        state_history: list[BillStateTransition] = []
        for h in stamped.get("history", []) or []:
            try:
                occurred_raw = h.get("date")
                if not occurred_raw:
                    continue
                occurred_at = datetime.fromisoformat(occurred_raw)
                to_state = map_olis_status(h.get("status", ""))
                state_history.append(
                    BillStateTransition(
                        from_state=None,
                        to_state=to_state,
                        occurred_at=occurred_at,
                        notes=h.get("status"),
                        provenance=stamped["provenance"],
                    )
                )
            except (ValueError, TypeError, KeyError):
                continue

        return {
            "jurisdiction": Jurisdiction.OREGON,
            "bill_number": bill_number,
            "title": stamped.get("title", "(no title)"),
            "introduced_at": introduced_at,
            "sponsor_ids": [],
            "co_sponsor_ids": [],
            "state": current_state,
            "state_history": state_history,
            "summary_raw": stamped.get("summary_raw") or stamped.get("title", ""),
            "summary_plain": None,
            "affected_entity_ids": [],
            "affected_sectors": [],
            "provenance": stamped["provenance"],
            "metadata": {
                "olis_bill_id": stamped.get("bill_id"),
                "session_key": stamped.get("session_key"),
                "sponsors_raw": stamped.get("sponsors", []),
                "co_sponsors_raw": stamped.get("co_sponsors", []),
            },
        }


# ---------------------------------------------------------------------------
# Legislators adapter (Official records)
# ---------------------------------------------------------------------------


class OlisLegislatorAdapter(SourceAdapter):
    """OLIS legislator roster adapter.

    Produces Official-shaped records (one per legislator in the given
    session). Used to enrich the seed with the full state-legislator
    layer, which is too dynamic to manage in the static seed JSON.
    """

    name = "olis_legislators"
    jurisdiction = Jurisdiction.OREGON
    edge_types: list = []
    version = "0.1.0"

    def __init__(
        self,
        http_client: Optional[Any] = None,
        session_year: Optional[int] = None,
        session_type: str = "R1",
        max_records: Optional[int] = None,
        live: Optional[bool] = None,
    ) -> None:
        super().__init__(http_client=http_client)
        self.session_year = session_year
        self.session_type = session_type
        self.max_records = max_records
        self.live = live if live is not None else (session_year is not None)

    @property
    def session_key(self) -> Optional[str]:
        if self.session_year is None:
            return None
        return f"{self.session_year}{self.session_type}"

    def _fetch_raw(self, since: Optional[datetime] = None) -> Iterator[dict]:
        if not self.live:
            raise NotImplementedError(
                "OlisLegislatorAdapter is not in live mode. Pass session_year=YYYY."
            )
        if not self.session_key:
            raise ValueError("session_year is required for live legislator fetch")
        filt = f"SessionKey eq '{self.session_key}'"
        for raw_leg in _paged_odata_fetch(
            collection="Legislators",
            filter_clause=filt,
            max_records=self.max_records,
        ):
            yield raw_leg

    def _stamp(self, raw: dict) -> dict:
        web_url = raw.get("WebSiteUrl") or (
            f"https://www.oregonlegislature.gov/{raw.get('LastName', '')}"
        )
        raw["provenance"] = Provenance(
            source_uri=web_url,
            source_name="olis_legislators",
            fetched_at=datetime.utcnow(),
            adapter_version=self.version,
        )
        return raw

    def _normalize(self, stamped: dict) -> Optional[dict]:
        first = (stamped.get("FirstName") or "").strip()
        last = (stamped.get("LastName") or "").strip()
        if not last:
            return None
        full_name = f"{first} {last}".strip()
        title = stamped.get("Title") or ""
        chamber = stamped.get("Chamber") or ""
        district = stamped.get("DistrictNumber") or ""
        party_raw = (stamped.get("Party") or "").strip()
        party_map = {"Democrat": "Democratic", "Republican": "Republican"}
        party = party_map.get(party_raw, party_raw or None)

        slug = (
            full_name.lower()
            .replace(" ", "-")
            .replace(".", "")
            .replace("'", "")
        )
        chamber_label = "house" if chamber == "H" else (
            "senate" if chamber == "S" else ""
        )
        official_id = f"off:oregon-state:{chamber_label}-{slug}".strip("-")

        role = f"Oregon State {title}, District {district}".strip(", ")

        session_key = stamped.get("SessionKey", "")
        try:
            ts_year = int(session_key[:4]) if session_key else date.today().year
        except ValueError:
            ts_year = date.today().year

        return {
            "id": official_id,
            "full_name": full_name,
            "aliases": (
                [stamped.get("LegislatorCode", "")]
                if stamped.get("LegislatorCode")
                else []
            ),
            "role": role,
            "district_id": None,
            "jurisdiction": Jurisdiction.OREGON,
            "party": party,
            "term_start": date(ts_year, 1, 1),
            "term_end": None,
            "status": "active",
            "provenance": stamped["provenance"],
            "metadata": {
                "olis_legislator_code": stamped.get("LegislatorCode"),
                "chamber": chamber,
                "district_number": district,
                "capitol_phone": stamped.get("CapitolPhone"),
                "email": stamped.get("EmailAddress"),
                "session_key": session_key,
            },
        }


__all__ = [
    "OlisAdapter",
    "OlisLegislatorAdapter",
    "OLIS_ODATA_BASE",
    "OLIS_STATUS_MAP",
    "map_olis_status",
]
