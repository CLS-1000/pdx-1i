"""
cls_pdx1.neutrality
====================

Neutrality enforced as code, not editorial habit.

Three gates:
  - tone_gate: detects loaded vocabulary against a verb whitelist + blacklist.
  - attribution_gate: every factual claim carries source_uri and in-prose attribution.
  - hedging_gate: detects unattributed characterization ("clearly", "obviously",
    "shockingly", etc).

The Metro Citizens Brief mission: residents form their own conclusions from
primary-source-attributed facts. The newsletter does not characterize; it
narrates what documents show and what entities said on the record.
"""

from __future__ import annotations

import re
from typing import Optional


# ---------------------------------------------------------------------------
# Verb policy
# ---------------------------------------------------------------------------


# Loaded verbs that frame action with editorial valence. Rejected at tone gate.
LOADED_VERBS: frozenset[str] = frozenset(
    {
        "admitted",
        "claimed",
        "denied",
        "alleged",
        "asserted",
        "slammed",
        "blasted",
        "lambasted",
        "decried",
        "revealed",
        "exposed",
        "unmasked",
        "called out",
        "hit back",
        "fired back",
        "lashed out",
        "doubled down",
        "tore into",
        "ripped",
        "shredded",
        "demolished",
        "savaged",
        "skewered",
        "eviscerated",
        "torched",
        "roasted",
        "schooled",
        "owned",
        "destroyed",
        "obliterated",
        "boasted",
        "bragged",
        "gloated",
        "whined",
        "moaned",
        "complained",
        "grumbled",
        "snapped",
        "barked",
        "growled",
        "scolded",
        "warned darkly",
        "ominously",
        "refused to address",
        "dodged",
        "deflected",
        "stonewalled",
    }
)


# Neutral verbs that describe actions without coloring. Preferred vocabulary.
NEUTRAL_VERBS: frozenset[str] = frozenset(
    {
        "said",
        "stated",
        "wrote",
        "responded",
        "answered",
        "told",
        "noted",
        "voted",
        "proposed",
        "introduced",
        "filed",
        "submitted",
        "testified",
        "announced",
        "issued",
        "approved",
        "rejected",
        "amended",
        "withdrew",
        "voted against",
        "voted for",
        "abstained",
        "declined to comment",
        "did not respond",
        "did not respond by deadline",
        "confirmed",
        "disclosed",
        "reported",
        "described",
        "characterized",
    }
)


# Unattributed characterization that smuggles in editorial voice. Rejected
# unless followed by an explicit attribution clause.
HEDGING_TERMS: frozenset[str] = frozenset(
    {
        "clearly",
        "obviously",
        "evidently",
        "plainly",
        "undoubtedly",
        "of course",
        "naturally",
        "shockingly",
        "alarmingly",
        "tellingly",
        "remarkably",
        "stunningly",
        "incredibly",
        "unsurprisingly",
        "predictably",
        "controversial",
        "controversially",
        "scandalous",
        "scandalously",
        "outrageous",
        "outrageously",
        "egregious",
        "egregiously",
    }
)


# ---------------------------------------------------------------------------
# Tone gate
# ---------------------------------------------------------------------------


def tone_gate(text: str) -> tuple[bool, list[str]]:
    """Scan text for loaded vocabulary.

    Returns (passed, violations). Each violation is the offending term.

    Word-boundary matching for single tokens. Multi-word phrases matched as
    substrings (case-insensitive).
    """
    if not text:
        return True, []

    text_lower = text.lower()
    violations: list[str] = []

    for term in LOADED_VERBS:
        if " " in term:
            if term in text_lower:
                violations.append(term)
        else:
            if re.search(rf"\b{re.escape(term)}\b", text_lower):
                violations.append(term)

    return len(violations) == 0, sorted(set(violations))


def hedging_gate(text: str) -> tuple[bool, list[str]]:
    """Scan text for unattributed characterization."""
    if not text:
        return True, []

    text_lower = text.lower()
    violations: list[str] = []

    for term in HEDGING_TERMS:
        if " " in term:
            if term in text_lower:
                violations.append(term)
        else:
            if re.search(rf"\b{re.escape(term)}\b", text_lower):
                violations.append(term)

    return len(violations) == 0, sorted(set(violations))


# ---------------------------------------------------------------------------
# Attribution gate
# ---------------------------------------------------------------------------


ATTRIBUTION_MARKERS: tuple[str, ...] = (
    "according to",
    "said",
    "stated",
    "wrote",
    "filed",
    "reported by",
    "as reported by",
    "per ",
    "in a statement",
    "in testimony",
    "in an interview with",
    "in a filing",
    "in a press release",
    "in a memo",
    "in a letter",
    "in an email",
    "told ",
)


def attribution_gate(text: str, has_source_uri: bool) -> tuple[bool, Optional[str]]:
    """A claim with factual force must carry attribution AND a source_uri.

    The source_uri half is structural (record-level). The attribution half is
    in-prose: the sentence references the source.
    """
    if not text:
        return True, None

    has_attribution_marker = any(marker in text.lower() for marker in ATTRIBUTION_MARKERS)

    if has_source_uri and has_attribution_marker:
        return True, None

    if has_source_uri and not has_attribution_marker:
        return False, "ATTR_001: source_uri present but in-prose attribution missing"

    if not has_source_uri and has_attribution_marker:
        return False, "ATTR_002: in-prose attribution present but source_uri missing"

    return False, "ATTR_003: claim lacks both source_uri and in-prose attribution"


# ---------------------------------------------------------------------------
# Composite section gate (used at publication assembly)
# ---------------------------------------------------------------------------


def section_neutrality_gate(
    body: str, cited_source_uris: list[str]
) -> tuple[bool, list[str]]:
    """Full neutrality gate for a publication section."""
    violations: list[str] = []

    tone_ok, tone_viol = tone_gate(body)
    if not tone_ok:
        violations.extend(f"tone:{t}" for t in tone_viol)

    hedge_ok, hedge_viol = hedging_gate(body)
    if not hedge_ok:
        violations.extend(f"hedge:{t}" for t in hedge_viol)

    has_sources = len(cited_source_uris) > 0
    attr_ok, attr_reason = attribution_gate(body, has_sources)
    if not attr_ok and attr_reason:
        violations.append(f"attr:{attr_reason}")

    return len(violations) == 0, violations


__all__ = [
    "LOADED_VERBS",
    "NEUTRAL_VERBS",
    "HEDGING_TERMS",
    "ATTRIBUTION_MARKERS",
    "tone_gate",
    "hedging_gate",
    "attribution_gate",
    "section_neutrality_gate",
]
