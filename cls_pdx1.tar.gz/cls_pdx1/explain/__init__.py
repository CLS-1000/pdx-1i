"""
cls_pdx1.explain
=================

Plain-language explain layer.

Mission: residents understand legislative actions in their own terms. Every
bill, ordinance, and council decision tracked by PDX-1i gets a plain-language
summary alongside the raw source link.

Two-pass design:
  1. Generate summary via Claude API with a locked, neutrality-aware prompt.
  2. Run summary through neutrality gates (tone, hedging, attribution).
     If gates fail, regenerate with strengthened constraint or fall back to
     raw-text excerpt + "summary unavailable due to gate failure" marker.

The raw source is always one click away in the published brief. The summary
is auxiliary, not authoritative.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

from ..neutrality import section_neutrality_gate


# Locked prompt. Edit only by versioning a new prompt and recording the
# adapter_version bump on every output.
PLAIN_LANGUAGE_PROMPT_V1 = """You are summarizing a legislative document for residents \
of the Portland metropolitan area. The audience is the general public, not lawyers \
or analysts. They want to know what this document does, who proposed it, and what \
happens next.

Strict rules:
1. Use only neutral verbs: said, stated, voted, proposed, introduced, filed, \
testified, announced, approved, rejected, amended, withdrew.
2. Do not use: admitted, claimed, denied, alleged, slammed, blasted, revealed, \
exposed, doubled down, hit back, controversial, scandalous, outrageous, clearly, \
obviously, shockingly, alarmingly, tellingly.
3. Do not characterize motivations or intent. State only what the document says \
and what action it takes.
4. Do not predict outcomes or consequences. Describe what the proposed measure \
would do procedurally; do not editorialize.
5. Plain language: avoid legalese. Define any necessary jargon inline.
6. Maximum 200 words.
7. Structure your output as:
   WHAT IT DOES: (2-4 sentences)
   WHO PROPOSED IT: (1 sentence with sponsor name + district)
   CURRENT STATUS: (1 sentence with bill state)
   PUBLIC INPUT: (1 sentence on next hearing or comment deadline, if known)

If any fact is not in the document, write "(not stated)" rather than inferring.

Document text:
---
{document_text}
---

Additional context (sponsor, status, next action):
---
{context}
---
"""


@dataclass
class SummaryResult:
    """Output of a summarization attempt."""

    summary_plain: Optional[str]
    passed_gates: bool
    gate_violations: list[str]
    prompt_version: str
    raw_excerpt_fallback: Optional[str] = None


class ExplainEngine:
    """Plain-language summarizer with neutrality gates.

    Concrete LLM call is injected via a `summarize_fn` callable that takes a
    prompt string and returns a string. This keeps the engine testable and
    swappable between Claude API / local model / fixture.
    """

    def __init__(
        self,
        summarize_fn=None,
        prompt: str = PLAIN_LANGUAGE_PROMPT_V1,
        prompt_version: str = "v1",
        max_retries: int = 1,
    ) -> None:
        self.summarize_fn = summarize_fn or self._default_summarize_fn
        self.prompt = prompt
        self.prompt_version = prompt_version
        self.max_retries = max_retries

    def summarize(
        self,
        document_text: str,
        context: str = "",
        cited_source_uris: Optional[list[str]] = None,
    ) -> SummaryResult:
        """Produce a plain-language summary, gated for neutrality.

        If the first pass fails gates, the engine retries with a strengthened
        constraint up to max_retries times. After exhausting retries, returns
        a SummaryResult with passed_gates=False and a raw-text fallback.
        """
        cited = cited_source_uris or []
        attempts = 0
        last_violations: list[str] = []

        while attempts <= self.max_retries:
            prompt = self.prompt.format(
                document_text=document_text.strip(),
                context=context.strip() or "(none)",
            )
            if attempts > 0:
                prompt += (
                    "\n\nRetry: previous attempt violated neutrality gates: "
                    f"{', '.join(last_violations)}. Rewrite using only the "
                    "neutral vocabulary listed in rule 1."
                )
            summary = self.summarize_fn(prompt)
            passed, violations = section_neutrality_gate(summary, cited)
            if passed:
                return SummaryResult(
                    summary_plain=summary.strip(),
                    passed_gates=True,
                    gate_violations=[],
                    prompt_version=self.prompt_version,
                )
            last_violations = violations
            attempts += 1

        # Exhausted retries — fall back to raw excerpt
        return SummaryResult(
            summary_plain=None,
            passed_gates=False,
            gate_violations=last_violations,
            prompt_version=self.prompt_version,
            raw_excerpt_fallback=self._excerpt(document_text, max_chars=600),
        )

    @staticmethod
    def _excerpt(text: str, max_chars: int = 600) -> str:
        text = (text or "").strip()
        if len(text) <= max_chars:
            return text
        return text[: max_chars - 1].rstrip() + "…"

    @staticmethod
    def _default_summarize_fn(prompt: str) -> str:
        """Default no-op summarize function.

        Production wiring should pass an anthropic-API-backed function.
        Without a wired callable, this returns a clear placeholder rather
        than fabricating content.
        """
        return (
            "WHAT IT DOES: (summary unavailable, ExplainEngine not configured "
            "with a backing LLM call).\nWHO PROPOSED IT: (not stated).\n"
            "CURRENT STATUS: (not stated).\nPUBLIC INPUT: (not stated)."
        )


def claude_api_summarize_factory(model: str = "claude-opus-4-7"):
    """Factory for a summarize_fn backed by the Anthropic Messages API.

    Returns a callable that takes a prompt string and returns text content.
    Reads ANTHROPIC_API_KEY from environment. Returns a stub if anthropic
    package is not installed.
    """
    try:
        import anthropic  # type: ignore
    except ImportError:
        def _stub(prompt: str) -> str:
            return ExplainEngine._default_summarize_fn(prompt)
        return _stub

    client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

    def _call(prompt: str) -> str:
        msg = client.messages.create(
            model=model,
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}],
        )
        # Extract text from response content blocks
        parts = []
        for block in msg.content:
            if hasattr(block, "text"):
                parts.append(block.text)
        return "\n".join(parts)

    return _call


__all__ = [
    "PLAIN_LANGUAGE_PROMPT_V1",
    "SummaryResult",
    "ExplainEngine",
    "claude_api_summarize_factory",
]
