# `data/external/`

Supplementary data files that came from outside the seed loader's main path
(`load_all()` returns districts + officials + entities). Each file has its
own loader and its own gates.

These files have weaker provenance than the main seed because:
- They aggregate data from session-based AI research with documented caveats
- They are intentionally transit data destined for other modules
- The schema is not enforced by `cls_pdx1.models`

The bar for graduating a file from `external/` to the main seed is:
- Every record carries a primary-source `source_uri` that passes
  `provenance_gate()`
- Every claim is verifiable today without re-running the original session
- The data type maps cleanly to an existing model (`District`, `Official`,
  `Entity`, `Affiliation`, etc.)

## Files

### `x_handles.json`
X (Twitter) handle data per Official. Two found, 25 documented absences.
The two found handles both carry caveats:
- `@MayorKWilson`: stale, ~1,431 followers, last post 2025-08-21
- `@kanalforpdx`: superseded by `@CouncilorKanal` per the account's own
  bio

The 25 nulls are not failures — they record genuine absence of X presence
for those officials. Roughly two-thirds of Portland-area officials have no
findable X account under their own names.

Origin: Grok v3 research session 2026-05-22.

### `media_coverage_patterns.jsonl`
Observational data about news-cycle framing convergence during the May
2026 Portland City Council budget vote. **Not PSYOP training data.**

Originally produced by Grok v2 (2026-05-22) as a "psyop_corpus.jsonl"
output, but analysis showed Grok could not reliably distinguish normal
news convergence from coordinated influence operations. The X posts are
real; the analytical category was wrong.

Reframed as transit data for a future `cls_psyop.framing_convergence`
signature that scores news-cycle convergence without claiming
coordination. Until that signature exists, this file is observational
only.

Each record carries:
- `_grok_original_signature` — the misclassified label Grok assigned
- `_relabeling_note` — why the original label was wrong

Cluster 03 and cluster 06 are duplicates and should be merged before any
downstream use.

## What is NOT in `external/`

- Seed records (districts, officials, entities) — those live in the main
  `data/` directory and load via `cls_pdx1.data.load_all()`
- Source adapter output — that flows through the pipeline, not the seed
- Anything that needs to be cited from a Metro Citizens Brief — those
  citations should go through `verification_refs.yaml` at the `data/`
  level, not here
