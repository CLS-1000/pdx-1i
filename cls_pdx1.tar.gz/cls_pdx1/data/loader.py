"""
cls_pdx1.data.loader
=====================

Seed data loader. Reads the JSON seed files, validates them through the
Pydantic models, and runs the provenance gate on every record before
returning. Append-only: callers receive new model instances; the JSON on
disk is treated as immutable reference.

Public surface:
  load_districts()    -> list[District]
  load_officials()    -> list[Official]
  load_entities()     -> list[Entity]
  load_all()          -> SeedBundle (named tuple with districts, officials, entities)
  verify_seed()       -> SeedReport (counts + any gate failures)

If a record fails its provenance gate it is dropped from the returned list
and recorded in the SeedReport. The loader never raises on a bad row —
mirrors the pipeline's failure-first stance.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from pydantic import ValidationError

from ..gates import (
    provenance_gate,
    run_gates,
    time_bounding_gate,
)
from ..models import (
    Affiliation,
    District,
    Entity,
    Official,
)


_HERE = Path(__file__).resolve().parent
DISTRICTS_JSON = _HERE / "districts_seed.json"
OFFICIALS_JSON = _HERE / "officials_seed.json"
ENTITIES_JSON = _HERE / "entities_seed.json"
VERIFICATION_REFS_YAML = _HERE / "verification_refs.yaml"
X_HANDLES_JSON = _HERE / "external" / "x_handles.json"
MEDIA_COVERAGE_JSONL = _HERE / "external" / "media_coverage_patterns.jsonl"


@dataclass
class SeedBundle:
    districts: list[District] = field(default_factory=list)
    officials: list[Official] = field(default_factory=list)
    entities: list[Entity] = field(default_factory=list)

    @property
    def district_ids(self) -> set[str]:
        return {d.id for d in self.districts}

    @property
    def official_ids(self) -> set[str]:
        return {o.id for o in self.officials}

    @property
    def entity_ids(self) -> set[str]:
        return {e.id for e in self.entities}

    @property
    def watch_listed(self) -> list[Entity]:
        return [e for e in self.entities if e.is_watch_listed]


@dataclass
class SeedReport:
    """Summary of a seed load. Useful for CI smoke checks and audits."""

    district_count: int = 0
    official_count: int = 0
    entity_count: int = 0
    watch_listed_count: int = 0
    validation_failures: list[tuple[str, str]] = field(default_factory=list)
    gate_failures: list[tuple[str, str]] = field(default_factory=list)
    orphan_district_refs: list[str] = field(default_factory=list)

    @property
    def total_failures(self) -> int:
        return (
            len(self.validation_failures)
            + len(self.gate_failures)
            + len(self.orphan_district_refs)
        )

    def summary(self) -> str:
        lines = [
            f"Seed report:",
            f"  Districts:     {self.district_count}",
            f"  Officials:     {self.official_count}",
            f"  Entities:      {self.entity_count}",
            f"  Watch-listed:  {self.watch_listed_count}",
            f"  Failures:      {self.total_failures}",
        ]
        if self.validation_failures:
            lines.append(f"  Validation failures ({len(self.validation_failures)}):")
            for rid, reason in self.validation_failures:
                lines.append(f"    - {rid}: {reason}")
        if self.gate_failures:
            lines.append(f"  Gate failures ({len(self.gate_failures)}):")
            for rid, reason in self.gate_failures:
                lines.append(f"    - {rid}: {reason}")
        if self.orphan_district_refs:
            lines.append(
                f"  Orphan district references ({len(self.orphan_district_refs)}):"
            )
            for rid in self.orphan_district_refs:
                lines.append(f"    - {rid}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Low-level: read JSON, validate, gate
# ---------------------------------------------------------------------------


def _read_json(path: Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _validate_records(
    raw_records: list[dict],
    model: type,
    report: SeedReport,
) -> list[Any]:
    """Validate each record against `model`, dropping failures into the report."""
    out: list[Any] = []
    for raw in raw_records:
        rid = raw.get("id") or "<unknown>"
        try:
            obj = model.model_validate(raw)
        except ValidationError as e:
            report.validation_failures.append((rid, str(e).splitlines()[0]))
            continue
        passed, reason = provenance_gate(obj)
        if not passed:
            report.gate_failures.append((rid, reason or "PROV_FAIL"))
            continue
        out.append(obj)
    return out


# ---------------------------------------------------------------------------
# Public loaders
# ---------------------------------------------------------------------------


def load_districts(path: Optional[Path] = None) -> tuple[list[District], SeedReport]:
    """Load districts seed. Returns (districts, partial report)."""
    path = path or DISTRICTS_JSON
    data = _read_json(path)
    report = SeedReport()
    districts = _validate_records(data.get("records", []), District, report)
    report.district_count = len(districts)
    return districts, report


def load_officials(
    path: Optional[Path] = None,
    known_district_ids: Optional[set[str]] = None,
) -> tuple[list[Official], SeedReport]:
    """Load officials seed. Returns (officials, partial report).

    If known_district_ids is provided, officials whose district_id is not
    in the set are still returned but flagged as orphan_district_refs.
    """
    path = path or OFFICIALS_JSON
    data = _read_json(path)
    report = SeedReport()
    officials = _validate_records(data.get("records", []), Official, report)
    report.official_count = len(officials)
    if known_district_ids is not None:
        for o in officials:
            if o.district_id and o.district_id not in known_district_ids:
                report.orphan_district_refs.append(
                    f"{o.id}->{o.district_id}"
                )
    return officials, report


def load_entities(path: Optional[Path] = None) -> tuple[list[Entity], SeedReport]:
    """Load entities seed. Returns (entities, partial report)."""
    path = path or ENTITIES_JSON
    data = _read_json(path)
    report = SeedReport()
    entities = _validate_records(data.get("records", []), Entity, report)
    report.entity_count = len(entities)
    report.watch_listed_count = sum(1 for e in entities if e.is_watch_listed)
    return entities, report


# ---------------------------------------------------------------------------
# Composite loader
# ---------------------------------------------------------------------------


def load_all(
    districts_path: Optional[Path] = None,
    officials_path: Optional[Path] = None,
    entities_path: Optional[Path] = None,
) -> tuple[SeedBundle, SeedReport]:
    """Load all three seeds, return the combined bundle plus a unified report.

    Cross-validates: officials whose district_id does not resolve to a real
    district are flagged in `report.orphan_district_refs`.
    """
    districts, d_report = load_districts(districts_path)
    entities, e_report = load_entities(entities_path)
    officials, o_report = load_officials(
        officials_path, known_district_ids={d.id for d in districts}
    )

    bundle = SeedBundle(
        districts=districts,
        officials=officials,
        entities=entities,
    )

    report = SeedReport(
        district_count=d_report.district_count,
        official_count=o_report.official_count,
        entity_count=e_report.entity_count,
        watch_listed_count=e_report.watch_listed_count,
        validation_failures=(
            d_report.validation_failures
            + o_report.validation_failures
            + e_report.validation_failures
        ),
        gate_failures=(
            d_report.gate_failures
            + o_report.gate_failures
            + e_report.gate_failures
        ),
        orphan_district_refs=o_report.orphan_district_refs,
    )
    return bundle, report


# ---------------------------------------------------------------------------
# Verification entry point (for CI / smoke check)
# ---------------------------------------------------------------------------


def verify_seed() -> SeedReport:
    """Load and verify all seed files. Return the combined report.

    Suitable for a CI step:
        from cls_pdx1.data.loader import verify_seed
        report = verify_seed()
        assert report.total_failures == 0, report.summary()
    """
    _, report = load_all()
    return report


__all__ = [
    "SeedBundle",
    "SeedReport",
    "DISTRICTS_JSON",
    "OFFICIALS_JSON",
    "ENTITIES_JSON",
    "VERIFICATION_REFS_YAML",
    "X_HANDLES_JSON",
    "MEDIA_COVERAGE_JSONL",
    "load_districts",
    "load_officials",
    "load_entities",
    "load_all",
    "verify_seed",
    "load_verification_refs",
    "load_x_handles",
    "load_media_coverage_patterns",
]


# ---------------------------------------------------------------------------
# Supplementary data loaders (separate from the Pydantic-validated seed)
# ---------------------------------------------------------------------------


def load_verification_refs(path: Optional[Path] = None) -> dict:
    """Load the verification_refs.yaml citation pool.

    Returns the parsed YAML as a dict. The loader does not validate against
    Pydantic models — `verification_refs.yaml` is supporting reference data,
    not canonical records. Schema is documented inline in the YAML file.
    """
    path = path or VERIFICATION_REFS_YAML
    if not path.exists():
        return {"schema_version": "1", "records": []}
    try:
        import yaml  # type: ignore
    except ImportError:
        raise ImportError(
            "load_verification_refs requires PyYAML. Install via: "
            "pip install pyyaml"
        )
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def load_x_handles(path: Optional[Path] = None) -> dict:
    """Load the x_handles.json supplementary data.

    Returns the full dict including warnings, records (handles that exist),
    and documented_absences. Callers should respect the `status` field on
    each record (e.g., 'needs_verification', 'superseded') — these are not
    drop-in primary sources.
    """
    path = path or X_HANDLES_JSON
    if not path.exists():
        return {"schema_version": "1", "records": [], "documented_absences": []}
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def load_media_coverage_patterns(path: Optional[Path] = None) -> list[dict]:
    """Load media_coverage_patterns.jsonl observational data.

    Returns one dict per cluster. The first line is a header record (begins
    with `_header`); it is skipped. Each cluster carries
    `_grok_original_signature` and `_relabeling_note` metadata indicating
    the original Grok misclassification.

    This file is transit data for a future cls_psyop framing_convergence
    signature — not training data for the existing PSYOP signatures.
    """
    path = path or MEDIA_COVERAGE_JSONL
    if not path.exists():
        return []
    clusters: list[dict] = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "_header" in rec:
                continue
            clusters.append(rec)
    return clusters
