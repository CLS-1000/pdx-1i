"""
cls_pdx1.data
==============

Seed data + loaders. Districts, officials, entities are stored as JSON in
this directory and loaded through `loader.py`, which validates every record
against the Pydantic models and runs the provenance gate.

The JSON files are treated as immutable reference data. Updates to current
office-holders happen through the normal pipeline (e.g., periodic re-fetch
from authoritative sources, append-only writes to cls_db), not by mutating
the seed JSON directly.
"""

from .loader import (
    DISTRICTS_JSON,
    ENTITIES_JSON,
    MEDIA_COVERAGE_JSONL,
    OFFICIALS_JSON,
    SeedBundle,
    SeedReport,
    VERIFICATION_REFS_YAML,
    X_HANDLES_JSON,
    load_all,
    load_districts,
    load_entities,
    load_media_coverage_patterns,
    load_officials,
    load_verification_refs,
    load_x_handles,
    verify_seed,
)

__all__ = [
    "DISTRICTS_JSON",
    "ENTITIES_JSON",
    "MEDIA_COVERAGE_JSONL",
    "OFFICIALS_JSON",
    "SeedBundle",
    "SeedReport",
    "VERIFICATION_REFS_YAML",
    "X_HANDLES_JSON",
    "load_all",
    "load_districts",
    "load_entities",
    "load_media_coverage_patterns",
    "load_officials",
    "load_verification_refs",
    "load_x_handles",
    "verify_seed",
]
