"""
cls_pdx1.watch
===============

Watch list: per-entity monitors that produce signals and feed anomaly
detection.

Each watch module:
  - Wraps one or more source adapters
  - Filters / scores incoming records for relevance to its watched entity
  - Emits Signal records for downstream anomaly detection

Anchor entities (Portland metro):
  PGE              — utility, public co. (SEC EDGAR + ORESTAR + PUC + lobbying)
  NW Natural       — utility (PUC + ORESTAR + lobbying)
  Portland Water   — city bureau (council budget + contracts + decisions)
  TriMet           — transit agency (board actions + contracts + ridership data)
  Portland Police  — city bureau (budget + council votes + oversight actions)
  OHSU             — academic medical (gubernatorial board + foundation 990 + OHA)
  Schnitzer        — family + companies (donations + property + lobbying)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Iterator, Optional

from ..models import Sector, Signal


@dataclass(frozen=True)
class WatchAnchor:
    """Static definition of a watch-list anchor entity."""

    slug: str  # canonical identifier
    canonical_name: str
    aliases: tuple[str, ...]
    sector_tags: tuple[Sector, ...]
    watch_priority: int  # 1 = highest
    monitored_signals: tuple[str, ...]  # signal kinds this anchor cares about


# Canonical watch-list anchors. These are seeded into the Entity table on
# first run and have is_watch_listed=True.
ANCHORS: tuple[WatchAnchor, ...] = (
    WatchAnchor(
        slug="pge",
        canonical_name="Portland General Electric",
        aliases=("PGE", "Portland General", "Portland General Electric Company"),
        sector_tags=(Sector.UTILITY,),
        watch_priority=1,
        monitored_signals=(
            "rate_filing",
            "lobbying_expenditure",
            "donation_received",
            "donation_made",
            "board_change",
            "sec_filing",
            "puc_docket_filing",
        ),
    ),
    WatchAnchor(
        slug="nw_natural",
        canonical_name="Northwest Natural Gas Company",
        aliases=("NW Natural", "NWN", "Northwest Natural", "NW Natural Gas"),
        sector_tags=(Sector.UTILITY,),
        watch_priority=1,
        monitored_signals=(
            "rate_filing",
            "lobbying_expenditure",
            "donation_received",
            "donation_made",
            "board_change",
            "sec_filing",
            "puc_docket_filing",
        ),
    ),
    WatchAnchor(
        slug="portland_water_bureau",
        canonical_name="Portland Water Bureau",
        aliases=("Water Bureau", "PWB", "Portland Bureau of Water"),
        sector_tags=(Sector.UTILITY,),
        watch_priority=1,
        monitored_signals=(
            "budget_line_change",
            "contract_award",
            "council_vote",
            "rate_change",
            "capital_project",
        ),
    ),
    WatchAnchor(
        slug="trimet",
        canonical_name="Tri-County Metropolitan Transportation District",
        aliases=("TriMet", "Tri-Met"),
        sector_tags=(Sector.TRANSIT,),
        watch_priority=1,
        monitored_signals=(
            "board_vote",
            "contract_award",
            "service_change",
            "fare_change",
            "labor_agreement",
        ),
    ),
    WatchAnchor(
        slug="ppb",
        canonical_name="Portland Police Bureau",
        aliases=("PPB", "Portland Police", "Bureau of Police"),
        sector_tags=(Sector.PUBLIC_SAFETY,),
        watch_priority=1,
        monitored_signals=(
            "budget_line_change",
            "council_vote",
            "oversight_action",
            "personnel_action",
            "use_of_force_report",
        ),
    ),
    WatchAnchor(
        slug="ohsu",
        canonical_name="Oregon Health & Science University",
        aliases=("OHSU",),
        sector_tags=(Sector.HEALTHCARE, Sector.EDUCATION),
        watch_priority=1,
        monitored_signals=(
            "board_appointment",
            "foundation_grant",
            "oha_action",
            "lobbying_expenditure",
            "research_funding",
            "leadership_change",
        ),
    ),
    WatchAnchor(
        slug="schnitzer",
        canonical_name="Schnitzer (family + affiliated entities)",
        aliases=(
            "Schnitzer",
            "Schnitzer Steel",
            "Schnitzer Properties",
            "Harsch Investment Properties",
        ),
        sector_tags=(Sector.REAL_ESTATE, Sector.CONSTRUCTION),
        watch_priority=2,
        monitored_signals=(
            "property_transaction",
            "donation_made",
            "lobbying_expenditure",
            "zoning_action",
            "contract_award",
        ),
    ),
)


def anchor_by_slug(slug: str) -> Optional[WatchAnchor]:
    for a in ANCHORS:
        if a.slug == slug:
            return a
    return None


class WatchModule(ABC):
    """Base class for per-entity watch modules.

    Subclasses bind to one WatchAnchor and define how raw signals are
    extracted / scored for their entity.
    """

    anchor: WatchAnchor

    def __init__(self, anchor: WatchAnchor) -> None:
        self.anchor = anchor

    @abstractmethod
    def extract_signals(
        self, records: list[dict], since: Optional[datetime] = None
    ) -> Iterator[Signal]:
        """Given a batch of source records, yield Signals relevant to this anchor."""
        ...

    def matches_anchor(self, text: str) -> bool:
        """Case-insensitive substring match against canonical name or aliases."""
        if not text:
            return False
        t = text.lower()
        if self.anchor.canonical_name.lower() in t:
            return True
        return any(alias.lower() in t for alias in self.anchor.aliases)

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} anchor={self.anchor.slug}>"


__all__ = ["WatchAnchor", "WatchModule", "ANCHORS", "anchor_by_slug"]
