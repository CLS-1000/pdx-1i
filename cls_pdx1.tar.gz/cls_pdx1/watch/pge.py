"""
cls_pdx1.watch.pge
===================

Portland General Electric watch module.

Watches for:
  - PUC rate case filings (Docket UE-xxx, UM-xxx)
  - Lobbying expenditures on Oregon legislature lobby reports
  - ORESTAR donations made by PGE PAC, employee PAC, or executives
  - SEC EDGAR filings: insider trades, 8-K material events, board changes
  - Council/commission votes touching PGE franchise or rate matters

This module operates on already-ingested records from sibling source adapters;
it does not fetch data itself. The pipeline composes adapter output and routes
it through each WatchModule.
"""

from __future__ import annotations

from datetime import datetime
from typing import Iterator, Optional

from ..models import Provenance, Signal
from . import WatchModule, anchor_by_slug


class PgeWatch(WatchModule):
    def __init__(self) -> None:
        anchor = anchor_by_slug("pge")
        if anchor is None:
            raise RuntimeError("PGE anchor not registered in ANCHORS")
        super().__init__(anchor)

    def extract_signals(
        self, records: list[dict], since: Optional[datetime] = None
    ) -> Iterator[Signal]:
        """Scan a batch of normalized records for PGE-relevant events.

        Records come from the pipeline already provenance-stamped and
        normalized into model-shaped dicts. This module classifies and
        emits Signals.
        """
        for r in records:
            # Donation records (from ORESTAR adapter)
            if "amount_usd" in r and r.get("amount_usd"):
                contributor = (
                    r.get("metadata", {}).get("contributor_name_raw") or ""
                ).strip()
                committee = (
                    r.get("metadata", {}).get("committee_name_raw") or ""
                ).strip()
                if self.matches_anchor(contributor):
                    yield self._signal(
                        kind="donation_made",
                        occurred_at=r.get("observed_at", datetime.utcnow()),
                        value=float(r["amount_usd"]),
                        payload={
                            "to_committee": committee,
                            "raw_contributor": contributor,
                        },
                        provenance=r.get("provenance"),
                    )
                elif self.matches_anchor(committee):
                    yield self._signal(
                        kind="donation_received",
                        occurred_at=r.get("observed_at", datetime.utcnow()),
                        value=float(r["amount_usd"]),
                        payload={
                            "from_contributor": contributor,
                            "raw_committee": committee,
                        },
                        provenance=r.get("provenance"),
                    )

            # Bill records (from OLIS adapter) — flag bills affecting PGE
            if "bill_number" in r and "title" in r:
                title = r.get("title", "") + " " + (r.get("summary_raw") or "")
                if self.matches_anchor(title) or self._utility_legislation(title):
                    yield self._signal(
                        kind="bill_affecting_pge",
                        occurred_at=datetime.utcnow(),
                        value=None,
                        payload={
                            "bill_number": r.get("bill_number"),
                            "title": r.get("title"),
                            "state": str(r.get("state")),
                        },
                        provenance=r.get("provenance"),
                    )

    def _utility_legislation(self, text: str) -> bool:
        """Heuristic: bills mentioning electric utility, ratepayer, PUC, etc.,
        even without naming PGE directly, are flagged for review."""
        keywords = (
            "electric utility",
            "investor-owned utility",
            "ratepayer",
            "public utility commission",
            "energy trust",
            "decoupling",
            "wildfire mitigation",
        )
        t = text.lower()
        return any(k in t for k in keywords)

    def _signal(
        self,
        kind: str,
        occurred_at: datetime,
        value: Optional[float],
        payload: dict,
        provenance: Optional[Provenance],
    ) -> Signal:
        if provenance is None:
            raise ValueError("PgeWatch._signal called without provenance")
        return Signal(
            kind=kind,
            occurred_at=occurred_at,
            detected_at=datetime.utcnow(),
            value=value,
            payload=payload,
            provenance=provenance,
        )


__all__ = ["PgeWatch"]
