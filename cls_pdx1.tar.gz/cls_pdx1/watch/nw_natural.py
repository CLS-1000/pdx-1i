"""
cls_pdx1.watch.nw_natural
==========================

Northwest Natural Gas Company watch module.

Pairs structurally with PgeWatch — both are utilities, both regulated by
the Oregon PUC, both with WA-side service territory. The pair is useful
for comparing rate-case timing and lobbying expenditure patterns between
the two regulated monopolies.

Watches for:
  - PUC rate case filings (Docket UG-xxx for gas utilities)
  - Lobbying expenditures
  - ORESTAR donations by NW Natural PAC, employee PAC, or executives
  - SEC EDGAR filings (NWN is publicly traded under NWN)
  - Bills affecting gas utilities, methane / pipeline regulation
"""

from __future__ import annotations

from datetime import datetime
from typing import Iterator, Optional

from ..models import Provenance, Signal
from . import WatchModule, anchor_by_slug


class NwNaturalWatch(WatchModule):
    def __init__(self) -> None:
        anchor = anchor_by_slug("nw_natural")
        if anchor is None:
            raise RuntimeError("NW Natural anchor not registered in ANCHORS")
        super().__init__(anchor)

    def extract_signals(
        self, records: list[dict], since: Optional[datetime] = None
    ) -> Iterator[Signal]:
        for r in records:
            # Donations to or from NW Natural-affiliated entities
            if "amount_usd" in r and r.get("amount_usd"):
                contributor = (
                    r.get("metadata", {}).get("contributor_name_raw") or ""
                ).strip()
                committee = (
                    r.get("metadata", {}).get("committee_name_raw") or ""
                ).strip()
                if self.matches_anchor(contributor):
                    yield self._signal(
                        kind="donation_made",
                        occurred_at=r.get("observed_at", datetime.utcnow()),
                        value=float(r["amount_usd"]),
                        payload={
                            "to_committee": committee,
                            "raw_contributor": contributor,
                        },
                        provenance=r.get("provenance"),
                    )
                elif self.matches_anchor(committee):
                    yield self._signal(
                        kind="donation_received",
                        occurred_at=r.get("observed_at", datetime.utcnow()),
                        value=float(r["amount_usd"]),
                        payload={
                            "from_contributor": contributor,
                            "raw_committee": committee,
                        },
                        provenance=r.get("provenance"),
                    )

            # Bills touching gas utility regulation
            if "bill_number" in r and "title" in r:
                title = r.get("title", "") + " " + (r.get("summary_raw") or "")
                if self.matches_anchor(title) or self._gas_legislation(title):
                    yield self._signal(
                        kind="bill_affecting_nw_natural",
                        occurred_at=datetime.utcnow(),
                        value=None,
                        payload={
                            "bill_number": r.get("bill_number"),
                            "title": r.get("title"),
                            "state": str(r.get("state")),
                        },
                        provenance=r.get("provenance"),
                    )

    def _gas_legislation(self, text: str) -> bool:
        keywords = (
            "natural gas",
            "gas utility",
            "methane",
            "pipeline safety",
            "gas pipeline",
            "ratepayer",
            "public utility commission",
            "gas rate",
            "electrification",  # gas-to-electric policy hits NW Natural directly
            "building decarbonization",
        )
        t = text.lower()
        return any(k in t for k in keywords)

    def _signal(
        self,
        kind: str,
        occurred_at: datetime,
        value: Optional[float],
        payload: dict,
        provenance: Optional[Provenance],
    ) -> Signal:
        if provenance is None:
            raise ValueError("NwNaturalWatch._signal called without provenance")
        return Signal(
            kind=kind,
            occurred_at=occurred_at,
            detected_at=datetime.utcnow(),
            value=value,
            payload=payload,
            provenance=provenance,
        )


__all__ = ["NwNaturalWatch"]
