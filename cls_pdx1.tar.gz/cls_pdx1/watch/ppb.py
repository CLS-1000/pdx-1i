"""
cls_pdx1.watch.ppb
===================

Portland Police Bureau watch module.

Different structurally from utility watches — PPB is a city bureau, not
an external entity. Its surveillance surface lives inside the city's own
records: council budget docs, city contracts, oversight body actions,
personnel reports.

Watches for:
  - Council votes touching PPB budget, policy, or contracts
  - Budget line changes (year-over-year and within-year transfers)
  - Independent Police Review / Citizen Review Committee actions
  - Contract awards (vendors for equipment, training, software)
  - Personnel actions surfacing in council oversight
  - Bills at state level affecting law enforcement scope or oversight
"""

from __future__ import annotations

from datetime import datetime
from typing import Iterator, Optional

from ..models import Provenance, Signal
from . import WatchModule, anchor_by_slug


class PpbWatch(WatchModule):
    def __init__(self) -> None:
        anchor = anchor_by_slug("ppb")
        if anchor is None:
            raise RuntimeError("PPB anchor not registered in ANCHORS")
        super().__init__(anchor)

    def extract_signals(
        self, records: list[dict], since: Optional[datetime] = None
    ) -> Iterator[Signal]:
        for r in records:
            # Council/commission vote records
            if r.get("record_kind") == "council_vote":
                subject = r.get("subject", "") or ""
                if self.matches_anchor(subject) or self._police_subject(subject):
                    yield self._signal(
                        kind="council_vote",
                        occurred_at=r.get("occurred_at", datetime.utcnow()),
                        value=None,
                        payload={
                            "subject": subject,
                            "outcome": r.get("outcome"),
                            "votes": r.get("votes"),
                        },
                        provenance=r.get("provenance"),
                    )

            # Contract awards
            if r.get("record_kind") == "contract_award":
                buyer = (r.get("buyer") or "").lower()
                description = r.get("description", "") or ""
                if self.matches_anchor(buyer) or self.matches_anchor(description):
                    yield self._signal(
                        kind="contract_award",
                        occurred_at=r.get("occurred_at", datetime.utcnow()),
                        value=float(r.get("amount_usd", 0) or 0),
                        payload={
                            "vendor": r.get("vendor"),
                            "description": description,
                            "buyer": r.get("buyer"),
                        },
                        provenance=r.get("provenance"),
                    )

            # Budget line changes
            if r.get("record_kind") == "budget_line_change":
                line_label = r.get("line_label", "") or ""
                if self.matches_anchor(line_label) or self._police_subject(line_label):
                    yield self._signal(
                        kind="budget_line_change",
                        occurred_at=r.get("occurred_at", datetime.utcnow()),
                        value=float(r.get("delta_usd", 0) or 0),
                        payload={
                            "line_label": line_label,
                            "from_amount": r.get("from_amount"),
                            "to_amount": r.get("to_amount"),
                            "fiscal_year": r.get("fiscal_year"),
                        },
                        provenance=r.get("provenance"),
                    )

            # State-level bills affecting law enforcement
            if "bill_number" in r and "title" in r:
                title = r.get("title", "") + " " + (r.get("summary_raw") or "")
                if self._police_legislation(title):
                    yield self._signal(
                        kind="bill_affecting_ppb",
                        occurred_at=datetime.utcnow(),
                        value=None,
                        payload={
                            "bill_number": r.get("bill_number"),
                            "title": r.get("title"),
                            "state": str(r.get("state")),
                        },
                        provenance=r.get("provenance"),
                    )

    def _police_subject(self, text: str) -> bool:
        keywords = (
            "police",
            "law enforcement",
            "ppb",
            "officer",
            "use of force",
            "body camera",
            "deadly force",
            "police bureau",
            "police accountability",
            "civilian oversight",
        )
        t = (text or "").lower()
        return any(k in t for k in keywords)

    def _police_legislation(self, text: str) -> bool:
        keywords = (
            "law enforcement",
            "police accountability",
            "use of force",
            "officer training",
            "body camera",
            "police records",
            "qualified immunity",
            "police certification",
            "civil asset forfeiture",
        )
        t = (text or "").lower()
        return any(k in t for k in keywords)

    def _signal(
        self,
        kind: str,
        occurred_at: datetime,
        value: Optional[float],
        payload: dict,
        provenance: Optional[Provenance],
    ) -> Signal:
        if provenance is None:
            raise ValueError("PpbWatch._signal called without provenance")
        return Signal(
            kind=kind,
            occurred_at=occurred_at,
            detected_at=datetime.utcnow(),
            value=value,
            payload=payload,
            provenance=provenance,
        )


__all__ = ["PpbWatch"]
