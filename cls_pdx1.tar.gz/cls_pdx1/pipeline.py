"""
cls_pdx1.pipeline
==================

Orchestration: composes sources, watch modules, anomaly detection, trigger
evaluation, and publication into a single coherent ingest-to-issue cycle.

Failure-first: every stage logs failures, none of them halt the pipeline.
A bad source row, a normalization error, a neutrality-gate failure on a
draft section — none of these can break the cycle.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from .anomaly import AnomalyDetector
from .models import Anomaly, Signal
from .sources import FetchResult, SourceAdapter
from .triggers import (
    TriggerEvaluation,
    TriggerPolicy,
    evaluate_publication_trigger,
)
from .watch import WatchModule


log = logging.getLogger("cls_pdx1.pipeline")


@dataclass
class PipelineRun:
    """Accounting record for a single ingest cycle."""

    started_at: datetime = field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = None
    fetch_results: list[FetchResult] = field(default_factory=list)
    signals_emitted: list[Signal] = field(default_factory=list)
    anomalies_detected: list[Anomaly] = field(default_factory=list)
    trigger: Optional[TriggerEvaluation] = None
    errors: list[str] = field(default_factory=list)

    @property
    def items_seen(self) -> int:
        return sum(fr.items_seen for fr in self.fetch_results)

    @property
    def items_accepted(self) -> int:
        return sum(fr.items_accepted for fr in self.fetch_results)

    @property
    def items_rejected(self) -> int:
        return sum(fr.items_rejected for fr in self.fetch_results)


@dataclass
class Pipeline:
    """Composed pipeline. Stateful for baseline carryover between runs.

    Compose at startup:
      pipeline = Pipeline(
          adapters=[OrestarAdapter(...), OlisAdapter(...)],
          watch_modules=[PgeWatch(), NwNaturalWatch(), ...],
          trigger_policy=TriggerPolicy(),
      )

    Run on cadence (e.g., from APScheduler):
      run = pipeline.run_cycle(last_published_at=db.get_last_issue_time())
    """

    adapters: list[SourceAdapter]
    watch_modules: list[WatchModule]
    detector: AnomalyDetector = field(default_factory=AnomalyDetector)
    trigger_policy: TriggerPolicy = field(default_factory=TriggerPolicy)

    def run_cycle(
        self,
        since: Optional[datetime] = None,
        last_published_at: Optional[datetime] = None,
    ) -> PipelineRun:
        run = PipelineRun()

        # --- 1. Fetch from every source adapter ---
        all_records: list[dict] = []
        for adapter in self.adapters:
            try:
                fr = adapter.fetch(since=since)
                run.fetch_results.append(fr)
                all_records.extend(fr.records)
                log.info(
                    "adapter=%s seen=%d accepted=%d rejected=%d",
                    adapter.name,
                    fr.items_seen,
                    fr.items_accepted,
                    fr.items_rejected,
                )
            except NotImplementedError as e:
                # Adapter is scaffolded but not yet wired — log and continue
                run.errors.append(f"{adapter.name}: not implemented ({e})")
                log.warning("adapter=%s not implemented: %s", adapter.name, e)
            except Exception as e:
                run.errors.append(f"{adapter.name}: {e!r}")
                log.exception("adapter=%s failed", adapter.name)

        # --- 2. Extract signals via watch modules ---
        for watch in self.watch_modules:
            try:
                for sig in watch.extract_signals(all_records, since=since):
                    run.signals_emitted.append(sig)
            except Exception as e:
                run.errors.append(f"watch:{watch.anchor.slug}: {e!r}")
                log.exception("watch=%s failed", watch.anchor.slug)

        # --- 3. Anomaly detection ---
        try:
            run.anomalies_detected = self.detector.feed(run.signals_emitted)
        except Exception as e:
            run.errors.append(f"anomaly: {e!r}")
            log.exception("anomaly detector failed")

        # --- 4. Publication trigger evaluation ---
        try:
            run.trigger = evaluate_publication_trigger(
                signals_since_last=run.signals_emitted,
                anomalies_since_last=run.anomalies_detected,
                last_published_at=last_published_at,
                policy=self.trigger_policy,
            )
        except Exception as e:
            run.errors.append(f"trigger: {e!r}")
            log.exception("trigger evaluation failed")

        run.ended_at = datetime.utcnow()
        return run


__all__ = ["Pipeline", "PipelineRun"]
