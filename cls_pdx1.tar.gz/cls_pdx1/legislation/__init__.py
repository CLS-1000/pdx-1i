"""
cls_pdx1.legislation
=====================

Bill tracking layer.

Treats the legislative process as a state machine. Each transition is itself
a signal — Bill state changes feed the same anomaly + publication pipeline as
watch-list signals.

The state machine is permissive: not all jurisdictions follow identical
procedures (Portland ordinance flow differs from Oregon legislative flow
differs from federal). The validation logic only flags impossible reverse
transitions; it does not impose a single canonical flow.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from ..models import Bill, BillState, BillStateTransition, Provenance, Signal


# Transitions that are structurally impossible. Going backward (e.g., from
# ENACTED to INTRODUCED) indicates a data error, not legislative reality.
TERMINAL_STATES: frozenset[BillState] = frozenset(
    {
        BillState.ENACTED,
        BillState.VETOED,
        BillState.DEAD,
        BillState.WITHDRAWN,
    }
)


class IllegalTransition(Exception):
    """Raised when a transition violates the bill state machine invariants."""


def validate_transition(from_state: Optional[BillState], to_state: BillState) -> None:
    """Raise IllegalTransition if (from -> to) is invalid.

    Rules:
      - None -> anything is allowed (new bill)
      - Same -> same is allowed (idempotent re-statement)
      - Terminal states cannot transition (except for explicit override path
        via correction, which goes through a separate API)
    """
    if from_state is None:
        return
    if from_state == to_state:
        return
    if from_state in TERMINAL_STATES:
        raise IllegalTransition(
            f"cannot transition from terminal state {from_state.value} to {to_state.value}"
        )


def apply_transition(
    bill: Bill,
    to_state: BillState,
    occurred_at: datetime,
    provenance: Provenance,
    notes: Optional[str] = None,
) -> Bill:
    """Return a new Bill record reflecting the transition. Append-only:
    original bill is not mutated.

    The new Bill carries:
      - the same id (the bill, not its versions)
      - the new current state
      - the updated state_history (old + new transition)
      - new provenance reflecting the transition's source
    """
    validate_transition(bill.state, to_state)
    transition = BillStateTransition(
        from_state=bill.state,
        to_state=to_state,
        occurred_at=occurred_at,
        notes=notes,
        provenance=provenance,
    )
    return bill.model_copy(
        update={
            "state": to_state,
            "state_history": [*bill.state_history, transition],
            "provenance": provenance,
        }
    )


def transition_to_signal(
    bill: Bill, transition: BillStateTransition
) -> Signal:
    """Promote a bill state transition into a Signal record.

    State transitions are signals — they feed the same downstream pipeline
    as watch-list events. The publication trigger may fire on accumulated
    transition activity (lots of bills moving) the same way it fires on
    anomalies (one entity doing something unusual).
    """
    return Signal(
        bill_id=bill.id,
        kind=f"bill_transition.{transition.to_state.value}",
        occurred_at=transition.occurred_at,
        detected_at=datetime.utcnow(),
        value=None,
        payload={
            "bill_number": bill.bill_number,
            "jurisdiction": bill.jurisdiction.value,
            "from_state": transition.from_state.value if transition.from_state else None,
            "to_state": transition.to_state.value,
            "notes": transition.notes,
        },
        provenance=transition.provenance,
    )


__all__ = [
    "TERMINAL_STATES",
    "IllegalTransition",
    "validate_transition",
    "apply_transition",
    "transition_to_signal",
]
