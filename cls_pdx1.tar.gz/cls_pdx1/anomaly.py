"""
cls_pdx1.anomaly
=================

Anomaly detection over watch-list signals.

Mirrors the journalist module's 4-tier alert pattern from cls_osint/journalist/:
  - 90-day rolling baseline per (entity, signal_kind) pair
  - Welford's online algorithm for mean / stdev (numerically stable)
  - Deviation expressed in sigma units
  - Tier assignment by sigma threshold

Anomaly tiers:
  Tier 1 — > 3 sigma OR Tier-1-confidence single hard signal (immediate publish-eligible)
  Tier 2 — 2 – 3 sigma OR multi-source corroborated soft signal
  Tier 3 — 1 – 2 sigma, watching
  Tier 4 — below threshold, logged for baseline only (does NOT enter publication)

All anomaly descriptions are factual, neutrally framed: "X observed value Y,
relative to 90-day baseline mean of Z (sigma N.NN)". Interpretation lives
elsewhere.
"""

from __future__ import annotations

import math
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Iterable, Optional

from .models import Anomaly, AnomalyTier, Provenance, Signal


# ---------------------------------------------------------------------------
# Sigma -> Tier thresholds
# ---------------------------------------------------------------------------


SIGMA_TIER_THRESHOLDS: list[tuple[float, AnomalyTier]] = [
    (3.0, AnomalyTier.TIER_1),
    (2.0, AnomalyTier.TIER_2),
    (1.0, AnomalyTier.TIER_3),
    (0.0, AnomalyTier.TIER_4),
]


def sigma_to_tier(sigma: float) -> AnomalyTier:
    """Map an absolute sigma value to an AnomalyTier."""
    abs_sigma = abs(sigma)
    for threshold, tier in SIGMA_TIER_THRESHOLDS:
        if abs_sigma >= threshold:
            return tier
    return AnomalyTier.TIER_4


# ---------------------------------------------------------------------------
# Rolling baseline
# ---------------------------------------------------------------------------


@dataclass
class RollingBaseline:
    """Time-windowed rolling baseline for a single (entity, kind) pair.

    Stores (timestamp, value) tuples; trims values outside the window on access.
    Uses Welford-derived sample statistics for mean and stdev.
    """

    window: timedelta
    samples: deque = field(default_factory=lambda: deque(maxlen=10_000))

    def add(self, ts: datetime, value: float) -> None:
        self.samples.append((ts, value))

    def _trim(self, now: Optional[datetime] = None) -> None:
        cutoff = (now or datetime.utcnow()) - self.window
        while self.samples and self.samples[0][0] < cutoff:
            self.samples.popleft()

    def stats(self, now: Optional[datetime] = None) -> tuple[int, float, float]:
        """Return (n, mean, stdev) for in-window samples.

        stdev is sample stdev (n-1 denominator). Returns (0, 0.0, 0.0) if empty.
        """
        self._trim(now=now)
        n = len(self.samples)
        if n == 0:
            return 0, 0.0, 0.0
        values = [v for _, v in self.samples]
        mean = sum(values) / n
        if n < 2:
            return n, mean, 0.0
        var = sum((v - mean) ** 2 for v in values) / (n - 1)
        return n, mean, math.sqrt(var)


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------


@dataclass
class AnomalyDetector:
    """Streaming anomaly detector over Signals.

    Maintains a per-(entity_id, kind) rolling baseline. As Signals arrive,
    compares each numeric signal to its baseline and emits Anomaly records
    when deviation exceeds threshold tiers.

    Non-numeric signals (value=None) bypass sigma detection; categorical
    anomaly rules can be layered above by passing them through categorical_rule.
    """

    window_days: int = 90
    min_samples_for_detection: int = 10
    baselines: dict[tuple[str, str], RollingBaseline] = field(default_factory=dict)

    def _baseline(self, entity_id: str, kind: str) -> RollingBaseline:
        key = (entity_id, kind)
        if key not in self.baselines:
            self.baselines[key] = RollingBaseline(window=timedelta(days=self.window_days))
        return self.baselines[key]

    def update(self, signal: Signal) -> Optional[Anomaly]:
        """Update baseline with a new signal; return Anomaly if it crosses threshold.

        Returns None if:
          - signal has no entity_id (untargeted signal)
          - signal value is None (non-numeric)
          - baseline has insufficient samples
          - deviation does not reach Tier 1/2 (i.e., not publication-eligible)
        """
        if not signal.entity_id:
            return None
        if signal.value is None:
            return None

        baseline = self._baseline(signal.entity_id, signal.kind)
        n_before, mean_before, stdev_before = baseline.stats(now=signal.detected_at)

        # Always update baseline regardless of whether we emit an anomaly.
        baseline.add(signal.occurred_at, signal.value)

        if n_before < self.min_samples_for_detection:
            return None

        if stdev_before == 0.0:
            # Degenerate baseline; no signal-to-noise.
            return None

        deviation = (signal.value - mean_before) / stdev_before
        tier = sigma_to_tier(deviation)

        # Tier 4 = below threshold, do not emit. Tier 3 = "watching", emit but
        # publication gate downstream will filter.
        if tier == AnomalyTier.TIER_4:
            return None

        description = self._neutral_description(
            kind=signal.kind,
            observed=signal.value,
            mean=mean_before,
            stdev=stdev_before,
            sigma=deviation,
            window_days=self.window_days,
            n_samples=n_before,
            occurred_at=signal.occurred_at,
        )

        return Anomaly(
            entity_id=signal.entity_id,
            tier=tier,
            detected_at=datetime.utcnow(),
            kind=signal.kind,
            description=description,
            baseline_window_days=self.window_days,
            baseline_mean=mean_before,
            baseline_stdev=stdev_before,
            observed_value=signal.value,
            deviation_sigma=deviation,
            signal_ids=[signal.id],
            provenance=signal.provenance,
        )

    @staticmethod
    def _neutral_description(
        kind: str,
        observed: float,
        mean: float,
        stdev: float,
        sigma: float,
        window_days: int,
        n_samples: int,
        occurred_at: datetime,
    ) -> str:
        """Build a strictly factual anomaly description. No characterization."""
        direction = "above" if sigma > 0 else "below"
        return (
            f"Signal of kind '{kind}' recorded value {observed:,.2f} on "
            f"{occurred_at.date().isoformat()}. {abs(sigma):.2f} sigma {direction} "
            f"the {window_days}-day rolling mean of {mean:,.2f} "
            f"(stdev {stdev:,.2f}, n={n_samples})."
        )

    def feed(self, signals: Iterable[Signal]) -> list[Anomaly]:
        """Convenience: feed a batch of signals, return all detected anomalies."""
        anomalies: list[Anomaly] = []
        for sig in signals:
            a = self.update(sig)
            if a is not None:
                anomalies.append(a)
        return anomalies


__all__ = [
    "AnomalyDetector",
    "RollingBaseline",
    "SIGMA_TIER_THRESHOLDS",
    "sigma_to_tier",
]
