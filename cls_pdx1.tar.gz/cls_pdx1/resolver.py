"""
cls_pdx1.resolver
==================

Entity resolution: map raw upstream names ("Portland General Electric Co",
"PGE PAC", "NW Natural Gas LLC", "Schnitzer Properties") to canonical
Entity ids from the seed (ent:pge, ent:nw-natural, ent:schnitzer-cluster).

Same for Officials — map a raw name like "Wilson, Keith" or "Mayor Wilson"
to off:portland:keith-wilson.

Design:
  - Index built once from a SeedBundle (canonical_name + aliases)
  - Names normalized aggressively (lowercase, strip corporate suffixes,
    strip punctuation, collapse whitespace)
  - Tiered match with confidence:
      EXACT      — normalized form matches canonical/alias 1:1
      ALIAS      — normalized form matches a known alias
      SUBSTRING  — canonical/alias is a substring of input or vice versa,
                   with disambiguation rules
      FUZZY      — Levenshtein-distance match below threshold
      NONE       — no acceptable match; return None and let the caller decide
  - Resolver NEVER guesses. If multiple candidates tie at the same tier,
    the result is None (ambiguous) with the candidates surfaced in the result.

This module has zero external dependencies — Levenshtein is implemented
inline (dynamic programming, O(m*n) for short strings, fine for the seed
size and upstream batch sizes we'll see).

Resolver is single-writer compatible: it does not mutate the seed bundle.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Iterable, Optional

from .models import ConfidenceTier, Entity, Official


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------


# Corporate / suffix tokens to strip before comparison. Order matters where
# multi-word forms appear (e.g. "northwest natural gas company" -> strip
# "company" last so it doesn't accidentally swallow the word "gas").
_CORPORATE_SUFFIXES = (
    "incorporated", "corporation", "corp", "company", "co",
    "limited liability company", "llc", "lp", "ltd", "inc",
    "holdings", "holding", "group", "partners", "partnership",
    "association", "associates", "foundation", "trust",
    "pac", "political action committee", "committee",
)

# Honorifics / titles to strip from official names
_OFFICIAL_TITLES = (
    "mayor", "councilor", "councilmember", "councillor",
    "council president", "council vice president",
    "vice president", "president",
    "chair", "chairman", "chairwoman", "chairperson",
    "commissioner", "commissioner of",
    "district attorney", "da",
    "sheriff", "auditor",
    "representative", "rep", "rep.",
    "senator", "sen", "sen.",
    "u.s. senator", "u.s. representative", "us senator", "us representative",
    "the honorable", "hon", "hon.",
    "former", "acting",
)

_PUNCT_RE = re.compile(r"[^\w\s]")
_WS_RE = re.compile(r"\s+")


def normalize(name: str) -> str:
    """Aggressively normalize a name for comparison.

    Lowercase, strip punctuation, drop corporate suffixes and official
    titles, collapse whitespace. Idempotent.
    """
    if not name:
        return ""
    s = name.lower()
    s = _PUNCT_RE.sub(" ", s)
    s = _WS_RE.sub(" ", s).strip()

    # Strip titles (officials) — loop to handle stacked titles
    # like "Acting President Hwang" -> "hwang"
    changed = True
    while changed:
        changed = False
        for title in sorted(_OFFICIAL_TITLES, key=len, reverse=True):
            if s.startswith(title + " "):
                s = s[len(title) + 1:]
                changed = True
                break
            if s.endswith(" " + title):
                s = s[: -(len(title) + 1)]
                changed = True
                break

    # Strip corporate suffixes (entities) — apply repeatedly to handle
    # chained suffixes like "Acme Holdings Inc"
    changed = True
    while changed:
        changed = False
        for sfx in sorted(_CORPORATE_SUFFIXES, key=len, reverse=True):
            if s.endswith(" " + sfx):
                s = s[: -(len(sfx) + 1)].strip()
                changed = True
                break

    return _WS_RE.sub(" ", s).strip()


# ---------------------------------------------------------------------------
# Levenshtein distance (small, dependency-free)
# ---------------------------------------------------------------------------


def _levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    if len(a) > len(b):
        a, b = b, a
    prev = list(range(len(a) + 1))
    for j, cb in enumerate(b, 1):
        curr = [j]
        for i, ca in enumerate(a, 1):
            ins = curr[i - 1] + 1
            dele = prev[i] + 1
            sub = prev[i - 1] + (0 if ca == cb else 1)
            curr.append(min(ins, dele, sub))
        prev = curr
    return prev[-1]


def _fuzzy_ratio(a: str, b: str) -> float:
    """Similarity score in [0, 1]. 1.0 is identical, 0.0 is no overlap."""
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    dist = _levenshtein(a, b)
    return 1.0 - (dist / max(len(a), len(b)))


# ---------------------------------------------------------------------------
# Match tier
# ---------------------------------------------------------------------------


class MatchTier(IntEnum):
    """Confidence tier for an entity resolution.

    Mapped to ConfidenceTier for downstream consistency:
      EXACT  -> HARD_RECORD (canonical match is as solid as the seed itself)
      ALIAS  -> DOCUMENTED  (alias was vetted in seed)
      SUBSTRING -> REPORTED (could be wrong, treat with care)
      FUZZY     -> INFERRED (statistical, not factual)
    """

    EXACT = 1
    ALIAS = 2
    SUBSTRING = 3
    FUZZY = 4
    NONE = 99

    def to_confidence(self) -> Optional[ConfidenceTier]:
        return {
            MatchTier.EXACT: ConfidenceTier.HARD_RECORD,
            MatchTier.ALIAS: ConfidenceTier.DOCUMENTED,
            MatchTier.SUBSTRING: ConfidenceTier.REPORTED,
            MatchTier.FUZZY: ConfidenceTier.INFERRED,
            MatchTier.NONE: None,
        }[self]


@dataclass
class ResolutionResult:
    """Outcome of a resolution attempt.

    `resolved_id` is None when there's no acceptable match OR when the
    match is ambiguous (multiple candidates tied at the same tier).
    `candidates` always lists what was considered, for debugging.
    """

    raw_input: str
    normalized: str
    resolved_id: Optional[str]
    tier: MatchTier
    score: float = 0.0
    candidates: list[tuple[str, MatchTier, float]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    @property
    def confidence(self) -> Optional[ConfidenceTier]:
        return self.tier.to_confidence()

    @property
    def is_resolved(self) -> bool:
        return self.resolved_id is not None

    @property
    def is_ambiguous(self) -> bool:
        return self.resolved_id is None and self.tier != MatchTier.NONE

    def __repr__(self) -> str:
        if self.is_resolved:
            return (
                f"<Resolved {self.raw_input!r} -> {self.resolved_id} "
                f"(tier={self.tier.name}, score={self.score:.2f})>"
            )
        return (
            f"<Unresolved {self.raw_input!r} "
            f"(candidates={len(self.candidates)})>"
        )


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------


# Minimum fuzzy ratio to consider a match. Below this we don't even surface
# it as a candidate. Tuned for short labels where 0.85 is "obvious typo or
# minor variant" territory.
DEFAULT_FUZZY_THRESHOLD = 0.85


@dataclass
class EntityResolver:
    """Maps raw names to canonical Entity ids.

    Build once from a SeedBundle; query many times. The resolver is
    stateless across resolution calls — index is built at construction
    and never mutated.
    """

    fuzzy_threshold: float = DEFAULT_FUZZY_THRESHOLD
    _canonical_idx: dict[str, str] = field(default_factory=dict)
    _alias_idx: dict[str, str] = field(default_factory=dict)
    # For substring matching we need to iterate; keep a list of (norm, id) pairs
    _all_names: list[tuple[str, str]] = field(default_factory=list)

    @classmethod
    def from_entities(
        cls,
        entities: Iterable[Entity],
        fuzzy_threshold: float = DEFAULT_FUZZY_THRESHOLD,
    ) -> "EntityResolver":
        resolver = cls(fuzzy_threshold=fuzzy_threshold)
        resolver._build_index(entities)
        return resolver

    def _build_index(self, entities: Iterable[Entity]) -> None:
        for e in entities:
            norm_canonical = normalize(e.canonical_name)
            if norm_canonical:
                # First write wins; if seed has duplicate normalized canonicals,
                # earlier ones win. (Should never happen — test_seed asserts ids unique.)
                self._canonical_idx.setdefault(norm_canonical, e.id)
                self._all_names.append((norm_canonical, e.id))
            for alias in e.aliases:
                norm_alias = normalize(alias)
                if norm_alias and norm_alias != norm_canonical:
                    self._alias_idx.setdefault(norm_alias, e.id)
                    self._all_names.append((norm_alias, e.id))

    # ----- Resolution -----

    def resolve(self, raw_name: str) -> ResolutionResult:
        result = ResolutionResult(
            raw_input=raw_name,
            normalized=normalize(raw_name),
            resolved_id=None,
            tier=MatchTier.NONE,
        )
        norm = result.normalized
        if not norm:
            result.notes.append("empty input after normalization")
            return result

        # Tier 1: exact canonical match
        if norm in self._canonical_idx:
            result.resolved_id = self._canonical_idx[norm]
            result.tier = MatchTier.EXACT
            result.score = 1.0
            result.candidates.append((result.resolved_id, MatchTier.EXACT, 1.0))
            return result

        # Tier 2: exact alias match
        if norm in self._alias_idx:
            result.resolved_id = self._alias_idx[norm]
            result.tier = MatchTier.ALIAS
            result.score = 1.0
            result.candidates.append((result.resolved_id, MatchTier.ALIAS, 1.0))
            return result

        # Tier 3: substring (with ambiguity check + min-length guard)
        # Min length 6 on the shorter side prevents short aliases like
        # "port" from matching anything containing the substring "port".
        substring_hits: list[tuple[str, float]] = []
        for known_norm, eid in self._all_names:
            if not known_norm:
                continue
            if known_norm in norm or norm in known_norm:
                shorter = min(len(known_norm), len(norm))
                longer = max(len(known_norm), len(norm))
                if shorter < 6:
                    continue
                substring_hits.append((eid, shorter / longer))
        # Dedupe by entity_id (keep best score per id)
        best_per_id: dict[str, float] = {}
        for eid, score in substring_hits:
            best_per_id[eid] = max(score, best_per_id.get(eid, 0.0))
        if best_per_id:
            ranked = sorted(best_per_id.items(), key=lambda kv: -kv[1])
            result.candidates = [
                (eid, MatchTier.SUBSTRING, score) for eid, score in ranked
            ]
            top_id, top_score = ranked[0]
            # If multiple substring hits tied at top, mark ambiguous
            ties = [eid for eid, s in ranked if s == top_score]
            if len(ties) == 1:
                result.resolved_id = top_id
                result.tier = MatchTier.SUBSTRING
                result.score = top_score
                return result
            result.tier = MatchTier.SUBSTRING
            result.score = top_score
            result.notes.append(
                f"ambiguous substring match: {ties}"
            )
            return result

        # Tier 4: fuzzy
        fuzzy_hits: list[tuple[str, float]] = []
        for known_norm, eid in self._all_names:
            score = _fuzzy_ratio(norm, known_norm)
            if score >= self.fuzzy_threshold:
                fuzzy_hits.append((eid, score))
        best_per_id = {}
        for eid, score in fuzzy_hits:
            best_per_id[eid] = max(score, best_per_id.get(eid, 0.0))
        if best_per_id:
            ranked = sorted(best_per_id.items(), key=lambda kv: -kv[1])
            result.candidates = [
                (eid, MatchTier.FUZZY, score) for eid, score in ranked
            ]
            top_id, top_score = ranked[0]
            ties = [eid for eid, s in ranked if s == top_score]
            if len(ties) == 1:
                result.resolved_id = top_id
                result.tier = MatchTier.FUZZY
                result.score = top_score
                return result
            result.tier = MatchTier.FUZZY
            result.score = top_score
            result.notes.append(
                f"ambiguous fuzzy match: {ties}"
            )
            return result

        return result

    def resolve_batch(self, raw_names: Iterable[str]) -> list[ResolutionResult]:
        return [self.resolve(n) for n in raw_names]


# ---------------------------------------------------------------------------
# Official resolver — same shape, just over Officials
# ---------------------------------------------------------------------------


@dataclass
class OfficialResolver:
    """Maps raw names like 'Wilson, Keith' or 'Mayor Wilson' to off:* ids.

    Construction is symmetric to EntityResolver; the indexing is over
    `Official.full_name` and `Official.aliases`.
    """

    fuzzy_threshold: float = DEFAULT_FUZZY_THRESHOLD
    _canonical_idx: dict[str, str] = field(default_factory=dict)
    _alias_idx: dict[str, str] = field(default_factory=dict)
    _all_names: list[tuple[str, str]] = field(default_factory=list)
    # Last-name index for officials. Surnames are often used in news
    # references ("the Schnitzer", "Senator Wyden's") so we maintain a
    # last-name index but only resolve via it when the last name is
    # unique in the seed.
    _last_name_idx: dict[str, list[str]] = field(default_factory=dict)

    @classmethod
    def from_officials(
        cls,
        officials: Iterable[Official],
        fuzzy_threshold: float = DEFAULT_FUZZY_THRESHOLD,
    ) -> "OfficialResolver":
        resolver = cls(fuzzy_threshold=fuzzy_threshold)
        resolver._build_index(officials)
        return resolver

    def _build_index(self, officials: Iterable[Official]) -> None:
        for o in officials:
            norm_canonical = normalize(o.full_name)
            if norm_canonical:
                self._canonical_idx.setdefault(norm_canonical, o.id)
                self._all_names.append((norm_canonical, o.id))
                # Last name index
                parts = norm_canonical.split()
                if parts:
                    last = parts[-1]
                    self._last_name_idx.setdefault(last, []).append(o.id)
            for alias in o.aliases:
                norm_alias = normalize(alias)
                if norm_alias and norm_alias != norm_canonical:
                    self._alias_idx.setdefault(norm_alias, o.id)
                    self._all_names.append((norm_alias, o.id))

    def resolve(self, raw_name: str) -> ResolutionResult:
        result = ResolutionResult(
            raw_input=raw_name,
            normalized=normalize(raw_name),
            resolved_id=None,
            tier=MatchTier.NONE,
        )
        norm = result.normalized
        if not norm:
            result.notes.append("empty input after normalization")
            return result

        # Tier 1: exact canonical
        if norm in self._canonical_idx:
            result.resolved_id = self._canonical_idx[norm]
            result.tier = MatchTier.EXACT
            result.score = 1.0
            result.candidates.append((result.resolved_id, MatchTier.EXACT, 1.0))
            return result

        # Tier 2: exact alias
        if norm in self._alias_idx:
            result.resolved_id = self._alias_idx[norm]
            result.tier = MatchTier.ALIAS
            result.score = 1.0
            result.candidates.append((result.resolved_id, MatchTier.ALIAS, 1.0))
            return result

        # Last-name lookup: only if the input is a single token and the
        # surname is unique in the index. Higher signal than substring.
        if " " not in norm and norm in self._last_name_idx:
            candidates = self._last_name_idx[norm]
            if len(candidates) == 1:
                result.resolved_id = candidates[0]
                result.tier = MatchTier.ALIAS
                result.score = 1.0
                result.candidates.append(
                    (candidates[0], MatchTier.ALIAS, 1.0)
                )
                result.notes.append("unique-surname match")
                return result
            result.candidates = [
                (c, MatchTier.SUBSTRING, 0.5) for c in candidates
            ]
            result.tier = MatchTier.SUBSTRING
            result.notes.append(f"ambiguous surname: {candidates}")
            return result

        # Tier 3: substring (min-length guard on shorter side)
        substring_hits: list[tuple[str, float]] = []
        for known_norm, oid in self._all_names:
            if not known_norm:
                continue
            if known_norm in norm or norm in known_norm:
                shorter = min(len(known_norm), len(norm))
                longer = max(len(known_norm), len(norm))
                if shorter < 6:
                    continue
                substring_hits.append((oid, shorter / longer))
        best_per_id: dict[str, float] = {}
        for oid, score in substring_hits:
            best_per_id[oid] = max(score, best_per_id.get(oid, 0.0))
        if best_per_id:
            ranked = sorted(best_per_id.items(), key=lambda kv: -kv[1])
            result.candidates = [
                (oid, MatchTier.SUBSTRING, score) for oid, score in ranked
            ]
            top_id, top_score = ranked[0]
            ties = [oid for oid, s in ranked if s == top_score]
            if len(ties) == 1:
                result.resolved_id = top_id
                result.tier = MatchTier.SUBSTRING
                result.score = top_score
                return result
            result.tier = MatchTier.SUBSTRING
            result.score = top_score
            result.notes.append(f"ambiguous substring: {ties}")
            return result

        # Tier 4: fuzzy
        fuzzy_hits: list[tuple[str, float]] = []
        for known_norm, oid in self._all_names:
            score = _fuzzy_ratio(norm, known_norm)
            if score >= self.fuzzy_threshold:
                fuzzy_hits.append((oid, score))
        best_per_id = {}
        for oid, score in fuzzy_hits:
            best_per_id[oid] = max(score, best_per_id.get(oid, 0.0))
        if best_per_id:
            ranked = sorted(best_per_id.items(), key=lambda kv: -kv[1])
            result.candidates = [
                (oid, MatchTier.FUZZY, score) for oid, score in ranked
            ]
            top_id, top_score = ranked[0]
            ties = [oid for oid, s in ranked if s == top_score]
            if len(ties) == 1:
                result.resolved_id = top_id
                result.tier = MatchTier.FUZZY
                result.score = top_score
                return result
            result.tier = MatchTier.FUZZY
            result.score = top_score
            result.notes.append(f"ambiguous fuzzy: {ties}")
            return result

        return result

    def resolve_batch(self, raw_names: Iterable[str]) -> list[ResolutionResult]:
        return [self.resolve(n) for n in raw_names]


__all__ = [
    "normalize",
    "MatchTier",
    "ResolutionResult",
    "EntityResolver",
    "OfficialResolver",
    "DEFAULT_FUZZY_THRESHOLD",
]
